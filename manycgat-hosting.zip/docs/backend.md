# Backend do ManyChat pessoal

Esta camada usa um banco JSON local em `data/db.json`. O arquivo é carregado uma vez em memória, as alterações passam por uma fila de mutações e cada gravação usa um arquivo temporário, `fsync` e `rename`. O banco é validado ao carregar e antes de ser persistido.

## Escopo entregue

- Store JSON com cache, fila de escrita e gravação atômica.
- Seed funcional com automações, links, contatos e métricas agregadas.
- Histórico de eventos limitado a 2.000 itens e mensagens por conversa limitadas a 200 itens para o volume pessoal previsto.
- Contadores agregados por total e por dia para DMs, respostas públicas, cliques, automações, webhooks e falhas.
- Modo mock seguro para Instagram quando as credenciais não existem.
- Integração isolada com a Meta Graph API em `src/lib/server/instagram.ts`.

## Rotas

| Método | Rota | Uso |
| --- | --- | --- |
| GET | `/api/dashboard?days=30` | Resumo, série diária, automações e links |
| GET | `/api/automations` | Lista automações; aceita `status` e `q` |
| POST | `/api/automations` | Cria uma automação |
| GET | `/api/automations/:id` | Consulta uma automação |
| PATCH | `/api/automations/:id` | Atualiza uma automação |
| DELETE | `/api/automations/:id` | Arquiva uma automação |
| GET | `/api/links` | Lista links e cliques |
| POST | `/api/links` | Cria um link rastreável |
| POST | `/api/links/:id/click` | Registra um clique e devolve a URL |
| GET | `/api/webhook/instagram` | Validação do callback da Meta |
| POST | `/api/webhook/instagram` | Recebe comentários e DMs da Meta |
| GET | `/api/health` | Saúde da store e estado da integração |

## Variáveis de ambiente

```text
JSON_DB_PATH=./data/db.json
INSTAGRAM_ACCESS_TOKEN=
INSTAGRAM_ACCOUNT_ID=
INSTAGRAM_MOCK_MODE=false
META_APP_SECRET=
META_WEBHOOK_VERIFY_TOKEN=
META_GRAPH_API_BASE_URL=https://graph.facebook.com/v23.0
LINK_CLICK_HASH_SECRET=troque-por-um-segredo
ALLOW_UNSIGNED_WEBHOOKS=false
```

`META_ACCESS_TOKEN` e `META_INSTAGRAM_ACCOUNT_ID` também são aceitos como aliases. Sem token e ID da conta, o envio fica em modo mock e nenhum request externo é feito. Quando as credenciais existem, o sender chama os endpoints de mensagens e respostas da Graph API; valide a versão, permissões e formato exato habilitados no seu app da Meta antes de produção.

## Webhook da Meta

Configure o callback para `/api/webhook/instagram`, usando o mesmo `META_WEBHOOK_VERIFY_TOKEN`. Em produção, `META_APP_SECRET` é obrigatório para validar `X-Hub-Signature-256`; sem ele, o POST é recusado. Para desenvolvimento local, a aceitação sem assinatura só ocorre com `ALLOW_UNSIGNED_WEBHOOKS=true` e `NODE_ENV` diferente de `production`.

O processamento é idempotente enquanto o `externalId` permanecer no histórico. Eventos repetidos são ignorados. O primeiro gatilho ativo correspondente é escolhido para evitar duas DMs para o mesmo evento.

## Cliques e privacidade

O endpoint aceita `visitorId` opcional no corpo. Sem ele, usa o primeiro IP de `X-Forwarded-For` combinado com User-Agent, quando disponível. O valor armazenado é somente um hash SHA-256 com `LINK_CLICK_HASH_SECRET`; IP e User-Agent não são salvos no JSON. Se não houver identificador, o clique é contado como único.

## Operação do JSON

O volume previsto de 3 a 5 mil DMs por mês é compatível com este desenho porque as métricas não geram um registro por métrica, o histórico é limitado e as conversas são truncadas. Faça backup do `data/db.json` antes de deploys e não rode múltiplas instâncias gravando o mesmo arquivo. Para um único processo pessoal, a fila em memória mantém as gravações ordenadas; múltiplas instâncias exigiriam SQLite ou outro armazenamento com lock.

## Segurança do painel

As rotas entregues são de backend e não adicionam autenticação de sessão porque o projeto não tinha uma camada de autenticação nem configuração existente no workspace. Antes de expor o painel publicamente, coloque autenticação no middleware ou no proxy da aplicação e mantenha os tokens apenas em variáveis de ambiente. O webhook possui verificação própria de assinatura e não deve ser liberado com `ALLOW_UNSIGNED_WEBHOOKS` em produção.
