# Textos legais do app pessoal

Última atualização de referência: 21 de setembro de 2026.

Este arquivo registra o conteúdo-base publicado em `/privacy` e `/security`. Antes de publicar o app no Facebook for Developers, o responsável deve:

- preencher o canal de contato real nas duas páginas quando necessário;
- confirmar as permissões realmente usadas na API da Meta;
- confirmar o ambiente de hospedagem, a retenção de logs e a rotina de backup;
- revisar o texto conforme o uso final e as leis aplicáveis;
- manter a data de atualização sincronizada com mudanças relevantes.

## Escopo do app

O app é uma ferramenta pessoal e interna conectada a uma única conta profissional do Instagram. Ele recebe eventos autorizados, executa automações configuradas pelo proprietário da conta e registra métricas operacionais como mensagens, cliques, falhas e execuções.

## Dados tratados

Podem ser tratados identificadores públicos, nomes de usuário, textos de comentários e mensagens, configurações de automação, links e eventos técnicos. O app não deve solicitar senha do Instagram, dados de cartão ou documentos de identidade.

## Finalidade

Os dados são usados para reconhecer eventos, responder comentários, enviar mensagens configuradas, medir resultados, evitar duplicidade e diagnosticar falhas. Não há finalidade de venda de dados ou publicidade de terceiros.

## Armazenamento JSON

O armazenamento operacional usa arquivos JSON. Esses arquivos precisam ficar fora da pasta pública, com permissões restritas, escrita controlada pelo servidor, gravação atômica e rotação de registros antigos. Tokens e segredos não devem ficar nesses arquivos nem no repositório.

## Tokens e webhooks

Tokens, segredos de webhook e credenciais devem ficar em variáveis protegidas do ambiente. Webhooks precisam ter a origem e a assinatura validadas antes do processamento. Identificadores de evento devem ser usados para reduzir duplicidade.

## Retenção e direitos

A retenção deve durar apenas o necessário para operar automações e consultar métricas. O responsável deve definir prazos concretos para eventos, logs e backups, além de atender solicitações de acesso, correção ou exclusão quando aplicável.

## Contato

Contato do responsável: **[preencher endereço de e-mail ou canal de contato]**.

## Limitações

O app depende da API, das permissões e dos limites da Meta. Nenhuma página garante disponibilidade contínua ou entrega de todas as mensagens. O texto deve ser revisado quando o fluxo, o armazenamento, as permissões ou o ambiente mudarem.
