import { FlowBuilder } from "../../../../../../components/dashboard/flow-builder";

export default async function AutomationFlowPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FlowBuilder flowId={id} automationId={id} />;
}
