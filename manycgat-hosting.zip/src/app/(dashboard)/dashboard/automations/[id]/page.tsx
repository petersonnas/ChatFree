import { notFound } from "next/navigation";
import { AutomationEditor } from "../../../../../components/dashboard/automation-editor";
import { getAutomation } from "../../../../../lib/server/repository";

export default async function EditAutomationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const automation = await getAutomation(id);
  if (!automation) notFound();
  return <AutomationEditor automation={automation} />;
}
