import { AutomationEditor } from "../../../../../components/dashboard/automation-editor";
import { getAutomationTemplate } from "../../../../../lib/automation-templates";

export default async function NewAutomationPage({ searchParams }: { searchParams: Promise<{ template?: string | string[] }> }) {
  const query = await searchParams;
  const requested = Array.isArray(query.template) ? query.template[0] : query.template;
  const template = getAutomationTemplate(requested);
  return <AutomationEditor key={template?.id ?? "blank"} template={template} templateError={requested && !template ? "Modelo não encontrado. Configure a automação abaixo." : undefined} />;
}
