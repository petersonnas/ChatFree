import { AutomationList } from "../../../../components/dashboard/dashboard-ui";

export default function AutomationsPage() {
  return <AutomationList />;
}
