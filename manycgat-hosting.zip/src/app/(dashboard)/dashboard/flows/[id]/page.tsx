import { FlowBuilder } from "../../../../../components/dashboard/flow-builder";

export default async function FlowPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FlowBuilder flowId={id} />;
}
