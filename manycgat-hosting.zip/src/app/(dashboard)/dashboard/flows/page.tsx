import { FlowBuilder } from "../../../../components/dashboard/flow-builder";

export default function FlowsPage() {
  return <FlowBuilder />;
}
