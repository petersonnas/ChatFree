import { InboxView } from "../../../../components/dashboard/inbox-view";

export default function InboxPage() {
  return <InboxView />;
}
