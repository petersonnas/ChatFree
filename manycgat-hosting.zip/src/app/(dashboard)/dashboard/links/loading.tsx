import styles from "../../../../components/dashboard/links.module.css";

export default function Loading() {
  return <main className={styles.page} aria-label="Carregando links"><div className={styles.pageHeader}><div><span className={`${styles.skeleton} ${styles.metricSkeleton}`} /><span className={`${styles.skeleton} ${styles.loadingTitle}`} /></div></div><div className={styles.metricGrid}><span className={`${styles.skeleton} ${styles.loadingCard}`} /><span className={`${styles.skeleton} ${styles.loadingCard}`} /><span className={`${styles.skeleton} ${styles.loadingCard}`} /></div><div className={`${styles.skeleton} ${styles.loadingPanel}`} /></main>;
}
