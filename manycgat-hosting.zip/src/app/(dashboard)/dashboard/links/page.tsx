import { LinksView } from "../../../../components/dashboard/links-view";

export default function LinksPage() {
  return <LinksView />;
}
