import { ModelsPage } from "../../../../components/dashboard/dashboard-ui";

export default function ModelsRoute() {
  return <ModelsPage />;
}
