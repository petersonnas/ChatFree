import { DashboardOverview } from "../../../components/dashboard/dashboard-ui";

export default function DashboardPage() {
  return <DashboardOverview />;
}
