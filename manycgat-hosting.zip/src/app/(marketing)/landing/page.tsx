import Link from "next/link";

import { FeatureCard } from "../../../components/marketing/FeatureCard";
import { MarketingFrame } from "../../../components/marketing/MarketingFrame";
import { SectionHeading } from "../../../components/marketing/SectionHeading";
import styles from "../../../components/marketing/marketing.module.css";

export const metadata = {
  title: "Automação para Instagram",
  description: "Organize comentários, mensagens e links do Instagram em um painel pessoal.",
};

const features = [
  {
    icon: "↗",
    title: "Comentários que viram conversa",
    description: "Crie gatilhos por palavra-chave e responda publicamente ou continue a conversa por mensagem privada.",
  },
  {
    icon: "✦",
    title: "Mensagens prontas para cada momento",
    description: "Monte respostas de boas-vindas, links, perguntas e próximos passos com uma experiência simples de editar.",
  },
  {
    icon: "◷",
    title: "Resultados em uma visão",
    description: "Acompanhe DMs enviadas, cliques em links, automações ativas e o histórico das execuções.",
  },
];

function DashboardPreview() {
  return (
    <div className={styles.dashboardMockup} aria-label="Prévia do painel de automações" role="img">
      <div className={styles.mockupTopbar}>
        <span className={styles.windowDot} />
        <span className={styles.windowDot} />
        <span className={styles.windowDot} />
        <span className={styles.mockupAddress} />
      </div>
      <div className={styles.mockupBody}>
        <div className={styles.mockupRail}>
          <span className={styles.railLogo}>ia</span>
          <span className={styles.railIcon} />
          <span className={`${styles.railIcon} ${styles.railIconActive}`} />
          <span className={styles.railIcon} />
          <span className={styles.railIcon} />
        </div>
        <div className={styles.mockupContent}>
          <div className={styles.mockupHeading}>
            <span className={styles.mockupTitle} />
            <span className={styles.mockupButton} />
          </div>
          <span className={styles.mockupSubline} />
          <div className={styles.mockupStats}>
            {['Mensagens', 'Cliques', 'Automações'].map((label) => (
              <div className={styles.mockupStat} key={label}>
                <span className={styles.mockupStatLabel} />
                <span className={styles.mockupStatValue} />
              </div>
            ))}
          </div>
          <div className={styles.mockupPanel}>
            <div className={styles.mockupPanelHeader}>
              <span className={styles.mockupPanelTitle} />
              <span className={styles.mockupPanelAction} />
            </div>
            {['Enviar link', 'Novos seguidores', 'Resposta padrão'].map((item, index) => (
              <div className={styles.mockupRow} key={item} aria-label={item}>
                <span className={`${styles.mockupRowLine} ${index === 0 ? styles.mockupRowLineStrong : ''}`} />
                <span className={styles.mockupRowLine} />
                <span className={styles.mockupLive} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MarketingHomePage() {
  return (
    <MarketingFrame>
      <div className={styles.contentWidth}>
        <section className={styles.hero} aria-labelledby="hero-title">
          <div className={styles.heroCopy}>
            <p className={styles.eyebrow}>Automação para Instagram</p>
            <h1 id="hero-title">Responda mais pessoas, com menos trabalho manual.</h1>
            <p className={styles.heroLead}>
              Um painel pessoal para transformar comentários em conversas, enviar links por DM e entender o que está funcionando.
            </p>
            <div className={styles.heroActions}>
              <Link className={styles.primaryButton} href="/dashboard">
                Acessar painel
              </Link>
              <Link className={styles.secondaryButton} href="#como-funciona">
                Ver como funciona
              </Link>
            </div>
            <p className={styles.heroNote}>
              <span className={styles.statusDot} aria-hidden="true" />
              Feito para uma conta profissional e um uso pessoal.
            </p>
          </div>
          <div className={styles.heroVisual}>
            <DashboardPreview />
          </div>
        </section>
      </div>

      <section className={`${styles.section} ${styles.sectionSoft}`} id="recursos" aria-labelledby="resources-title">
        <div className={styles.contentWidth}>
          <SectionHeading
            id="resources-title"
            eyebrow="Recursos"
            title="Tudo o que você precisa para manter a conversa andando."
            description="Uma base enxuta para criar automações úteis, acompanhar seus links e responder a sua comunidade com contexto."
          />
          <div className={styles.featureGrid}>
            {features.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} id="como-funciona" aria-labelledby="how-title">
        <div className={styles.contentWidth}>
          <SectionHeading
            id="how-title"
            eyebrow="Como funciona"
            title="Do gatilho ao resultado em três passos."
            description="A configuração acompanha a lógica de uma conversa real e deixa o preview sempre por perto."
          />
          <div className={styles.steps}>
            <article className={styles.step}>
              <span className={styles.stepNumber}>1</span>
              <h3>Escolha o gatilho</h3>
              <p>Defina se a automação começa em um comentário, uma palavra-chave, um novo seguidor ou uma mensagem recebida.</p>
            </article>
            <article className={styles.step}>
              <span className={styles.stepNumber}>2</span>
              <h3>Monte a resposta</h3>
              <p>Escreva a mensagem pública, a DM, os botões e os links que fazem sentido para aquela pessoa.</p>
            </article>
            <article className={styles.step}>
              <span className={styles.stepNumber}>3</span>
              <h3>Acompanhe o efeito</h3>
              <p>Veja mensagens enviadas, cliques e execuções no dashboard para ajustar o fluxo quando necessário.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="privacy-preview-title">
        <div className={styles.contentWidth}>
          <div className={styles.trustBand}>
            <div>
              <h2 id="privacy-preview-title">Transparência desde o começo.</h2>
              <p>O app explica quais dados usa, onde eles ficam e quais limites existem na integração com o Instagram.</p>
            </div>
            <Link className={styles.secondaryButton} href="/privacy">
              Ler privacidade
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.finalCta} aria-labelledby="final-cta-title">
        <div className={styles.contentWidth}>
          <h2 id="final-cta-title">Pronto para organizar seu próximo fluxo?</h2>
          <p>Abra o painel e comece com uma automação simples para testar o caminho completo.</p>
          <Link className={styles.primaryButton} href="/dashboard">
            Acessar painel
          </Link>
        </div>
      </section>
    </MarketingFrame>
  );
}
