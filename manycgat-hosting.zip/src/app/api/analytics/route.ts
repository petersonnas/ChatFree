import { NextRequest, NextResponse } from "next/server";
import { getAnalytics } from "../../../lib/server/repository";
import { errorResponse } from "../../../lib/server/http";
import { parseDays } from "../../../lib/server/validation";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const days = parseDays(request.nextUrl.searchParams.get("days"));
    return NextResponse.json({ data: await getAnalytics(days) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}
