import { NextRequest, NextResponse } from "next/server";
import { createSessionToken } from "../../../../lib/session";

const SESSION_COOKIE = "conversa_session";

export async function POST(request: NextRequest): Promise<NextResponse> {
  const accessKey = process.env.APP_ACCESS_KEY;
  if (!accessKey) return NextResponse.json({ error: "APP_ACCESS_KEY não configurada." }, { status: 503 });

  const body = (await request.json().catch(() => null)) as { accessKey?: unknown } | null;
  if (!body || body.accessKey !== accessKey) return NextResponse.json({ error: "Chave de acesso inválida." }, { status: 401 });

  const response = NextResponse.json({ data: { authenticated: true } });
  response.cookies.set(SESSION_COOKIE, await createSessionToken(accessKey), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 30 * 24 * 60 * 60,
  });
  return response;
}
