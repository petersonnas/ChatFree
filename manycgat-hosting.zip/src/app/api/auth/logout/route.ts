import { NextResponse } from "next/server";

export async function POST(): Promise<NextResponse> {
  const response = NextResponse.json({ data: { authenticated: false } });
  response.cookies.set("conversa_session", "", { httpOnly: true, expires: new Date(0), path: "/" });
  return response;
}
