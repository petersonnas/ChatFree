import { NextRequest, NextResponse } from "next/server";
import { archiveAutomation, getAutomation, updateAutomation } from "../../../../lib/server/repository";
import { errorResponse, notFound, readJson } from "../../../../lib/server/http";
import { parseAutomationPatch } from "../../../../lib/server/validation";

type RouteContext = { params: { id: string } | Promise<{ id: string }> };

async function routeId(context: RouteContext): Promise<string> {
  return (await context.params).id;
}

export async function GET(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const automation = await getAutomation(await routeId(context));
    return automation ? NextResponse.json({ data: automation }) : notFound("Automação");
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const patch = parseAutomationPatch(await readJson(request));
    const automation = await updateAutomation(await routeId(context), patch);
    return automation ? NextResponse.json({ data: automation }) : notFound("Automação");
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const archived = await archiveAutomation(await routeId(context));
    return archived ? NextResponse.json({ data: { archived: true } }) : notFound("Automação");
  } catch (error) {
    return errorResponse(error);
  }
}
