import { NextRequest, NextResponse } from "next/server";
import { createAutomation, listAutomations } from "../../../lib/server/repository";
import { errorResponse, readJson } from "../../../lib/server/http";
import { parseAutomationDraft } from "../../../lib/server/validation";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const status = request.nextUrl.searchParams.get("status") as import("../../../types/backend").AutomationStatus | null;
    const query = request.nextUrl.searchParams.get("q") ?? undefined;
    return NextResponse.json({ data: await listAutomations({ status: status ?? undefined, query }) });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const draft = parseAutomationDraft(await readJson(request));
    return NextResponse.json({ data: await createAutomation(draft) }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
