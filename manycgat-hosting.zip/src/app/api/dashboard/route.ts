import { NextRequest, NextResponse } from "next/server";
import { getDashboard } from "../../../lib/server/repository";
import { errorResponse } from "../../../lib/server/http";
import { getInstagramIntegrationStatus } from "../../../lib/server/instagram";
import { parseDays } from "../../../lib/server/validation";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const days = parseDays(request.nextUrl.searchParams.get("days"));
    const integration = getInstagramIntegrationStatus();
    return NextResponse.json({ data: await getDashboard(days, integration) });
  } catch (error) {
    return errorResponse(error);
  }
}
