import { createHmac, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { getWebhookAppSecret } from "../../../lib/server/instagram";
import { operationQueue } from "../../../lib/server/operation-queue";

export const runtime = "nodejs";

function decodeBase64UrlBuffer(value: string): Buffer | undefined {
  try {
    return Buffer.from(value.replace(/-/g, "+").replace(/_/g, "/"), "base64");
  } catch {
    return undefined;
  }
}

function verifySignedRequest(value: string, secret: string): Record<string, unknown> | undefined {
  const [encodedSignature, encodedPayload] = value.split(".");
  if (!encodedSignature || !encodedPayload) return undefined;
  const signature = decodeBase64UrlBuffer(encodedSignature);
  const payload = decodeBase64UrlBuffer(encodedPayload);
  if (!signature || !payload) return undefined;
  const expected = createHmac("sha256", secret).update(encodedPayload).digest();
  if (signature.length !== expected.length || !timingSafeEqual(signature, expected)) return undefined;
  try {
    const parsed: unknown = JSON.parse(payload.toString("utf8"));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed as Record<string, unknown> : undefined;
  } catch {
    return undefined;
  }
}

async function readSignedRequest(request: NextRequest): Promise<string | undefined> {
  const contentType = request.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const body = await request.json().catch(() => null) as { signed_request?: unknown } | null;
    return typeof body?.signed_request === "string" ? body.signed_request : undefined;
  }
  const form = await request.formData().catch(() => undefined);
  const signedRequest = form?.get("signed_request");
  return typeof signedRequest === "string" ? signedRequest : undefined;
}

function subjectId(payload: Record<string, unknown>): string | undefined {
  const nested = payload.data && typeof payload.data === "object" ? payload.data as Record<string, unknown> : undefined;
  const value = payload.user_id ?? payload.userId ?? nested?.user_id ?? nested?.userId;
  return typeof value === "string" && value.trim() ? value.trim() : typeof value === "number" ? String(value) : undefined;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const secret = getWebhookAppSecret();
  if (!secret) return NextResponse.json({ error: "Callback de exclusão ainda não está configurado." }, { status: 503 });
  const signedRequest = await readSignedRequest(request);
  const payload = signedRequest ? verifySignedRequest(signedRequest, secret) : undefined;
  const userId = payload && subjectId(payload);
  if (!payload || !userId) return NextResponse.json({ error: "signed_request inválido." }, { status: 400 });

  const deletion = await operationQueue.requestDeletion({ subjectId: userId, reason: "Callback de exclusão de dados da Meta." });
  const statusUrl = new URL(request.url);
  statusUrl.search = "";
  statusUrl.searchParams.set("code", deletion.id);
  return NextResponse.json({ url: statusUrl.toString(), confirmation_code: deletion.id }, { status: 200 });
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  const code = request.nextUrl.searchParams.get("code");
  if (!code) return NextResponse.json({ service: "manycgat", status: "ready" }, { headers: { "cache-control": "no-store" } });
  const database = await operationQueue.snapshot();
  const deletion = database.deletionRequests.find((item) => item.id === code);
  if (!deletion) return NextResponse.json({ error: "Código de confirmação não encontrado." }, { status: 404 });
  return NextResponse.json({ confirmation_code: deletion.id, status: deletion.status }, { headers: { "cache-control": "no-store" } });
}
