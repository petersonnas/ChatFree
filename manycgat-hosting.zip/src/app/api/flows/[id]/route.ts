import { NextRequest, NextResponse } from "next/server";
import { archiveFlow, getFlow, updateFlow } from "../../../../lib/server/flow-repository";
import { errorResponse, notFound, readJson } from "../../../../lib/server/http";

type Context = { params: Promise<{ id: string }> };
async function id(context: Context) { return (await context.params).id; }

export async function GET(_request: NextRequest, context: Context): Promise<NextResponse> {
  try { const flow = await getFlow(await id(context)); return flow ? NextResponse.json({ data: flow }) : notFound("Fluxo"); } catch (error) { return errorResponse(error); }
}
export async function PATCH(request: NextRequest, context: Context): Promise<NextResponse> {
  try { const flow = await updateFlow(await id(context), await readJson(request) as never); return flow ? NextResponse.json({ data: flow }) : notFound("Fluxo"); } catch (error) { return errorResponse(error); }
}
export async function DELETE(_request: NextRequest, context: Context): Promise<NextResponse> {
  try { const archived = await archiveFlow(await id(context)); return archived ? NextResponse.json({ data: { archived: true } }) : notFound("Fluxo"); } catch (error) { return errorResponse(error); }
}
