import { NextRequest, NextResponse } from "next/server";
import { createFlow, listFlows } from "../../../lib/server/flow-repository";
import { errorResponse, readJson } from "../../../lib/server/http";

export async function GET(): Promise<NextResponse> {
  try { return NextResponse.json({ data: await listFlows() }); } catch (error) { return errorResponse(error); }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try { return NextResponse.json({ data: await createFlow(await readJson(request) as never) }, { status: 201 }); } catch (error) { return errorResponse(error); }
}
