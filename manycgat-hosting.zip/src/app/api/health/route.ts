import { NextResponse } from "next/server";
import { jsonStore } from "../../../lib/server/json-store";
import { getInstagramIntegrationStatus } from "../../../lib/server/instagram";
import { operationQueue } from "../../../lib/server/operation-queue";

export async function GET(): Promise<NextResponse> {
  const storage = await jsonStore.health();
  const queue = await operationQueue.health();
  const integration = getInstagramIntegrationStatus();
  const healthy = storage.ready && queue.ready;
  return NextResponse.json(
    {
      status: healthy ? "ok" : "degraded",
      database: "json",
      storage: {
        ready: storage.ready,
        cached: storage.cached,
        pendingWrites: storage.pendingWrites,
        lastLoadedAt: storage.lastLoadedAt,
        lastWriteAt: storage.lastWriteAt,
      },
      instagram: integration,
      operations: {
        ready: queue.ready,
        pendingWrites: queue.pendingWrites,
        counts: queue.counts,
        sendsPerMinute: queue.sendsPerMinute,
      },
      timestamp: new Date().toISOString(),
    },
    { status: healthy ? 200 : 503 },
  );
}
