import { NextRequest, NextResponse } from "next/server";
import { errorResponse, notFound, readJson } from "../../../../../lib/server/http";
import { parseManualMessage, sendInboxMessage } from "../../../../../lib/server/inbox-repository";

type RouteContext = { params: { id: string } | Promise<{ id: string }> };

async function routeId(context: RouteContext): Promise<string> {
  return (await context.params).id;
}

export async function POST(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const result = await sendInboxMessage(await routeId(context), parseManualMessage(await readJson(request)));
    if (!result) return notFound("Conversa");
    return NextResponse.json({ data: result }, { status: result.idempotent ? 200 : 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
