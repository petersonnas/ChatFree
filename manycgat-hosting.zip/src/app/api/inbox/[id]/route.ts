import { NextRequest, NextResponse } from "next/server";
import { errorResponse, notFound, readJson } from "../../../../lib/server/http";
import { getInbox, parseInboxPatch, updateInbox } from "../../../../lib/server/inbox-repository";

type RouteContext = { params: { id: string } | Promise<{ id: string }> };

async function routeId(context: RouteContext): Promise<string> {
  return (await context.params).id;
}

export async function GET(_request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const detail = await getInbox(await routeId(context));
    return detail ? NextResponse.json({ data: detail }) : notFound("Conversa");
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const detail = await updateInbox(await routeId(context), parseInboxPatch(await readJson(request)));
    return detail ? NextResponse.json({ data: detail }) : notFound("Conversa");
  } catch (error) {
    return errorResponse(error);
  }
}
