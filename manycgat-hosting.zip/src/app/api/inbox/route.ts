import { NextRequest, NextResponse } from "next/server";
import { errorResponse } from "../../../lib/server/http";
import { listInbox, parseInboxListQuery } from "../../../lib/server/inbox-repository";

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const params = request.nextUrl.searchParams;
    const query = parseInboxListQuery({ status: params.get("status"), q: params.get("q"), tag: params.get("tag") });
    return NextResponse.json({ data: await listInbox(query) });
  } catch (error) {
    return errorResponse(error);
  }
}
