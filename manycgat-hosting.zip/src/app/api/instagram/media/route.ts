import { NextRequest, NextResponse } from "next/server";
import { listInstagramMedia } from "../../../../lib/server/instagram";

export async function GET(request: NextRequest) {
  const after = request.nextUrl.searchParams.get("after") ?? undefined;
  if (after && (after.length > 2048 || /[\r\n]/.test(after))) return NextResponse.json({ error: "Cursor de paginação inválido." }, { status: 400 });
  try {
    return NextResponse.json(await listInstagramMedia(after));
  } catch {
    return NextResponse.json({ error: "Não foi possível carregar as publicações. Confira o token e as permissões da conta em Configurações." }, { status: 502 });
  }
}
