import { NextRequest, NextResponse } from "next/server";
import { HttpError, errorResponse } from "../../../../../lib/server/http";
import { recordLinkClick } from "../../../../../lib/server/repository";

type RouteContext = { params: { id: string } | Promise<{ id: string }> };

export async function POST(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const { id } = await context.params;
    let visitorId: string | undefined;
    try {
      const body = await request.json() as { visitorId?: unknown };
      if (typeof body.visitorId === "string" && body.visitorId.length <= 200) visitorId = body.visitorId;
    } catch {
      // O corpo é opcional para o contador de cliques.
    }

    const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
    const userAgent = request.headers.get("user-agent") ?? "";
    const visitorIdentity = visitorId ?? (forwarded ? `${forwarded}:${userAgent}` : undefined);
    const link = await recordLinkClick(id, visitorIdentity);
    if (!link) throw new HttpError(404, "Link não encontrado ou inativo.");
    return NextResponse.json({ data: { id: link.id, clicks: link.clicks, uniqueClicks: link.uniqueClicks, url: link.url } });
  } catch (error) {
    return errorResponse(error);
  }
}
