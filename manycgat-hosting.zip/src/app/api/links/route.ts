import { NextRequest, NextResponse } from "next/server";
import { createLink, listLinks } from "../../../lib/server/repository";
import { errorResponse, readJson } from "../../../lib/server/http";
import { parseLinkDraft } from "../../../lib/server/validation";

export async function GET(): Promise<NextResponse> {
  try {
    return NextResponse.json({ data: await listLinks() });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    return NextResponse.json({ data: await createLink(parseLinkDraft(await readJson(request))) }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
