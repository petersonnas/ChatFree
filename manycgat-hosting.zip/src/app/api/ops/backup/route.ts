import { NextRequest, NextResponse } from "next/server";
import { jsonStore } from "../../../../lib/server/json-store";
import { requireOperationsAccess } from "../../../../lib/server/operation-auth";
import { operationQueue } from "../../../../lib/server/operation-queue";

export const runtime = "nodejs";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;
  const [database, operations] = await Promise.all([jsonStore.snapshot(), operationQueue.snapshot()]);
  const payload = { exportedAt: new Date().toISOString(), database, operations };
  return NextResponse.json(payload, {
    headers: {
      "cache-control": "no-store",
      "content-disposition": `attachment; filename="manycgat-backup-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
