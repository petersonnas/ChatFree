export { GET, POST } from "../../data-deletion/route";
export const runtime = "nodejs";
