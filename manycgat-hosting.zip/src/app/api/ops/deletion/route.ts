import { NextRequest, NextResponse } from "next/server";
import { requireOperationsAccess } from "../../../../lib/server/operation-auth";
import { operationQueue } from "../../../../lib/server/operation-queue";

export const runtime = "nodejs";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;
  const database = await operationQueue.snapshot();
  return NextResponse.json({ data: database.deletionRequests }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;
  const body = await request.json().catch(() => null) as { subjectId?: unknown; reason?: unknown } | null;
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Corpo inválido." }, { status: 400 });
  const subjectId = body.subjectId === undefined ? undefined : typeof body.subjectId === "string" ? body.subjectId.trim() : null;
  const reason = body.reason === undefined ? undefined : typeof body.reason === "string" ? body.reason.trim() : null;
  if (subjectId === null || reason === null || subjectId && subjectId.length > 200 || reason && reason.length > 1_000) {
    return NextResponse.json({ error: "Solicitação de exclusão inválida." }, { status: 400 });
  }
  const requestRecord = await operationQueue.requestDeletion({ subjectId, reason });
  return NextResponse.json({ data: requestRecord }, { status: 202 });
}
