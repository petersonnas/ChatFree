import { NextRequest, NextResponse } from "next/server";
import { jsonStore } from "../../../../lib/server/json-store";
import { getInstagramIntegrationDiagnostics } from "../../../../lib/server/instagram";
import { operationQueue } from "../../../../lib/server/operation-queue";
import { requireOperationsAccess } from "../../../../lib/server/operation-auth";

export const runtime = "nodejs";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;

  const [storage, queue, operations] = await Promise.all([jsonStore.health(), operationQueue.health(), operationQueue.snapshot()]);
  const recentWebhooks = operations.webhooks.slice(0, 20);
  return NextResponse.json({
    status: storage.ready && queue.ready ? "ok" : "degraded",
    timestamp: new Date().toISOString(),
    storage: {
      ready: storage.ready,
      cached: storage.cached,
      pendingWrites: storage.pendingWrites,
      filePath: storage.filePath,
      lastLoadedAt: storage.lastLoadedAt,
      lastWriteAt: storage.lastWriteAt,
    },
    integration: getInstagramIntegrationDiagnostics(),
    queue: {
      filePath: queue.filePath,
      sendsPerMinute: queue.sendsPerMinute,
      counts: queue.counts,
      lastLoadedAt: queue.lastLoadedAt,
      lastWriteAt: queue.lastWriteAt,
    },
    webhooks: {
      total: operations.webhooks.length,
      accepted: operations.webhooks.filter((item) => item.accepted).length,
      duplicates: operations.webhooks.filter((item) => item.duplicate).length,
      recent: recentWebhooks.map(({ fingerprint: _fingerprint, ...item }) => item),
    },
  }, { headers: { "cache-control": "no-store" } });
}
