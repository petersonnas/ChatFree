import { NextRequest, NextResponse } from "next/server";
import { errorResponse } from "../../../../lib/server/http";
import { requireOperationsAccess } from "../../../../lib/server/operation-auth";
import { operationQueue } from "../../../../lib/server/operation-queue";
import { processPendingSendOperations } from "../../../../lib/server/operation-dispatcher";

export const runtime = "nodejs";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;
  const [health, database] = await Promise.all([operationQueue.health(), operationQueue.snapshot()]);
  return NextResponse.json({
    data: database.sends,
    counts: health.counts,
    sendsPerMinute: health.sendsPerMinute,
  }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const denied = await requireOperationsAccess(request);
  if (denied) return denied as NextResponse;
  try {
    const body = await request.json().catch(() => ({})) as { limit?: unknown };
    const limit = typeof body.limit === "number" && Number.isFinite(body.limit) ? Math.max(1, Math.min(Math.floor(body.limit), 100)) : 20;
    const results = await processPendingSendOperations({ limit });
    const health = await operationQueue.health();
    return NextResponse.json({ data: results, counts: health.counts }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}
