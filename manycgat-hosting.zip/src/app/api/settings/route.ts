import { NextRequest, NextResponse } from "next/server";
import { getSettings, updateSettings, type AppSettings } from "../../../lib/server/settings-store";

const allowedTimezones = new Set(["America/Sao_Paulo", "America/New_York", "Europe/Lisbon"]);

export async function GET(): Promise<NextResponse> {
  return NextResponse.json({ data: await getSettings() });
}

export async function PATCH(request: NextRequest): Promise<NextResponse> {
  const body = (await request.json().catch(() => null)) as Partial<AppSettings> | null;
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Corpo inválido." }, { status: 400 });
  const patch: Partial<AppSettings> = {};

  if (body.name !== undefined) {
    if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.length > 120) return NextResponse.json({ error: "Nome inválido." }, { status: 400 });
    patch.name = body.name.trim();
  }
  if (body.username !== undefined) {
    if (typeof body.username !== "string" || body.username.trim().length < 2 || body.username.length > 80) return NextResponse.json({ error: "Usuário inválido." }, { status: 400 });
    patch.username = body.username.trim().replace(/^@/, "");
  }
  if (body.email !== undefined) {
    if (typeof body.email !== "string" || !/^\S+@\S+\.\S+$/.test(body.email)) return NextResponse.json({ error: "E-mail inválido." }, { status: 400 });
    patch.email = body.email.trim();
  }
  if (body.timezone !== undefined) {
    if (typeof body.timezone !== "string" || !allowedTimezones.has(body.timezone)) return NextResponse.json({ error: "Fuso horário inválido." }, { status: 400 });
    patch.timezone = body.timezone;
  }

  return NextResponse.json({ data: await updateSettings(patch) });
}
