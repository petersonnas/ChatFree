import { NextRequest, NextResponse } from "next/server";
import { getWebhookVerifyToken } from "../../../../lib/server/instagram";
import { errorResponse } from "../../../../lib/server/http";
import { operationQueue } from "../../../../lib/server/operation-queue";
import { processInstagramWebhookPayload, verifyMetaSignature, webhookPayloadFingerprint, normalizeInstagramPayload } from "../../../../lib/server/webhook";

export async function GET(request: NextRequest): Promise<NextResponse> {
  const mode = request.nextUrl.searchParams.get("hub.mode");
  const token = request.nextUrl.searchParams.get("hub.verify_token");
  const challenge = request.nextUrl.searchParams.get("hub.challenge");
  const expected = getWebhookVerifyToken();

  if (mode === "subscribe" && expected && token === expected && challenge) {
    return new NextResponse(challenge, { status: 200 });
  }
  return NextResponse.json({ error: "Verificação do webhook recusada." }, { status: 403 });
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const rawBody = await request.text();
  const fingerprint = webhookPayloadFingerprint(rawBody);
  let receipt: Awaited<ReturnType<typeof operationQueue.recordWebhook>> | undefined;
  try {
    if (!verifyMetaSignature(rawBody, request.headers.get("x-hub-signature-256"))) {
      await operationQueue.recordWebhook({ fingerprint, accepted: false, error: "Assinatura inválida." });
      return NextResponse.json({ error: "Assinatura do webhook inválida." }, { status: 401 });
    }

    let payload: unknown;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      await operationQueue.recordWebhook({ fingerprint, accepted: false, error: "JSON inválido." });
      return NextResponse.json({ error: "Corpo do webhook inválido." }, { status: 400 });
    }
    const events = normalizeInstagramPayload(payload);
    receipt = await operationQueue.recordWebhook({ fingerprint, accepted: true, eventCount: events.length });
    if (receipt.duplicate) {
      await operationQueue.completeWebhook(receipt.id, { eventCount: events.length });
      return NextResponse.json({ data: { received: events.length, processed: 0, ignored: 0, duplicates: events.length, mocked: 0, failed: 0, queued: 0 } }, { status: 200 });
    }
    const summary = await processInstagramWebhookPayload(payload);
    await operationQueue.completeWebhook(receipt.id, { eventCount: summary.received });
    return NextResponse.json({ data: summary }, { status: 200 });
  } catch (error) {
    if (receipt) await operationQueue.completeWebhook(receipt.id, { eventCount: receipt.eventCount ?? 0, error: "Falha no processamento." }).catch(() => undefined);
    return errorResponse(error);
  }
}
