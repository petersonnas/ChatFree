import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Conversa | Automação para Instagram",
  description: "Automatize comentários, mensagens e links do seu Instagram em um painel simples.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
