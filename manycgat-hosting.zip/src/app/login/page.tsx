"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";

export default function LoginPage() {
  const [accessKey, setAccessKey] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ accessKey }),
      });
      if (!response.ok) throw new Error("Chave inválida");
      const next = new URLSearchParams(window.location.search).get("next") || "/dashboard";
      window.location.assign(next.startsWith("/") ? next : "/dashboard");
    } catch {
      setError("Não foi possível entrar. Confira a chave de acesso.");
      setLoading(false);
    }
  }

  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "#f7f8fa" }}>
      <section style={{ width: "min(100%, 410px)", padding: 32, border: "1px solid #e4e7ec", borderRadius: 18, background: "#fff", boxShadow: "0 18px 42px rgba(20, 34, 56, 0.08)" }}>
        <div style={{ width: 40, height: 40, display: "grid", placeItems: "center", marginBottom: 20, borderRadius: 12, background: "#182230", color: "#fff", fontWeight: 800 }}>ia</div>
        <p style={{ margin: "0 0 8px", color: "#697586", fontSize: 12, fontWeight: 700, letterSpacing: ".08em", textTransform: "uppercase" }}>Área privada</p>
        <h1 style={{ margin: "0 0 10px", color: "#182230", fontSize: 28, letterSpacing: "-.04em" }}>Entrar no painel</h1>
        <p style={{ margin: "0 0 24px", color: "#697586", lineHeight: 1.6 }}>Digite a chave de acesso configurada no ambiente do app.</p>
        <form onSubmit={submit} style={{ display: "grid", gap: 14 }}>
          <label style={{ display: "grid", gap: 7, color: "#344054", fontSize: 13, fontWeight: 650 }}>
            Chave de acesso
            <input autoFocus type="password" value={accessKey} onChange={(event) => setAccessKey(event.target.value)} style={{ minHeight: 44, padding: "0 12px", border: "1px solid #d0d5dd", borderRadius: 10, color: "#182230", outline: "none" }} />
          </label>
          {error && <p role="alert" style={{ margin: 0, color: "#c33d4d", fontSize: 13 }}>{error}</p>}
          <button type="submit" disabled={loading || !accessKey} style={{ minHeight: 44, border: 0, borderRadius: 10, background: "#0b72e7", color: "#fff", fontWeight: 700, opacity: loading || !accessKey ? .65 : 1 }}>{loading ? "Entrando…" : "Entrar"}</button>
        </form>
        <Link href="/" style={{ display: "inline-block", marginTop: 22, color: "#0b72e7", fontSize: 13, fontWeight: 650 }}>Voltar para a página inicial</Link>
      </section>
    </main>
  );
}
