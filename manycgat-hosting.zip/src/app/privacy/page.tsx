import Link from "next/link";

import { MarketingFrame } from "../../components/marketing/MarketingFrame";
import styles from "../../components/marketing/marketing.module.css";

export const metadata = {
  title: "Privacidade | Automação para Instagram",
  description: "Como o app pessoal trata dados de comentários, mensagens e integrações com o Instagram.",
};

const sections = [
  ["escopo", "Escopo"],
  ["dados", "Dados coletados"],
  ["uso", "Finalidades"],
  ["integracao", "Integração com Instagram"],
  ["armazenamento", "Armazenamento e retenção"],
  ["direitos", "Direitos e contato"],
];

const contactEmail = process.env.PUBLIC_CONTACT_EMAIL?.trim();

export default function PrivacyPage() {
  return (
    <MarketingFrame>
      <div className={styles.contentWidth}>
        <div className={styles.legalPage}>
          <header className={styles.legalHero}>
            <p className={styles.legalEyebrow}>Transparência</p>
            <h1>Política de privacidade</h1>
            <p className={styles.legalLead}>
              Esta página explica, em linguagem simples, como o app pessoal trata informações usadas para automatizar comentários e mensagens do Instagram.
            </p>
            <p className={styles.legalMeta}>Última atualização: 22 de setembro de 2026</p>
            <div className={styles.legalNotice}>
              Este é um modelo público para o app pessoal. Antes da publicação, preencha o contato indicado nesta página e revise o conteúdo com base no ambiente final, nas permissões aprovadas pela Meta e nas regras aplicáveis ao seu uso.
            </div>
          </header>

          <div className={styles.legalLayout}>
            <nav className={styles.legalToc} aria-label="Nesta política">
              {sections.map(([id, label]) => (
                <Link href={`#${id}`} key={id}>
                  {label}
                </Link>
              ))}
              <Link href="#limitacoes">Limitações</Link>
            </nav>

            <article className={styles.legalContent}>
              <section id="escopo">
                <h2>1. Escopo</h2>
                <p>
                  O app é uma ferramenta de uso pessoal e interno, conectada a uma única conta profissional do Instagram. Ele permite configurar automações, receber eventos autorizados pela Meta e registrar métricas operacionais do próprio uso.
                </p>
                <p>
                  Esta política se aplica às informações processadas pelo painel, pelos serviços do app e pelos webhooks usados para receber eventos do Instagram.
                </p>
              </section>

              <section id="dados">
                <h2>2. Dados coletados</h2>
                <p>O app pode processar somente os dados necessários para executar uma automação configurada:</p>
                <ul>
                  <li>Identificadores públicos de conta, publicação, comentário ou conversa enviados pela plataforma.</li>
                  <li>Nome de usuário, texto do comentário e conteúdo da mensagem quando esses dados estiverem disponíveis no evento autorizado.</li>
                  <li>Configurações de automação, palavras-chave, mensagens, botões e links criados no painel.</li>
                  <li>Eventos técnicos, como envio, falha, entrega, clique em link e data da execução.</li>
                  <li>Credenciais e tokens necessários para a integração, mantidos separadamente dos dados operacionais.</li>
                </ul>
                <p>O app não deve pedir senha do Instagram, dados de cartão, documento de identidade ou informações que não sejam necessárias para esse fluxo.</p>
              </section>

              <section id="uso">
                <h2>3. Para que os dados são usados</h2>
                <ul>
                  <li>Receber e reconhecer comentários, mensagens e outros eventos permitidos pela integração.</li>
                  <li>Executar respostas e mensagens que foram configuradas pelo proprietário da conta.</li>
                  <li>Contabilizar mensagens enviadas, cliques, falhas e execuções para o dashboard.</li>
                  <li>Diagnosticar erros, evitar duplicidade de envio e manter a operação estável.</li>
                </ul>
                <p>Os dados não devem ser vendidos, usados para publicidade de terceiros ou compartilhados para finalidades incompatíveis com a automação da conta.</p>
              </section>

              <section id="integracao">
                <h2>4. Integração com o Instagram</h2>
                <p>
                  A conexão depende da API oficial da Meta, das permissões concedidas no Facebook for Developers e das limitações vigentes para contas profissionais. O app recebe apenas os eventos disponibilizados pela plataforma e não controla decisões, bloqueios, limites ou indisponibilidades do Instagram.
                </p>
                <p>
                  Webhooks podem informar que um comentário ou mensagem ocorreu. O app valida a origem do evento, evita processar o mesmo identificador mais de uma vez quando possível e registra o resultado da tentativa.
                </p>
                <p>
                  A solicitação de exclusão de dados da Meta é recebida no callback público <code>/api/data-deletion</code>, que valida o <code>signed_request</code> e devolve um código de confirmação.
                </p>
              </section>

              <section id="armazenamento">
                <h2>5. Armazenamento e retenção</h2>
                <h3>Banco em JSON</h3>
                <p>
                  O armazenamento operacional é baseado em arquivos JSON por ser um projeto pessoal e de uma única conta. Os arquivos devem ficar fora da pasta pública do servidor, com permissões restritas e cópias de segurança controladas.
                </p>
                <h3>Tokens e segredos</h3>
                <p>
                  Tokens de acesso, segredos de webhook e outras credenciais não devem ser armazenados em JSON público, versionados no repositório ou enviados ao navegador. Eles devem ficar em variáveis protegidas do ambiente de execução, com rotação quando necessário.
                </p>
                <h3>Retenção</h3>
                <p>
                  A retenção deve ser limitada ao período necessário para operar as automações e consultar métricas. Registros antigos, dados de testes e eventos duplicados devem ser revisados e removidos periodicamente. Defina no ambiente final um prazo concreto para logs e backups antes de publicar esta política.
                </p>
              </section>

              <section id="direitos">
                <h2>6. Direitos e solicitações</h2>
                <p>
                  Como o app é pessoal, o proprietário da conta administra diretamente a maior parte dos dados. Uma pessoa que interaja com a conta pode solicitar informações sobre o tratamento, correção ou exclusão de dados relacionados à interação, respeitando registros que precisem ser mantidos por segurança ou obrigação legal.
                </p>
                <p>
                  Para uma solicitação, use o contato que será preenchido pelo responsável do app:
                </p>
                <div className={styles.callout} id="contato">
                  <p><strong>Contato:</strong> {contactEmail ? <a href={`mailto:${contactEmail}`}>{contactEmail}</a> : "Configure PUBLIC_CONTACT_EMAIL no ambiente publicado."}</p>
                  <p>Use um canal monitorado e informe um prazo razoável para resposta antes de publicar esta página.</p>
                </div>
              </section>

              <section id="limitacoes">
                <h2>7. Limitações e alterações</h2>
                <p>
                  Nenhum sistema conectado ao Instagram garante disponibilidade contínua, entrega de todas as mensagens ou preservação de eventos fora do controle da API. O uso precisa respeitar as políticas da Meta e as leis aplicáveis ao conteúdo enviado.
                </p>
                <p>
                  Esta política pode ser atualizada quando o app, as permissões ou o fluxo de dados mudarem. A data no topo deve ser atualizada junto com qualquer mudança relevante.
                </p>
                <p>
                  Consulte também a página de <Link href="/security">Segurança</Link> para entender os controles técnicos e os cuidados necessários no ambiente de execução.
                </p>
              </section>
            </article>
          </div>
        </div>
      </div>
    </MarketingFrame>
  );
}
