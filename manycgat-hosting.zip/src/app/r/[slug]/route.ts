import { NextRequest, NextResponse } from "next/server";
import { HttpError } from "../../../lib/server/http";
import { buildTrackedLinkUrl, recordLinkClick } from "../../../lib/server/repository";

export const dynamic = "force-dynamic";

type RouteContext = { params: { slug: string } | Promise<{ slug: string }> };

export async function GET(request: NextRequest, context: RouteContext): Promise<NextResponse> {
  try {
    const { slug } = await context.params;
    const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
    const realIp = request.headers.get("x-real-ip")?.trim();
    const userAgent = request.headers.get("user-agent") ?? "";
    const visitorIdentity = (forwarded || realIp) ? `${forwarded || realIp}:${userAgent}` : undefined;
    const link = await recordLinkClick(slug, visitorIdentity);
    if (!link) throw new HttpError(404, "Link não encontrado.");

    return NextResponse.redirect(new URL(buildTrackedLinkUrl(link)), {
      status: 302,
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    if (error instanceof HttpError && error.statusCode === 404) {
      return NextResponse.json({ error: error.message }, { status: 404, headers: { "Cache-Control": "no-store" } });
    }
    console.error("Tracked link redirect failed", error);
    return NextResponse.json({ error: "Link não encontrado." }, { status: 404, headers: { "Cache-Control": "no-store" } });
  }
}
