import Link from "next/link";

import { MarketingFrame } from "../../components/marketing/MarketingFrame";
import styles from "../../components/marketing/marketing.module.css";

export const metadata = {
  title: "Segurança | Automação para Instagram",
  description: "Princípios de segurança para o app pessoal de automação do Instagram.",
};

const sections = [
  ["principios", "Princípios"],
  ["acesso", "Acesso ao painel"],
  ["credenciais", "Tokens e webhooks"],
  ["dados", "Dados e JSON"],
  ["operacao", "Operação e resposta"],
  ["limites", "Limitações"],
];

export default function SecurityPage() {
  return (
    <MarketingFrame>
      <div className={styles.contentWidth}>
        <div className={styles.legalPage}>
          <header className={styles.legalHero}>
            <p className={styles.legalEyebrow}>Proteção do app</p>
            <h1>Segurança</h1>
            <p className={styles.legalLead}>
              O app foi pensado para uma conta pessoal: poucos usuários, escopo reduzido e controle direto sobre o ambiente que executa as automações.
            </p>
            <p className={styles.legalMeta}>Última atualização: 22 de setembro de 2026</p>
            <div className={styles.legalNotice}>
              Os controles abaixo descrevem a configuração esperada do ambiente. Antes de publicar, confirme quais itens estão realmente ativos no servidor, no provedor de hospedagem e no app da Meta.
            </div>
          </header>

          <div className={styles.legalLayout}>
            <nav className={styles.legalToc} aria-label="Nesta página">
              {sections.map(([id, label]) => (
                <Link href={`#${id}`} key={id}>
                  {label}
                </Link>
              ))}
            </nav>

            <article className={styles.legalContent}>
              <section id="principios">
                <h2>1. Princípios</h2>
                <p>
                  A segurança do projeto parte de quatro decisões: limitar o acesso, guardar segredos fora dos dados operacionais, registrar apenas o necessário e revisar o fluxo quando a integração mudar.
                </p>
                <div className={styles.principlesGrid}>
                  <article className={styles.principleCard}>
                    <h3>Escopo mínimo</h3>
                    <p>Solicite na Meta somente as permissões indispensáveis para comentários, mensagens e métricas do fluxo.</p>
                  </article>
                  <article className={styles.principleCard}>
                    <h3>Segredos isolados</h3>
                    <p>Mantenha tokens, chaves e segredos de webhook no ambiente do servidor, longe do navegador e do repositório.</p>
                  </article>
                  <article className={styles.principleCard}>
                    <h3>Dados mínimos</h3>
                    <p>Guarde o que ajuda a executar, deduplicar e medir uma automação, com limpeza periódica dos registros antigos.</p>
                  </article>
                  <article className={styles.principleCard}>
                    <h3>Revisão manual</h3>
                    <p>Confira automações, links e permissões antes de ativar um fluxo que possa enviar muitas mensagens.</p>
                  </article>
                </div>
              </section>

              <section id="acesso">
                <h2>2. Acesso ao painel</h2>
                <p>
                  O dashboard deve ficar protegido por autenticação e por uma sessão segura. Como o uso é pessoal, o acesso pode ser restrito a uma única identidade autorizada, sem cadastro público e sem compartilhamento de credenciais.
                </p>
                <ul>
                  <li>Use HTTPS em todas as páginas e chamadas de API.</li>
                  <li>Proteja cookies de sessão com as opções HttpOnly, Secure e SameSite adequadas ao ambiente.</li>
                  <li>Evite deixar o painel administrativo aberto em uma URL pública sem autenticação.</li>
                  <li>Revise acessos e encerre sessões quando houver troca de máquina ou suspeita de exposição.</li>
                </ul>
              </section>

              <section id="credenciais">
                <h2>3. Tokens e webhooks</h2>
                <p>
                  Tokens de acesso do Instagram, segredos do app e a assinatura de webhook são credenciais sensíveis. Eles não devem aparecer em componentes do front-end, mensagens de erro, logs públicos, arquivos JSON versionados ou respostas da API para o navegador.
                </p>
                <ul>
                  <li>Valide a assinatura e a origem de cada webhook antes de processar o conteúdo.</li>
                  <li>Use identificadores de evento para evitar executar duas vezes a mesma automação.</li>
                  <li>Faça rotação e revogação de tokens quando eles forem expostos, perderem validade ou deixarem de ser necessários.</li>
                  <li>Restrinja o acesso às variáveis de ambiente e aos backups que possam contê-las.</li>
                </ul>
              </section>

              <section id="dados">
                <h2>4. Dados e armazenamento em JSON</h2>
                <p>
                  O uso de JSON é adequado para um projeto pessoal de baixo número de operadores, desde que a escrita seja controlada pelo servidor e que os arquivos não possam ser baixados diretamente pela web.
                </p>
                <ul>
                  <li>Coloque os arquivos de dados fora da pasta pública ou bloqueie explicitamente o acesso direto.</li>
                  <li>Serialize escritas concorrentes e prefira gravação atômica para reduzir o risco de arquivo incompleto.</li>
                  <li>Separe configurações, contatos, eventos e métricas para facilitar limpeza, backup e recuperação.</li>
                  <li>Monitore o tamanho dos arquivos e faça rotação de eventos antigos para evitar degradação com milhares de DMs mensais.</li>
                  <li>Criptografe ou proteja os backups que contenham identificadores, conversas ou tokens.</li>
                </ul>
              </section>

              <section id="operacao">
                <h2>5. Operação e resposta</h2>
                <p>
                  O responsável pelo app deve acompanhar falhas de envio, respostas duplicadas, mudanças de permissão e notificações da Meta. Alertas simples no painel ajudam a interromper um fluxo antes que ele continue enviando mensagens incorretas.
                </p>
                <div className={styles.callout}>
                  <p><strong>Em caso de suspeita:</strong> pause as automações, revogue ou troque os tokens, preserve os registros técnicos necessários e revise os acessos do ambiente antes de reativar o fluxo.</p>
                </div>
              </section>

              <section id="limites">
                <h2>6. Limitações</h2>
                <p>
                  Nenhuma medida elimina todos os riscos. A disponibilidade, os limites de envio, a entrega e o comportamento da API são controlados em parte pela Meta. Bibliotecas, hospedagem e configurações do ambiente também precisam ser atualizadas pelo responsável.
                </p>
                <p>
                  A página de <Link href="/privacy">Privacidade</Link> explica quais dados podem ser processados e como revisar retenção e contato antes da publicação.
                </p>
              </section>
            </article>
          </div>
        </div>
      </div>
    </MarketingFrame>
  );
}
