import type { AnalyticsSnapshot } from "./analytics-summary";
import { Icon } from "./icons";
import styles from "./links.module.css";

function formatNumber(value: number): string {
  return new Intl.NumberFormat("pt-BR").format(value);
}

export function AnalyticsFunnel({ analytics, loading, error, onRetry }: { analytics: AnalyticsSnapshot | null; loading: boolean; error: string | null; onRetry: () => void }) {
  const maxValue = Math.max(...(analytics?.funnel.map((step) => step.value) ?? [1]), 1);
  return <section className={styles.funnelCard} aria-labelledby="funnel-title"><div className={styles.cardHeader}><div><p className={styles.eyebrow}>Performance</p><h2 className={styles.cardTitle} id="funnel-title">Funil de conversão</h2><p className={styles.cardHint}>Veja como as conversas avançam até o clique no link.</p></div><span className={styles.dataBadge}><Icon name="chart" size={13} /> Últimos 30 dias</span></div><div className={styles.funnelBody}>{loading && <div className={styles.funnelLoading} aria-label="Carregando funil"><span /><span /><span /></div>}{!loading && error && <div className={styles.inlineState} role="alert"><div><strong>Não foi possível carregar o funil.</strong><span>{error}</span></div><button className={styles.textButton} type="button" onClick={onRetry}>Tentar novamente</button></div>}{!loading && !error && analytics?.funnel.length === 0 && <div className={styles.emptyState}>Ainda não há dados de conversão para este período.</div>}{!loading && !error && analytics && analytics.funnel.length > 0 && <div className={styles.funnelSteps}>{analytics.funnel.map((step, index) => <div className={styles.funnelStep} key={step.id}><div className={styles.funnelStepMeta}><span className={styles.funnelStepIndex}>{String(index + 1).padStart(2, "0")}</span><div><strong>{step.label}</strong>{step.description && <span>{step.description}</span>}</div><b>{formatNumber(step.value)}</b></div><div className={styles.funnelBar} aria-hidden="true"><span style={{ width: `${Math.max((step.value / maxValue) * 100, 4)}%` }} /></div></div>)}</div>}</div></section>;
}
