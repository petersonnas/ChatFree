import { Icon } from "./icons";
import styles from "./links.module.css";

export type AnalyticsSnapshot = {
  totalClicks: number | null;
  uniqueClicks: number | null;
  ctr: number | null;
  funnel: Array<{ id: string; label: string; value: number; description?: string }>;
};

function formatNumber(value: number | null): string {
  return value === null ? "—" : new Intl.NumberFormat("pt-BR").format(value);
}

function formatPercent(value: number | null): string {
  return value === null ? "—" : `${value.toFixed(1).replace(".", ",")}%`;
}

export function AnalyticsSummary({ analytics, loading }: { analytics: AnalyticsSnapshot | null; loading: boolean }) {
  const cards = [
    { label: "Cliques totais", value: formatNumber(analytics?.totalClicks ?? null), icon: "click" as const, hint: "Todas as interações registradas" },
    { label: "Cliques únicos", value: formatNumber(analytics?.uniqueClicks ?? null), icon: "user" as const, hint: "Visitantes distintos" },
    { label: "CTR médio", value: formatPercent(analytics?.ctr ?? null), icon: "chart" as const, hint: "Conversão do funil" },
  ];

  return <section className={styles.metricGrid} aria-label="Resumo de desempenho">{cards.map((card) => <article className={styles.metricCard} key={card.label}><div className={styles.metricTop}><span>{card.label}</span><span className={styles.metricIcon}><Icon name={card.icon} size={16} /></span></div>{loading ? <span className={`${styles.skeleton} ${styles.metricSkeleton}`} aria-label={`Carregando ${card.label}`} /> : <strong className={styles.metricValue}>{card.value}</strong>}<span className={styles.metricHint}>{card.hint}</span></article>)}</section>;
}
