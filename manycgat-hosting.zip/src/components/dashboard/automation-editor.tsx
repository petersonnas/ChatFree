"use client";

import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import type { Automation } from "../../types/backend";
import type { AutomationTemplate, AutomationTrigger, QuickAutomation, QuickAutomationDraft } from "../../lib/automation-templates";
import { PhonePreview, type PreviewTab } from "./phone-preview";
import { actionLabels, actionOf, changeAction, draftFromEditor, hydrateEditor, readApi, saveMismatch, triggerLabels, validateEditor, type EditorAction, type EditorState } from "./quick-automation-state";
import { LinkPicker, MediaPicker, useEditorResources } from "./quick-automation-resources";
import styles from "./quick-automation.module.css";

const statusLabels = { draft: "Rascunho", active: "Ativa", paused: "Pausada", archived: "Arquivada" };
const triggers: Array<{ type: AutomationTrigger["type"]; title: string; description: string; disabled?: boolean }> = [
  { type: "comment_any", title: "Comentário em publicação ou Reel", description: "Transforme o interesse no seu conteúdo em uma conversa." },
  { type: "dm_received", title: "Mensagem direta recebida", description: "Responda quando alguém iniciar uma conversa no direct." },
  { type: "story_reply", title: "Resposta ao seu story", description: "Quando alguém responder a um story seu." },
  { type: "story_mention", title: "Menção no story de alguém", description: "Quando seu perfil for mencionado em outro story." },
  { type: "new_follower", title: "Novo seguidor · indisponível", description: "O Instagram não disponibiliza esse evento nesta integração.", disabled: true },
];
function Section({ number, title, description, children }: { number: string; title: string; description: string; children: ReactNode }) {
  return <section className={styles.section}><div className={styles.sectionHeader}><span className={styles.number}>{number}</span><div><h2>{title}</h2><p>{description}</p></div></div>{children}</section>;
}
function Toggle({ title, description, checked, onChange }: { title: string; description?: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <div className={styles.toggle}><div><strong>{title}</strong>{description && <p>{description}</p>}</div><button type="button" role="switch" aria-label={title} aria-checked={checked} className={styles.switch} onClick={() => onChange(!checked)} /></div>;
}
function MessageField({ label, value, onChange }: { label: string; value?: string; onChange: (value: string) => void }) {
  return <label className={styles.field}><span>{label}</span><textarea value={value ?? ""} maxLength={1000} onChange={(event) => onChange(event.target.value)} /><small className={styles.hint}>{value?.length ?? 0}/1000</small></label>;
}
export function AutomationEditor({ automation, template, templateError }: { automation?: Automation; template?: AutomationTemplate; templateError?: string }) {
  return <EditorSession key={automation?.id ?? template?.id ?? "new"} automation={automation} template={template} templateError={templateError} />;
}
function EditorSession({ automation, template, templateError }: { automation?: QuickAutomation; template?: AutomationTemplate; templateError?: string }) {
  const router = useRouter();
  const resources = useEditorResources();
  const [form, setForm] = useState(() => hydrateEditor(automation ?? template?.config));
  const [persisted, setPersisted] = useState(automation);
  const recordId = useRef(automation?.id);
  const saveLock = useRef(false);
  const [saving, setSaving] = useState(false);
  const [linkBusy, setLinkBusy] = useState(false);
  const [uncertainCreation, setUncertainCreation] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [tab, setTab] = useState<"config" | "history">("config");
  const [previewTab, setPreviewTab] = useState<PreviewTab>("DM");
  const tabsId = useId();
  const busy = saving || linkBusy;
  const isComment = form.trigger.type === "comment_any" || form.trigger.type === "comment_keyword";
  const opening = actionOf(form, "send_dm"), delivery = actionOf(form, "send_link"), reply = actionOf(form, "public_reply");
  const follow = actionOf(form, "request_follow"), email = actionOf(form, "request_email"), reminder = actionOf(form, "reminder");
  const selectedLink = resources.links.find((link) => link.id === delivery?.linkId);
  const selectedMedia = form.trigger.media ?? resources.media.find((media) => media.id === form.trigger.mediaId);
  const variants = reply?.variants ?? [reply?.message ?? "", "", ""];
  const currentStatus = persisted?.status ?? "draft";
  useEffect(() => {
    if (!automation?.id) return;
    try {
      const message = sessionStorage.getItem(`automation-saved:${automation.id}`);
      if (message) { setSuccess(message); sessionStorage.removeItem(`automation-saved:${automation.id}`); }
    } catch { /* Feedback across navigation is optional. */ }
  }, [automation?.id]);
  function update(transform: (state: EditorState) => EditorState) { setForm(transform); setDirty(true); setError(""); setSuccess(""); }
  function updateAction(type: EditorAction["type"], patch: Partial<EditorAction>) { update((current) => changeAction(current, type, patch)); }
  function scope(value: NonNullable<AutomationTrigger["mediaScope"]>) {
    update((current) => ({ ...current, trigger: { ...current.trigger, mediaScope: value, ...(value !== "specific" ? { media: undefined, mediaId: undefined } : {}) } }));
  }
  async function save(status: QuickAutomationDraft["status"]) {
    if (saveLock.current || linkBusy || uncertainCreation) return;
    const draft = draftFromEditor(form, status);
    const invalid = validateEditor(draft);
    if (invalid) { setError(invalid); setSuccess(""); return; }
    saveLock.current = true; setSaving(true); setError(""); setSuccess("");
    const creating = !recordId.current;
    let definitiveResponse = false;
    try {
      const response = await fetch(recordId.current ? `/api/automations/${encodeURIComponent(recordId.current)}` : "/api/automations", {
        method: recordId.current ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft),
      });
      definitiveResponse = !response.ok;
      const result = await readApi<{ data: QuickAutomation }>(response);
      if (!result.data?.id) throw new Error("O servidor não retornou o identificador da automação. O salvamento não pôde ser confirmado.");
      recordId.current = result.data.id; definitiveResponse = true;
      if (!result.data.trigger || !Array.isArray(result.data.actions)) throw new Error("O servidor retornou uma automação incompleta. Recarregue o registro.");
      const mismatch = saveMismatch(draft, result.data);
      if (mismatch) throw new Error(mismatch);
      setPersisted(result.data); setForm(hydrateEditor(result.data)); setDirty(false);
      await resources.refreshLinks().catch(() => undefined);
      const message = `${status === "active" ? "Automação ativada" : status === "paused" ? "Automação pausada" : "Rascunho salvo"} com sucesso.${result.data.revision ? ` Revisão ${result.data.revision}.` : ""}`;
      setSuccess(message);
      if (creating) {
        try { sessionStorage.setItem(`automation-saved:${result.data.id}`, message); } catch { /* Optional feedback. */ }
        router.replace(`/dashboard/automations/${encodeURIComponent(result.data.id)}`);
      }
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : "Não foi possível salvar a automação.";
      if (creating && !definitiveResponse && !recordId.current) {
        setUncertainCreation(true);
        setError(`${message} A resposta da criação não foi confirmada. Confira a lista de automações antes de criar novamente para evitar duplicatas.`);
      } else setError(message);
    } finally { saveLock.current = false; setSaving(false); }
  }
  return <main className={styles.main}>
    <a className={styles.breadcrumb} href="/dashboard/automations">← Automações</a>
    <header className={styles.header}>
      <div><div className={styles.eyebrow}>Instagram · Quick Automation <span className={styles.badge} data-status={currentStatus}>{statusLabels[currentStatus]}</span></div><h1>{automation ? "Editar automação" : "Crie sua próxima conversa"}</h1><p>Do primeiro comentário ao link certo. Do seu jeito.</p></div>
      <div className={styles.actions}>
        <button className={styles.secondary} type="button" disabled={busy || uncertainCreation} onClick={() => void save("draft")}>Salvar rascunho</button>
        {currentStatus === "active" && <button className={styles.secondary} type="button" disabled={busy} onClick={() => void save("paused")}>Pausar</button>}
        <button className={styles.primary} type="button" disabled={busy || uncertainCreation || form.trigger.type === "new_follower"} onClick={() => void save("active")}>{saving ? "Salvando…" : currentStatus === "active" ? "Salvar alterações" : "Ativar automação"}</button>
      </div>
    </header>
    {template && !automation && <p className={styles.notice}>Modelo: <strong>{template.name}</strong>. {template.unavailableReason ?? "Personalize as mensagens e escolha seu link antes de ativar."}</p>}
    {templateError && <p className={styles.notice}>{templateError}</p>}
    {error && <div className={styles.error} role="alert">{error}{uncertainCreation && <> <a href="/dashboard/automations">Ver automações →</a></>}</div>}
    {success && <p className={styles.success} role="status">{success}</p>}
    <div className={styles.tabs} role="tablist" aria-label="Editor de automação">
      {([["config", "Configuração"], ["history", `Histórico${persisted?.versions?.length ? ` (${persisted.versions.length})` : ""}`]] as const).map(([value, label], index) => <button key={value} type="button" id={`${tabsId}-${value}`} role="tab" aria-selected={tab === value} aria-controls={`${tabsId}-panel`} tabIndex={tab === value ? 0 : -1} onClick={() => setTab(value)} onKeyDown={(event) => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
        event.preventDefault(); const next = event.key === "Home" ? "config" : event.key === "End" ? "history" : index === 0 ? "history" : "config";
        setTab(next); document.getElementById(`${tabsId}-${next}`)?.focus();
      }}>{label}</button>)}
    </div>
    <div className={styles.layout}>
      <div id={`${tabsId}-panel`} role="tabpanel" aria-labelledby={`${tabsId}-${tab}`}>
        {tab === "history" ? <div className={styles.history}>
          <section className={styles.section}><h2 className={styles.previewTitle}>Histórico de revisões</h2><p className={styles.hint}>{persisted ? `Versão atual: ${persisted.revision ?? "legada"} · ${persisted.name}` : "Salve a automação para começar seu histórico."}</p><p className={styles.hint}>Cada salvamento registra a configuração anterior. As revisões abaixo são retornadas pelo servidor.</p></section>
          {!persisted?.versions?.length && <p className={styles.hint}>Nenhuma revisão anterior disponível.</p>}
          {[...(persisted?.versions ?? [])].reverse().map((version) => <details key={version.revision}>
            <summary><strong>Revisão {version.revision} · {version.name}</strong><span>{new Date(version.savedAt).toLocaleString("pt-BR")}</span></summary>
            <dl><dt>Gatilho</dt><dd>{triggerLabels[version.trigger.type]}</dd><dt>Palavras-chave</dt><dd>{version.trigger.keywords.join(", ") || "Todas"}</dd><dt>Publicação</dt><dd>{version.trigger.media?.caption || version.trigger.mediaId || (version.trigger.mediaScope === "next" ? "Próxima publicação" : "Qualquer publicação")}</dd>
              {version.actions.map((action) => <div key={action.id}><dt>{actionLabels[action.type]} · {action.enabled ? "Habilitada" : "Desabilitada"}</dt><dd>{action.message}{action.variants && <p>{action.variants.join("\n")}</p>}{action.buttonText && <p>Botão: {action.buttonText}</p>}{action.linkId && <p>Link: {resources.links.find((link) => link.id === action.linkId)?.name ?? action.linkId}</p>}{action.delaySeconds !== undefined && <p>Atraso: {action.delaySeconds}s</p>}</dd></div>)}
            </dl>
          </details>)}
        </div> : <div className={styles.form}>
          <fieldset className={styles.fieldset} disabled={busy}>
            <section className={styles.section}>
              <label className={styles.field}><span>Nome da automação</span><input value={form.name} maxLength={120} onChange={(event) => update((current) => ({ ...current, name: event.target.value }))} /></label>
              <label className={styles.field}><span>Descrição · opcional</span><input value={form.description} maxLength={500} onChange={(event) => update((current) => ({ ...current, description: event.target.value }))} /></label>
            </section>
            <Section number="01" title="Quando a conversa começa" description="Escolha o evento que inicia sua automação.">
              <div className={styles.options}>{triggers.map((option) => <button type="button" key={option.type} className={styles.option} disabled={option.disabled} aria-pressed={form.trigger.type === option.type || (option.type === "comment_any" && isComment)} onClick={() => update((current) => ({ ...current, trigger: { ...current.trigger, type: option.type } }))}><span className={styles.radio} /><span><strong>{option.title}</strong><small>{option.description}</small></span></button>)}</div>
              {form.trigger.type === "new_follower" && <p className={styles.error}>Este gatilho está indisponível. Escolha outro para ativar a automação.</p>}
              {isComment && <>
                <p className={styles.field}>Em qual conteúdo?</p>
                <div className={styles.segmented}>{([["any", "Qualquer publicação"], ["specific", "Uma específica"], ["next", "Próxima publicação"]] as const).map(([value, label]) => <button type="button" key={value} aria-pressed={form.trigger.mediaScope === value} onClick={() => scope(value)}>{label}</button>)}</div>
                {form.trigger.mediaScope === "specific" && <MediaPicker resources={resources} selectedId={form.trigger.mediaId ?? form.trigger.media?.id} onSelect={(media) => update((current) => ({ ...current, trigger: { ...current.trigger, media, mediaId: media.id } }))} />}
                {form.trigger.mediaScope === "next" && <p className={styles.hint}>A automação aguardará sua próxima publicação ou Reel.</p>}
                <div className={styles.segmented}><button type="button" aria-pressed={form.trigger.type === "comment_any"} onClick={() => update((current) => ({ ...current, keywordText: "", trigger: { ...current.trigger, type: "comment_any" } }))}>Todos os comentários</button><button type="button" aria-pressed={form.trigger.type === "comment_keyword"} onClick={() => update((current) => ({ ...current, trigger: { ...current.trigger, type: "comment_keyword" } }))}>Palavras-chave</button></div>
              </>}
              {(form.trigger.type === "comment_keyword" || !isComment) && form.trigger.type !== "new_follower" && <label className={styles.field}><span>{isComment ? "Palavras ou expressões" : "Filtrar por palavras · opcional"}</span><input value={form.keywordText} placeholder="link, material, comprar" onChange={(event) => update((current) => ({ ...current, keywordText: event.target.value }))} /><small className={styles.hint}>Separe por vírgulas.{!isComment && " Deixe vazio para todas as mensagens deste gatilho."}</small></label>}
            </Section>
            {isComment && <Section number="02" title="Uma resposta no comentário" description="Confirme publicamente que a conversa continua no direct.">
              <Toggle title="Responder publicamente" checked={Boolean(reply?.enabled)} onChange={(enabled) => updateAction("public_reply", { enabled })} />
              {reply?.enabled && <>{[0, 1, 2].map((index) => <label key={index} className={styles.field}><span>Resposta {index + 1}{index > 0 && " · alternativa"}</span><textarea value={variants[index] ?? ""} maxLength={1000} onChange={(event) => { const next = [...variants]; next[index] = event.target.value; updateAction("public_reply", { variants: next, message: next[0] ?? "" }); }} /></label>)}<p className={styles.hint}>As respostas preenchidas são alternativas para variar a conversa.{variants.length > 3 && " As alternativas adicionais já salvas serão preservadas."}</p></>}
            </Section>}
            <Section number={isComment ? "03" : "02"} title="Abra a conversa no direct" description="Uma mensagem curta e um botão para a pessoa continuar.">
              <Toggle title="Mensagem de abertura" description="Opcional. Sem abertura, o fluxo segue para as próximas etapas." checked={Boolean(opening?.enabled)} onChange={(enabled) => updateAction("send_dm", { enabled })} />
              {opening?.enabled && <><MessageField label="Mensagem de abertura" value={opening.message} onChange={(message) => updateAction("send_dm", { message })} /><label className={styles.field}><span>Texto do botão de abertura</span><input value={opening.buttonText ?? ""} maxLength={80} onChange={(event) => updateAction("send_dm", { buttonText: event.target.value })} /></label></>}
            </Section>
            <Section number={isComment ? "04" : "03"} title="Antes de entregar o link" description="Escolha quais etapas a pessoa precisa concluir.">
              {([["request_follow", "Pedir para seguir o perfil", "Solicite que a pessoa siga seu perfil."], ["request_email", "Pedir e-mail", "Peça o e-mail antes da entrega."]] as const).map(([type, title, description]) => {
                const action = actionOf(form, type);
                return <div key={type}><Toggle title={title} description={description} checked={Boolean(action?.enabled)} onChange={(enabled) => updateAction(type, { enabled })} />{action?.enabled && <div className={styles.inset}><MessageField label={type === "request_follow" ? "Mensagem do pedido para seguir" : "Mensagem do pedido de e-mail"} value={action.message} onChange={(message) => updateAction(type, { message })} /><label className={styles.field}><span>Texto do botão · opcional</span><input value={action.buttonText ?? ""} maxLength={80} onChange={(event) => updateAction(type, { buttonText: event.target.value })} /></label><label className={styles.field}><span>Atraso antes desta etapa · segundos</span><input type="number" min={0} max={86400} value={action.delaySeconds ?? 0} onChange={(event) => updateAction(type, { delaySeconds: Number(event.target.value) })} /></label></div>}</div>;
              })}
            </Section>
            <Section number={isComment ? "05" : "04"} title="Entregue o que você prometeu" description="Escreva a mensagem e conecte o link que a pessoa vai receber.">
              <Toggle title="Entrega do link" checked={Boolean(delivery?.enabled)} onChange={(enabled) => updateAction("send_link", { enabled })} />
              {delivery?.enabled && <><MessageField label="Mensagem de entrega" value={delivery.message} onChange={(message) => updateAction("send_link", { message })} /><label className={styles.field}><span>Texto do botão do link</span><input value={delivery.buttonText ?? ""} maxLength={80} onChange={(event) => updateAction("send_link", { buttonText: event.target.value })} /></label><LinkPicker resources={resources} linkId={delivery.linkId} onSelect={(linkId) => updateAction("send_link", { linkId })} onBusy={setLinkBusy} /></>}
            </Section>
            <Section number={isComment ? "06" : "05"} title="Um lembrete para depois" description="Retome a conversa se a pessoa ainda não tiver acessado o link.">
              <Toggle title="Enviar lembrete" checked={Boolean(reminder?.enabled)} onChange={(enabled) => updateAction("reminder", { enabled, ...(enabled && reminder?.delaySeconds === undefined ? { delaySeconds: 3600 } : {}) })} />
              {reminder?.enabled && <><MessageField label="Mensagem do lembrete" value={reminder.message} onChange={(message) => updateAction("reminder", { message })} /><label className={styles.field}><span>Aguardar · segundos</span><input type="number" min={1} max={86400} value={reminder.delaySeconds ?? 3600} onChange={(event) => updateAction("reminder", { delaySeconds: Number(event.target.value) })} /><small className={styles.hint}>3.600 segundos = 1 hora. Máximo: 24 horas.</small></label></>}
            </Section>
          </fieldset>
          <footer className={styles.footer}><span className={styles.hint}>{dirty ? "Alterações ainda não salvas" : persisted ? `Revisão ${persisted.revision ?? "legada"}` : "Rascunho ainda não salvo"}</span><button type="button" className={styles.secondary} disabled={busy || uncertainCreation} onClick={() => void save(currentStatus === "active" ? "active" : currentStatus === "paused" ? "paused" : "draft")}>{saving ? "Salvando…" : "Salvar alterações"}</button></footer>
        </div>}
      </div>
      <aside className={styles.preview}>
        <h2 className={styles.previewTitle}>Sua conversa, em tempo real</h2>
        <p className={styles.previewNote}>Simulação interativa. Testar esta prévia não envia mensagens nem verifica seguidores reais.</p>
        {resources.settingsError && <p className={styles.error} role="alert">Perfil: {resources.settingsError}</p>}
        <PhonePreview activeTab={previewTab} onTabChange={setPreviewTab} username={resources.username} media={selectedMedia} isExample={resources.mode === "mock"} mediaScope={form.trigger.mediaScope} triggerType={form.trigger.type}
          message={opening?.message ?? ""} button={opening?.buttonText ?? ""} openingEnabled={Boolean(opening?.enabled)}
          deliveryEnabled={Boolean(delivery?.enabled)} deliveryMessage={delivery?.message ?? ""} linkLabel={delivery?.buttonText ?? ""} linkUrl={selectedLink?.url ?? ""}
          publicReply={reply?.message ?? ""} publicReplies={variants} sendPublicReply={isComment && Boolean(reply?.enabled)} keywords={form.keywordText}
          askToFollow={Boolean(follow?.enabled)} followMessage={follow?.message ?? ""} followButton={follow?.buttonText ?? ""}
          askEmail={Boolean(email?.enabled)} emailMessage={email?.message ?? ""} emailButton={email?.buttonText ?? ""}
          sendReminder={Boolean(reminder?.enabled)} reminderMessage={reminder?.message ?? ""} reminderDelaySeconds={reminder?.delaySeconds ?? 0} />
      </aside>
    </div>
  </main>;
}
