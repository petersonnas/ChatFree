export type AutomationStatus = "active" | "paused" | "draft";

export type Automation = {
  id: string;
  name: string;
  description: string;
  trigger: string;
  status: AutomationStatus;
  sent: number;
  clicks: number;
  updatedAt: string;
  keywords: string[];
  message: string;
};

export type LinkMetric = {
  id: string;
  label: string;
  url: string;
  clicks: number;
  sent: number;
  ctr: number;
  color: string;
};

export type Activity = {
  id: string;
  kind: "message" | "click" | "automation" | "comment";
  title: string;
  detail: string;
  time: string;
};

export type InboxItem = {
  id: string;
  username: string;
  name: string;
  avatar: string;
  channel: "DM" | "Comentário";
  preview: string;
  time: string;
  unread: boolean;
  tag?: string;
};

export const fallbackDashboard = {
  metrics: {
    messages: { value: 3842, change: 18.4 },
    clicks: { value: 1276, change: 12.8 },
    ctr: { value: 33.2, change: 4.6 },
    automations: { value: 8, change: 2 },
  },
  links: [
    { id: "link-1", label: "Material gratuito", url: "gpeterson.co/material", clicks: 674, sent: 1840, ctr: 36.6, color: "#2563eb" },
    { id: "link-2", label: "Lista de espera", url: "gpeterson.co/lista", clicks: 382, sent: 1214, ctr: 31.5, color: "#0f766e" },
    { id: "link-3", label: "Comunidade", url: "gpeterson.co/comunidade", clicks: 220, sent: 788, ctr: 27.9, color: "#7c3aed" },
  ] satisfies LinkMetric[],
  activity: [
    { id: "a1", kind: "message", title: "DM enviada para @marina.silva", detail: "Automação: Palavra-chave material", time: "há 4 min" },
    { id: "a2", kind: "click", title: "Novo clique em Material gratuito", detail: "Origem: comentário no Reel", time: "há 9 min" },
    { id: "a3", kind: "comment", title: "Comentário processado em um Reel", detail: "Palavra detectada: LINK", time: "há 16 min" },
    { id: "a4", kind: "automation", title: "Automação ativada", detail: "Novos seguidores", time: "há 28 min" },
  ] satisfies Activity[],
};

export const fallbackAutomations: Automation[] = [
  { id: "automation-free-guide", name: "Link do material gratuito", description: "Entrega o material quando alguém comenta uma palavra-chave.", trigger: "Comentário em publicação ou Reel", status: "active", sent: 1840, clicks: 674, updatedAt: "Hoje, 10:42", keywords: ["material", "link", "free"], message: "Oi! Vi seu comentário 😊\n\nClique no botão abaixo para receber o material gratuito." },
  { id: "automation-welcome", name: "Boas-vindas para novos seguidores", description: "Inicia uma conversa com quem acabou de seguir o perfil.", trigger: "Novo seguidor", status: "active", sent: 963, clicks: 338, updatedAt: "Ontem, 18:20", keywords: [], message: "Que bom ter você por aqui! Como posso ajudar?" },
  { id: "automation-paused-example", name: "Resposta para perguntas frequentes", description: "Responde dúvidas recorrentes recebidas por DM.", trigger: "Mensagem direta recebida", status: "paused", sent: 621, clicks: 182, updatedAt: "20 set, 15:08", keywords: ["preço", "como funciona", "horário"], message: "Olá! Separei as respostas mais comuns para você 👇" },
  { id: "automation-story-mention", name: "Menção no story", description: "Agradece menções e convida a pessoa para conversar.", trigger: "Menção no story", status: "draft", sent: 0, clicks: 0, updatedAt: "19 set, 11:33", keywords: [], message: "Obrigado por compartilhar! 🙌" },
];

export const fallbackInbox: InboxItem[] = [
  { id: "inbox-1", username: "marina.silva", name: "Marina Silva", avatar: "MS", channel: "DM", preview: "Me manda o material?", time: "agora", unread: true, tag: "material" },
  { id: "inbox-2", username: "joaovitor.dev", name: "João Vitor", avatar: "JV", channel: "Comentário", preview: "Link", time: "há 4 min", unread: true, tag: "link" },
  { id: "inbox-3", username: "ana.estuda", name: "Ana Souza", avatar: "AS", channel: "DM", preview: "Qual é o horário da aula?", time: "há 12 min", unread: false, tag: "FAQ" },
  { id: "inbox-4", username: "lucas.mkt", name: "Lucas Martins", avatar: "LM", channel: "DM", preview: "Obrigado! Consegui acessar.", time: "há 28 min", unread: false },
  { id: "inbox-5", username: "carol.cria", name: "Carol Ferreira", avatar: "CF", channel: "Comentário", preview: "Quero participar", time: "há 42 min", unread: false },
];

export function formatNumber(value: number) {
  return new Intl.NumberFormat("pt-BR").format(value);
}

export function formatPercent(value: number) {
  return `${value.toFixed(1).replace(".", ",")}%`;
}
