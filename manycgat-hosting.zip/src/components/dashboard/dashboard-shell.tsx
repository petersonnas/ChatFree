"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { BrandMark, Icon, type IconName } from "./icons";
import styles from "./dashboard.module.css";

type NavItem = { href: string; label: string; icon: IconName; count?: string };

const mainNav: NavItem[] = [
  { href: "/dashboard", label: "Visão geral", icon: "home" },
  { href: "/dashboard/automations", label: "Automações", icon: "automation", count: "8" },
  { href: "/dashboard/flows", label: "Construtor de fluxos", icon: "automation" },
  { href: "/dashboard/inbox", label: "Inbox", icon: "inbox", count: "2" },
];

const manageNav: NavItem[] = [
  { href: "/dashboard/links", label: "Links e analytics", icon: "link" },
  { href: "/dashboard/models", label: "Modelos", icon: "template" },
  { href: "/dashboard/settings", label: "Configurações", icon: "settings" },
];

function isActive(pathname: string, href: string) {
  if (href === "/dashboard") return pathname === href;
  return pathname.startsWith(href);
}

function Navigation({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return <>
    <div className={styles.navLabel}>Workspace</div>
    <nav className={styles.nav} aria-label="Navegação principal">
      {mainNav.map((item) => <Link key={item.href} href={item.href} onClick={onNavigate} className={`${styles.navItem} ${isActive(pathname, item.href) ? styles.navItemActive : ""}`}>
        <Icon name={item.icon} size={17} />
        <span>{item.label}</span>
        {item.count && <small className={styles.navCount}>{item.count}</small>}
      </Link>)}
    </nav>
    <div className={styles.navLabel} style={{ marginTop: 27 }}>Gerenciar</div>
    <nav className={styles.nav} aria-label="Navegação de gerenciamento">
      {manageNav.map((item) => <Link key={item.href} href={item.href} onClick={onNavigate} className={`${styles.navItem} ${isActive(pathname, item.href) ? styles.navItemActive : ""}`}>
        <Icon name={item.icon} size={17} />
        <span>{item.label}</span>
      </Link>)}
    </nav>
  </>;
}

function Sidebar({ pathname }: { pathname: string }) {
  return <aside className={styles.sidebar}>
    <div className={styles.brand}><BrandMark size={30} /><div><div className={styles.brandName}>Manyflow</div><div className={styles.brandSub}>Instagram automation</div></div></div>
    <div className={styles.sideInner}>
      <div className={styles.workspace}><div className={styles.avatar}>GP</div><div className={styles.workspaceText}><strong>gpeterson.co</strong><span>Conta profissional</span></div><Icon name="chevronDown" size={14} /></div>
      <Navigation pathname={pathname} />
      <div className={styles.sideBottom}>
        <Link href="/dashboard/settings" className={styles.navItem}><Icon name="help" size={17} /><span>Central de ajuda</span></Link>
        <div className={styles.account}><div className={styles.avatar}>GP</div><div className={styles.accountText}><strong>Gabriel Peterson</strong><span>Administrador</span></div><Icon name="more" size={16} /></div>
      </div>
    </div>
  </aside>;
}

function pageName(pathname: string) {
  if (pathname.includes("automations/new")) return "Nova automação";
  if (pathname.includes("automations/")) return "Editor de automação";
  if (pathname.startsWith("/dashboard/automations")) return "Automações";
  if (pathname.startsWith("/dashboard/flows")) return "Construtor de fluxos";
  if (pathname.startsWith("/dashboard/links")) return "Links e analytics";
  if (pathname.startsWith("/dashboard/inbox")) return "Inbox";
  if (pathname.startsWith("/dashboard/models")) return "Modelos";
  if (pathname.startsWith("/dashboard/settings")) return "Configurações";
  return "Visão geral";
}

export function DashboardShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const current = pageName(pathname);

  return <div className={styles.app}>
    <Sidebar pathname={pathname} />
    {mobileOpen && <div className={styles.mobileOverlay} onClick={() => setMobileOpen(false)} aria-hidden="true" />}
    {mobileOpen && <aside className={styles.mobileDrawer}><div className={styles.brand}><BrandMark size={30} /><div><div className={styles.brandName}>Manyflow</div><div className={styles.brandSub}>Instagram automation</div></div><button className={styles.iconButton} onClick={() => setMobileOpen(false)} aria-label="Fechar menu"><Icon name="close" size={18} /></button></div><div className={styles.sideInner}><Navigation pathname={pathname} onNavigate={() => setMobileOpen(false)} /></div></aside>}
    <div className={styles.content}>
      <header className={styles.topbar}>
        <div className={styles.crumbs}><button className={`${styles.iconButton} ${styles.mobileMenu}`} onClick={() => setMobileOpen(true)} aria-label="Abrir menu"><Icon name="menu" size={19} /></button><span>Workspace</span><Icon name="chevronRight" size={13} /><span className={styles.crumbCurrent}>{current}</span></div>
        <div className={styles.topActions}><button className={`${styles.iconButton} ${styles.notif}`} aria-label="Notificações"><Icon name="bell" size={17} /></button><div className={styles.avatar}>GP</div></div>
      </header>
      {children}
    </div>
  </div>;
}
