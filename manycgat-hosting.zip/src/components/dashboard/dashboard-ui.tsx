"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { fallbackAutomations, fallbackDashboard, fallbackInbox, formatNumber, formatPercent, type Activity, type Automation, type InboxItem, type LinkMetric } from "./dashboard-data";
import { Icon, type IconName } from "./icons";
import styles from "./dashboard.module.css";

type RecordLike = Record<string, unknown>;

function unwrapApiData(payload: unknown): unknown {
  if (payload && typeof payload === "object" && "data" in payload) return (payload as RecordLike).data;
  return payload;
}

const identity = <T,>(payload: unknown) => unwrapApiData(payload) as T;

function normalizeDashboardPayload(payload: unknown) {
  const value = unwrapApiData(payload);
  if (!value || typeof value !== "object") throw new Error("Dashboard inválido");
  const record = value as RecordLike;
  if (record.metrics && record.links && record.activity) return record as typeof fallbackDashboard;
  const summary = (record.summary && typeof record.summary === "object" ? record.summary : {}) as RecordLike;
  const dmsSent = Number(summary.dmsSent ?? 0);
  const linkClicks = Number(summary.linkClicks ?? 0);
  const rawLinks = Array.isArray(record.links) ? record.links : [];
  const sentPerLink = Math.max(Math.round(dmsSent / Math.max(rawLinks.length, 1)), 1);
  const links: LinkMetric[] = rawLinks.map((item, index) => {
    const link = (item && typeof item === "object" ? item : {}) as RecordLike;
    const clicks = Number(link.clicks ?? link.uniqueClicks ?? 0);
    const sent = Math.max(sentPerLink, clicks);
    return { id: String(link.id ?? `link-${index}`), label: String(link.name ?? link.slug ?? "Link"), url: String(link.url ?? ""), clicks, sent, ctr: sent ? Math.min((clicks / sent) * 100, 100) : 0, color: ["#2563eb", "#0f766e", "#7c3aed", "#d97706"][index % 4] };
  });
  const rawAutomations = Array.isArray(record.automations) ? record.automations : [];
  const activeAutomations = rawAutomations.filter((item) => (item as RecordLike).status === "active").length;
  return { metrics: { messages: { value: dmsSent, change: 0 }, clicks: { value: linkClicks, change: 0 }, ctr: { value: dmsSent ? Math.min((linkClicks / dmsSent) * 100, 100) : 0, change: 0 }, automations: { value: activeAutomations, change: 0 } }, links: links.length ? links : fallbackDashboard.links, activity: fallbackDashboard.activity };
}

function normalizeAutomationPayload(payload: unknown): Automation[] {
  const value = unwrapApiData(payload);
  if (!Array.isArray(value)) throw new Error("Automações inválidas");
  const triggerLabels: Record<string, string> = { comment_keyword: "Comentário com palavra-chave", comment_any: "Qualquer comentário", new_follower: "Novo seguidor", dm_received: "Mensagem direta recebida", story_mention: "Menção no story" };
  return value.map((item, index) => {
    const raw = (item && typeof item === "object" ? item : {}) as RecordLike;
    const trigger = (raw.trigger && typeof raw.trigger === "object" ? raw.trigger : {}) as RecordLike;
    const actions = Array.isArray(raw.actions) ? raw.actions : [];
    const messageAction = actions.find((action) => ["send_dm", "send_link"].includes(String((action as RecordLike).type))) as RecordLike | undefined;
    const publicAction = actions.find((action) => String((action as RecordLike).type) === "public_reply") as RecordLike | undefined;
    const stats = (raw.stats && typeof raw.stats === "object" ? raw.stats : {}) as RecordLike;
    const status = raw.status === "active" || raw.status === "paused" ? raw.status : "draft";
    return { id: String(raw.id ?? `automation-${index}`), name: String(raw.name ?? "Automação"), description: String(raw.description ?? ""), trigger: triggerLabels[String(trigger.type)] ?? "Gatilho do Instagram", status, sent: Number(stats.messagesSent ?? 0), clicks: 0, updatedAt: String(raw.updatedAt ?? ""), keywords: Array.isArray(trigger.keywords) ? trigger.keywords.map(String) : [], message: String(messageAction?.message ?? publicAction?.message ?? "") };
  });
}

export function useApiFallback<T>(endpoint: string, fallback: T, normalize: (payload: unknown) => T = identity) {
  const [data, setData] = useState<T>(fallback);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    fetch(endpoint, { headers: { Accept: "application/json" } })
      .then(async (response) => {
        if (!response.ok) throw new Error(`API ${response.status}`);
        return response.json() as Promise<unknown>;
      })
      .then((payload) => { if (active) setData(normalize(payload)); })
      .catch(() => { if (active) { setData(fallback); setError("Exibindo dados de demonstração enquanto a API não está disponível."); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [endpoint, attempt, normalize]);

  return { data, loading, error, retry: () => setAttempt((value) => value + 1) };
}

export function PageHeader({ eyebrow, title, subtitle, actions }: { eyebrow?: string; title: string; subtitle?: string; actions?: ReactNode }) {
  return <div className={styles.pageHeader}><div>{eyebrow && <div className={styles.eyebrow}>{eyebrow}</div>}<h1 className={styles.pageTitle}>{title}</h1>{subtitle && <p className={styles.pageSubtitle}>{subtitle}</p>}</div>{actions && <div className={styles.headerActions}>{actions}</div>}</div>;
}

export function Button({ children, variant = "primary", href, onClick, type = "button", disabled = false }: { children: ReactNode; variant?: "primary" | "secondary" | "quiet"; href?: string; onClick?: () => void; type?: "button" | "submit"; disabled?: boolean }) {
  const className = `${styles.button} ${variant === "primary" ? styles.buttonPrimary : variant === "secondary" ? styles.buttonSecondary : styles.buttonQuiet}`;
  if (href) return <a className={className} href={href}>{children}</a>;
  return <button type={type} className={className} onClick={onClick} disabled={disabled}>{children}</button>;
}

export function Card({ children, className = "", id }: { children: ReactNode; className?: string; id?: string }) {
  return <section className={`${styles.card} ${className}`} id={id}>{children}</section>;
}

const metricIcons: Record<string, IconName> = { messages: "message", clicks: "click", ctr: "chart", automations: "automation" };
const metricLabels: Record<string, string> = { messages: "DMs enviadas", clicks: "Cliques nos links", ctr: "CTR médio", automations: "Automações ativas" };

export function MetricCard({ name, value, change, suffix }: { name: string; value: number; change: number; suffix?: string }) {
  return <Card className={styles.metric}><div className={styles.metricTop}><span>{metricLabels[name]}</span><span className={styles.metricIcon}><Icon name={metricIcons[name]} size={15} /></span></div><div className={styles.metricValue}>{suffix ? `${value.toFixed(1).replace(".", ",")}${suffix}` : formatNumber(value)}</div><div className={styles.metricBottom}><span className={styles.positive}><Icon name="arrowUp" size={12} /> {change.toFixed(1).replace(".", ",")}%</span><span>vs. mês anterior</span></div></Card>;
}

export function ErrorNote({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div className={styles.errorNote}><span>{message}</span>{onRetry && <button className={styles.button} style={{ height: 27, padding: "0 8px", fontSize: 10 }} onClick={onRetry}>Tentar novamente</button>}</div>;
}

export function SimpleLineChart() {
  const values = [38, 44, 42, 59, 51, 64, 61, 77, 72, 81, 75, 92];
  const width = 640;
  const height = 190;
  const points = values.map((value, index) => `${(index / (values.length - 1)) * width},${height - value * 1.55}`).join(" ");
  const area = `0,${height} ${points} ${width},${height}`;
  return <div className={styles.chartWrap}><svg className={styles.chartSvg} viewBox={`0 0 ${width} ${height + 22}`} role="img" aria-label="Mensagens enviadas nos últimos doze meses"><line className={styles.gridLine} x1="0" y1="35" x2={width} y2="35" /><line className={styles.gridLine} x1="0" y1="88" x2={width} y2="88" /><line className={styles.gridLine} x1="0" y1="141" x2={width} y2="141" /><polygon className={styles.chartArea} points={area} /><polyline className={styles.chartLine} points={points} />{values.map((value, index) => <circle key={index} className={styles.chartDot} cx={(index / (values.length - 1)) * width} cy={height - value * 1.55} r="3.6" />)}{["out", "nov", "dez", "jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set"].map((label, index) => <text key={label} className={styles.chartAxis} x={(index / 11) * width} y="210" textAnchor={index === 0 ? "start" : index === 11 ? "end" : "middle"}>{label}</text>)}</svg></div>;
}

function activityIcon(kind: Activity["kind"]): IconName {
  if (kind === "message") return "message";
  if (kind === "click") return "click";
  if (kind === "comment") return "comment";
  return "automation";
}

export function ActivityList({ items }: { items: Activity[] }) {
  return <div className={styles.activity}>{items.map((item) => <div className={styles.activityItem} key={item.id}><span className={styles.activityIcon}><Icon name={activityIcon(item.kind)} size={14} /></span><div><div className={styles.activityTitle}>{item.title}</div><div className={styles.activityDetail}>{item.detail}</div></div><span className={styles.activityTime}>{item.time}</span></div>)}</div>;
}

export function LinksList({ links }: { links: LinkMetric[] }) {
  const max = Math.max(...links.map((link) => link.clicks), 1);
  return <div className={styles.linkRows}>{links.map((link) => <div key={link.id}><div className={styles.linkRow}><div className={styles.linkInfo}><span className={styles.linkDot} style={{ background: link.color }} /><div style={{ minWidth: 0 }}><div className={styles.linkName}>{link.label}</div><div className={styles.linkUrl}>{link.url}</div></div></div><div className={styles.linkStats}><strong>{formatNumber(link.clicks)}</strong><span>{formatPercent(link.ctr)} CTR</span></div></div><div className={styles.progress}><span style={{ width: `${(link.clicks / max) * 100}%`, background: link.color }} /></div></div>)}</div>;
}

export function DashboardOverview() {
  const summary = useApiFallback("/api/dashboard?days=30", fallbackDashboard, normalizeDashboardPayload);
  return <main className={styles.main}><PageHeader eyebrow="Resumo da conta" title="Visão geral" subtitle="Acompanhe o desempenho das suas automações e os resultados das conversas no Instagram." actions={<Button href="/dashboard/automations/new"><Icon name="plus" size={15} /> Nova automação</Button>} />{summary.error && <div style={{ marginBottom: 16 }}><ErrorNote message={summary.error} onRetry={summary.retry} /></div>}<div className={styles.metricGrid}>{Object.entries(summary.data.metrics).map(([name, metric]) => <MetricCard key={name} name={name} value={metric.value} change={metric.change} suffix={name === "ctr" ? "%" : undefined} />)}</div><div className={styles.twoCol}><div style={{ display: "grid", gap: 18 }}><Card className={styles.sectionCard}><div className={styles.cardHeader}><div><h2 className={styles.cardTitle}>Mensagens enviadas</h2><p className={styles.cardHint}>Volume de DMs automáticas nos últimos 12 meses</p></div><select className={styles.select} defaultValue="12"><option value="12">Últimos 12 meses</option><option value="6">Últimos 6 meses</option><option value="1">Este mês</option></select></div><SimpleLineChart /></Card><Card className={styles.sectionCard}><div className={styles.cardHeader}><div><h2 className={styles.cardTitle}>Links com melhor desempenho</h2><p className={styles.cardHint}>Cliques e taxa de conversão por link rastreado</p></div><a href="/dashboard/settings" className={styles.button} style={{ height: 30, padding: "0 9px", fontSize: 10 }}>Ver todos <Icon name="chevronRight" size={12} /></a></div><div className={styles.cardBody}><LinksList links={summary.data.links} /></div></Card></div><div style={{ display: "grid", gap: 18 }}><Card className={styles.sectionCard}><div className={styles.cardHeader}><div><h2 className={styles.cardTitle}>Atividade recente</h2><p className={styles.cardHint}>Últimos eventos processados</p></div><button className={styles.iconButton} aria-label="Mais opções"><Icon name="more" size={17} /></button></div><div className={styles.cardBody}><ActivityList items={summary.data.activity} /></div></Card><Card className={styles.sectionCard}><div className={styles.cardHeader}><div><h2 className={styles.cardTitle}>Resumo rápido</h2><p className={styles.cardHint}>Status da sua operação</p></div></div><div className={styles.cardBody}><div style={{ display: "grid", gap: 14 }}><div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}><span style={{ color: "#707b89", fontSize: 11 }}>Conta do Instagram</span><span className={styles.connected}>Conectada</span></div><div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}><span style={{ color: "#707b89", fontSize: 11 }}>Limite mensal estimado</span><strong style={{ fontSize: 12 }}>5.000 DMs</strong></div><div><div style={{ display: "flex", justifyContent: "space-between", color: "#707b89", fontSize: 10 }}><span>Uso neste mês</span><span>77%</span></div><div className={styles.progress} style={{ marginTop: 7 }}><span style={{ width: "77%", background: "#2563eb" }} /></div></div></div></div></Card></div></div></main>;
}

export function useAutomations() {
  return useApiFallback<Automation[]>("/api/automations", fallbackAutomations, normalizeAutomationPayload);
}

export function AutomationStatusPill({ status }: { status: Automation["status"] }) {
  const label = status === "active" ? "Ativa" : status === "paused" ? "Pausada" : "Rascunho";
  return <span className={`${styles.status} ${status === "active" ? styles.statusActive : status === "paused" ? styles.statusPaused : styles.statusDraft}`}>{label}</span>;
}

export function AutomationList() {
  const { data, loading, error, retry } = useAutomations();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | Automation["status"]>("all");
  const filtered = useMemo(() => data.filter((item) => (filter === "all" || item.status === filter) && `${item.name} ${item.description}`.toLowerCase().includes(query.toLowerCase())), [data, filter, query]);
  return <main className={styles.main}><PageHeader eyebrow="Automação" title="Minhas automações" subtitle="Crie fluxos para responder comentários, iniciar conversas e entregar links automaticamente." actions={<Button href="/dashboard/automations/new"><Icon name="plus" size={15} /> Nova automação</Button>} /><div className={styles.toolbar}><div className={styles.searchBox}><Icon name="search" size={16} /><input className={styles.searchInput} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Pesquisar automações" /></div><div className={styles.toolbarRight}><select className={styles.filterButton} value={filter} onChange={(event) => setFilter(event.target.value as typeof filter)}><option value="all">Todos os estados</option><option value="active">Ativas</option><option value="paused">Pausadas</option><option value="draft">Rascunhos</option></select><a href="/dashboard/models" className={`${styles.button} ${styles.buttonSecondary}`} style={{ height: 37 }}><Icon name="template" size={15} /> Modelos</a></div></div>{error && <div style={{ marginBottom: 14 }}><ErrorNote message={error} onRetry={retry} /></div>}{loading ? <div className={`${styles.card} ${styles.loading}`}>Carregando automações…</div> : <div className={styles.automationList}>{filtered.map((automation) => <Card key={automation.id} className={styles.automationCard}><div className={styles.automationMain}><div className={styles.automationTitleRow}><h2 className={styles.automationTitle}>{automation.name}</h2><AutomationStatusPill status={automation.status} /></div><p className={styles.automationDescription}>{automation.description}</p><div className={styles.automationMeta}><span className={styles.metaItem}><Icon name="automation" size={13} /> {automation.trigger}</span><span className={styles.metaItem}><Icon name="link" size={13} /> {automation.keywords.length ? automation.keywords.join(", ") : "Sem palavras-chave"}</span><span className={styles.metaItem}>Atualizada {automation.updatedAt}</span></div></div><div className={styles.automationNumbers}><div className={styles.numberBlock}><strong>{formatNumber(automation.sent)}</strong><span>DMs enviadas</span></div><div className={styles.numberBlock}><strong>{formatNumber(automation.clicks)}</strong><span>cliques</span></div><div className={styles.cardActions}><a className={styles.iconButton} href={`/dashboard/automations/${automation.id}`} aria-label={`Editar ${automation.name}`}><Icon name="chevronRight" size={16} /></a></div></div></Card>)}{filtered.length === 0 && <div className={`${styles.card} ${styles.empty}`}>Nenhuma automação encontrada.</div>}</div>}</main>;
}

export function ModelsPage() {
  const models = [
    ["Enviar links por comentário", "Responda comentários com uma mensagem pública e envie o link por DM.", "comment", true],
    ["Boas-vindas a novos seguidores", "Comece uma conversa automaticamente quando alguém seguir seu perfil.", "user", false],
    ["Responder todas as DMs", "Defina uma resposta para as mensagens recebidas e encaminhe perguntas frequentes.", "message", false],
    ["Mencione você no story", "Agradeça quem mencionar seu perfil e convide para uma conversa.", "automation", false],
    ["Palavras-chave em comentários", "Crie respostas diferentes para palavras como preço, link ou comprar.", "link", false],
    ["Menu de perguntas frequentes", "Organize as perguntas mais comuns em botões fáceis de acessar.", "template", false],
  ] as const;
  return <main className={styles.main}><PageHeader eyebrow="Biblioteca" title="Modelos" subtitle="Comece com um fluxo pronto e personalize cada detalhe para o seu perfil." actions={<Button href="/dashboard/automations/new"><Icon name="plus" size={15} /> Começar do zero</Button>} /><div className={styles.toolbar}><div className={styles.searchBox}><Icon name="search" size={16} /><input className={styles.searchInput} placeholder="Buscar modelos do Instagram" /></div><div className={styles.segmented}><button className={`${styles.segment} ${styles.segmentActive}`}>Todos</button><button className={styles.segment}>Comentários</button><button className={styles.segment}>DM</button></div></div><div className={styles.modelGrid}>{models.map(([title, description, icon, popular]) => <Card key={title} className={styles.modelCard}><span className={styles.modelIcon}><Icon name={icon as IconName} size={17} /></span><h3>{title}</h3><p>{description}</p><div className={styles.modelFooter}><span className={styles.modelType}><Icon name="play" size={12} /> Automação rápida</span>{popular && <span className={styles.popular}>Popular</span>}<a href={`/dashboard/automations/new?template=${encodeURIComponent(title)}`} className={styles.button} style={{ height: 27, padding: "0 8px", fontSize: 10 }}>Usar modelo</a></div></Card>)}</div></main>;
}

export { fallbackDashboard, fallbackInbox };
