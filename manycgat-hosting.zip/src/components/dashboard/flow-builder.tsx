"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { Icon } from "./icons";
import styles from "./flow-builder.module.css";

type NodeKind = "trigger" | "message" | "condition" | "delay" | "action";
type ApiState = "loading" | "idle" | "synced" | "error";
type SimulationState = "idle" | "running" | "done";

type FlowNode = {
  id: string;
  kind: NodeKind;
  title: string;
  description: string;
  x: number;
  y: number;
};

type FlowEdge = {
  id: string;
  source: string;
  target: string;
  label?: string;
};

type FlowPayload = {
  id?: string;
  name?: string;
  nodes: FlowNode[];
  edges: FlowEdge[];
};

type FlowBuilderProps = {
  flowId?: string;
  automationId?: string;
};

const CANVAS_WIDTH = 1280;
const CANVAS_HEIGHT = 570;

const kindLabels: Record<NodeKind, string> = {
  trigger: "Gatilho",
  message: "Mensagem",
  condition: "Condição",
  delay: "Aguardar",
  action: "Ação",
};

const kindDescriptions: Record<NodeKind, string> = {
  trigger: "Inicia o fluxo quando algo acontece no Instagram.",
  message: "Envia uma mensagem para a conversa.",
  condition: "Verifica uma regra antes de continuar.",
  delay: "Aguarda um período antes da próxima etapa.",
  action: "Executa uma ação no caminho da conversa.",
};

const kindIcons: Record<NodeKind, "comment" | "message" | "filter" | "pause" | "send"> = {
  trigger: "comment",
  message: "message",
  condition: "filter",
  delay: "pause",
  action: "send",
};

const starterNodes: FlowNode[] = [
  { id: "trigger", kind: "trigger", title: "Comentário recebido", description: "Quando alguém comenta em uma publicação", x: 72, y: 196 },
  { id: "welcome", kind: "message", title: "Enviar boas-vindas", description: "Oi! Vi seu comentário e já vou te ajudar.", x: 370, y: 196 },
  { id: "has-link", kind: "condition", title: "Tem palavra-chave?", description: "material, link ou quero", x: 668, y: 196 },
  { id: "deliver", kind: "action", title: "Entregar material", description: "Enviar o link do material gratuito", x: 966, y: 92 },
  { id: "follow-up", kind: "delay", title: "Aguardar resposta", description: "Esperar 1 hora para lembrar", x: 966, y: 306 },
];

const starterEdges: FlowEdge[] = [
  { id: "edge-trigger-welcome", source: "trigger", target: "welcome" },
  { id: "edge-welcome-condition", source: "welcome", target: "has-link" },
  { id: "edge-condition-deliver", source: "has-link", target: "deliver", label: "Sim" },
  { id: "edge-condition-follow-up", source: "has-link", target: "follow-up", label: "Não" },
];

function isNodeKind(value: unknown): value is NodeKind {
  return typeof value === "string" && ["trigger", "message", "condition", "delay", "action"].includes(value);
}

function isFlowNode(value: unknown): value is FlowNode {
  if (!value || typeof value !== "object") return false;
  const node = value as Record<string, unknown>;
  return typeof node.id === "string" && isNodeKind(node.kind) && typeof node.title === "string" && typeof node.description === "string" && typeof node.x === "number" && typeof node.y === "number";
}

function isFlowEdge(value: unknown): value is FlowEdge {
  if (!value || typeof value !== "object") return false;
  const edge = value as Record<string, unknown>;
  return typeof edge.id === "string" && typeof edge.source === "string" && typeof edge.target === "string" && (edge.label === undefined || typeof edge.label === "string");
}

function unwrapPayload(value: unknown): unknown {
  if (value && typeof value === "object" && "data" in value) return (value as Record<string, unknown>).data;
  return value;
}

function parseFlowPayload(payload: unknown): FlowPayload | null {
  const unwrapped = unwrapPayload(payload);
  const candidate = Array.isArray(unwrapped) ? unwrapped[0] : unwrapped;
  if (!candidate || typeof candidate !== "object") return Array.isArray(unwrapped) ? null : null;
  const record = candidate as Record<string, unknown>;
  const nodes = Array.isArray(record.nodes) ? record.nodes.filter(isFlowNode) : [];
  const edges = Array.isArray(record.edges) ? record.edges.filter(isFlowEdge) : [];
  if (!nodes.length || nodes.length !== (Array.isArray(record.nodes) ? record.nodes.length : 0)) return null;
  if (edges.length !== (Array.isArray(record.edges) ? record.edges.length : 0)) return null;
  return { id: typeof record.id === "string" ? record.id : undefined, name: typeof record.name === "string" ? record.name : undefined, nodes, edges };
}

async function apiError(response: Response): Promise<string> {
  let detail = "";
  try {
    const payload = await response.json() as unknown;
    const value = unwrapPayload(payload);
    if (value && typeof value === "object") {
      const record = value as Record<string, unknown>;
      const candidate = record.message ?? record.error;
      if (typeof candidate === "string") detail = candidate;
    }
  } catch {
    // A non-JSON response still has a useful HTTP status.
  }
  return `API ${response.status}${detail ? `: ${detail}` : ""}`;
}

function nodeCenter(node: FlowNode, side: "left" | "right") {
  return { x: node.x + (side === "right" ? 220 : 0), y: node.y + 56 };
}

function edgePath(source: FlowNode, target: FlowNode) {
  const start = nodeCenter(source, "right");
  const end = nodeCenter(target, "left");
  const distance = Math.max((end.x - start.x) * 0.48, 48);
  return `M ${start.x} ${start.y} C ${start.x + distance} ${start.y}, ${end.x - distance} ${end.y}, ${end.x} ${end.y}`;
}

function nextNodeId(nodes: FlowNode[]) {
  let index = nodes.length + 1;
  while (nodes.some((node) => node.id === `node-${index}`)) index += 1;
  return `node-${index}`;
}

function flowPath(nodes: FlowNode[], edges: FlowEdge[]) {
  const start = nodes.find((node) => node.kind === "trigger") ?? nodes[0];
  if (!start) return [];
  const path: string[] = [];
  const visited = new Set<string>();
  let current: FlowNode | undefined = start;
  while (current && !visited.has(current.id)) {
    path.push(current.id);
    visited.add(current.id);
    const nextEdge = edges.find((edge) => edge.source === current?.id);
    current = nextEdge ? nodes.find((node) => node.id === nextEdge.target) : undefined;
  }
  return path;
}

export function FlowBuilder({ flowId, automationId }: FlowBuilderProps) {
  const router = useRouter();
  const [flowName, setFlowName] = useState(flowId ? "Fluxo da automação" : "Novo fluxo de comentários");
  const [nodes, setNodes] = useState<FlowNode[]>(starterNodes);
  const [edges, setEdges] = useState<FlowEdge[]>(starterEdges);
  const [selectedId, setSelectedId] = useState<string | null>(starterNodes[0]?.id ?? null);
  const [apiState, setApiState] = useState<ApiState>("loading");
  const [apiMessage, setApiMessage] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [addMenuOpen, setAddMenuOpen] = useState(false);
  const [simulationState, setSimulationState] = useState<SimulationState>("idle");
  const [simulationStep, setSimulationStep] = useState(-1);

  const selectedNode = nodes.find((node) => node.id === selectedId) ?? null;
  const path = useMemo(() => flowPath(nodes, edges), [nodes, edges]);
  const activePath = simulationStep >= 0 ? path.slice(0, simulationStep + 1) : [];

  useEffect(() => {
    let active = true;
    const endpoint = flowId ? `/api/flows/${encodeURIComponent(flowId)}` : "/api/flows";
    setApiState("loading");
    setApiMessage(null);
    fetch(endpoint, { headers: { Accept: "application/json" } })
      .then(async (response) => {
        if (!response.ok) throw new Error(await apiError(response));
        return response.json() as Promise<unknown>;
      })
      .then((payload) => {
        if (!active) return;
        const remote = parseFlowPayload(payload);
        if (remote) {
          setNodes(remote.nodes);
          setEdges(remote.edges);
          setSelectedId(remote.nodes[0]?.id ?? null);
          if (remote.name) setFlowName(remote.name);
        }
        setApiState("synced");
        setApiMessage(remote ? "Fluxo carregado da API." : "A API respondeu sem um fluxo utilizável. O rascunho local continua disponível.");
      })
      .catch((error: unknown) => {
        if (!active) return;
        setApiState("error");
        setApiMessage(error instanceof Error ? error.message : "Não foi possível carregar o fluxo.");
      });
    return () => { active = false; };
  }, [flowId]);

  useEffect(() => {
    if (simulationState !== "running") return;
    if (simulationStep >= path.length - 1) {
      setSimulationState("done");
      return;
    }
    const timer = window.setTimeout(() => setSimulationStep((step) => step + 1), 650);
    return () => window.clearTimeout(timer);
  }, [path, simulationState, simulationStep]);

  function updateSelected(changes: Partial<FlowNode>) {
    if (!selectedId) return;
    setNodes((current) => current.map((node) => node.id === selectedId ? { ...node, ...changes } : node));
    setSaveMessage(null);
  }

  function addNode(kind: NodeKind) {
    const id = nextNodeId(nodes);
    const last = nodes[nodes.length - 1];
    const next: FlowNode = {
      id,
      kind,
      title: kind === "message" ? "Nova mensagem" : `Nova ${kindLabels[kind].toLocaleLowerCase("pt-BR")}`,
      description: kindDescriptions[kind],
      x: last ? Math.min(last.x + 44, CANVAS_WIDTH - 240) : 90,
      y: last ? Math.min(last.y + 150, CANVAS_HEIGHT - 130) : 100,
    };
    const anchor = selectedId ?? last?.id;
    setNodes((current) => [...current, next]);
    if (anchor && anchor !== id) setEdges((current) => [...current, { id: `edge-${anchor}-${id}`, source: anchor, target: id }]);
    setSelectedId(id);
    setAddMenuOpen(false);
    setSaveMessage(null);
  }

  function removeSelected() {
    if (!selectedNode || selectedNode.kind === "trigger") return;
    setNodes((current) => current.filter((node) => node.id !== selectedNode.id));
    setEdges((current) => current.filter((edge) => edge.source !== selectedNode.id && edge.target !== selectedNode.id));
    const nextSelected = nodes.find((node) => node.id !== selectedNode.id && node.kind !== "trigger") ?? nodes.find((node) => node.id !== selectedNode.id);
    setSelectedId(nextSelected?.id ?? null);
    setSaveMessage(null);
  }

  function runSimulation() {
    if (!path.length) return;
    setSimulationState("running");
    setSimulationStep(0);
    setSelectedId(path[0]);
  }

  function stopSimulation() {
    setSimulationState("idle");
    setSimulationStep(-1);
  }

  async function saveFlow() {
    setSaving(true);
    setSaveMessage(null);
    const endpoint = flowId ? `/api/flows/${encodeURIComponent(flowId)}` : "/api/flows";
    try {
      const response = await fetch(endpoint, {
        method: flowId ? "PATCH" : "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ id: flowId, automationId, name: flowName, nodes, edges }),
      });
      if (!response.ok) throw new Error(await apiError(response));
      const payload = await response.json() as { data?: { id?: string } };
      setApiState("synced");
      setSaveMessage("Fluxo salvo pela API.");
      if (!flowId && payload.data?.id) router.replace(`/dashboard/flows/${encodeURIComponent(payload.data.id)}`);
    } catch (error: unknown) {
      setApiState("error");
      setSaveMessage(error instanceof Error ? `Não foi possível salvar: ${error.message}` : "Não foi possível salvar o fluxo.");
    } finally {
      setSaving(false);
    }
  }

  return <main className={styles.page}>
    <header className={styles.header}>
      <div>
        <div className={styles.breadcrumbs}><Link href="/dashboard">Workspace</Link><span>/</span><Link href="/dashboard/automations">Automações</Link><span>/</span><span>Flow Builder</span></div>
        <h1 className={styles.title}>{flowName}</h1>
        <p className={styles.subtitle}>Monte a conversa visualmente, ajuste cada etapa e percorra o caminho como a pessoa verá no Instagram.</p>
      </div>
      <div className={styles.headerActions}>
        <Link className={`${styles.button} ${styles.buttonSecondary}`} href="/dashboard/automations">Voltar</Link>
        <button className={`${styles.button} ${styles.buttonPrimary}`} type="button" onClick={() => void saveFlow()} disabled={saving}><Icon name="check" size={14} />{saving ? "Salvando…" : "Salvar fluxo"}</button>
      </div>
    </header>

    {apiMessage && <div className={styles.apiNotice} role={apiState === "error" ? "alert" : "status"}><Icon name={apiState === "error" ? "shield" : "check"} size={15} /><span><strong>{apiState === "error" ? "Atenção: " : "Status: "}</strong>{apiMessage}</span></div>}
    {saveMessage && <div className={styles.saveNotice} role={apiState === "error" ? "alert" : "status"}><Icon name={apiState === "error" ? "shield" : "check"} size={15} /><span>{saveMessage}</span></div>}

    <section className={styles.workspace} aria-label="Editor visual do fluxo">
      <aside className={styles.properties} aria-label="Painel de propriedades">
        <div className={styles.panelKicker}>Inspector</div>
        <h2 className={styles.panelTitle}>{selectedNode ? "Propriedades" : "Selecione um nó"}</h2>
        {!selectedNode ? <p className={styles.propertyEmpty}>Escolha uma etapa no canvas para ver e editar seus detalhes.</p> : <div>
          <div className={styles.propertyType}><span className={styles.propertyTypeDot} />{kindLabels[selectedNode.kind]}</div>
          <label className={styles.field}><span>Nome da etapa</span><input id="node-title" aria-label="Nome da etapa" value={selectedNode.title} maxLength={80} onChange={(event) => updateSelected({ title: event.target.value })} /></label>
          <label className={styles.field}><span>Descrição</span><textarea id="node-description" aria-label="Descrição" value={selectedNode.description} maxLength={240} onChange={(event) => updateSelected({ description: event.target.value })} /></label>
          <div className={styles.propertyActions}><button className={styles.nodeDelete} type="button" onClick={removeSelected} disabled={selectedNode.kind === "trigger"}><Icon name="close" size={13} />Remover nó</button>{selectedNode.kind === "trigger" && <p className={styles.propertyHint}>O gatilho é o início obrigatório do fluxo e não pode ser removido.</p>}</div>
        </div>}
      </aside>

      <div className={styles.canvasColumn}>
        <div className={styles.canvasToolbar}>
          <div className={styles.canvasToolbarInfo}><div className={styles.canvasKicker}>Canvas do fluxo</div><p className={styles.canvasToolbarTitle}>{nodes.length} etapas conectadas</p><p className={styles.canvasToolbarHint}>Clique em um nó para editar suas propriedades.</p></div>
          <div className={styles.canvasToolbarActions}>
            <span className={styles.simStatus}><span className={`${styles.simDot} ${simulationState === "running" ? styles.simDotRunning : simulationState === "done" ? styles.simDotDone : ""}`} />{simulationState === "running" ? "Simulando caminho" : simulationState === "done" ? "Simulação concluída" : "Pronto para simular"}</span>
            {simulationState === "running" ? <button className={`${styles.button} ${styles.buttonSecondary}`} type="button" onClick={stopSimulation}>Parar</button> : <button className={`${styles.button} ${styles.buttonSecondary}`} type="button" onClick={runSimulation} disabled={!path.length}><Icon name="play" size={13} />Simular caminho</button>}
            <div className={styles.addWrap}><button className={styles.addButton} type="button" aria-expanded={addMenuOpen} aria-haspopup="menu" onClick={() => setAddMenuOpen((open) => !open)}><Icon name="plus" size={14} />Adicionar nó</button>{addMenuOpen && <div className={styles.menu} role="menu" aria-label="Tipos de nó">{(Object.keys(kindLabels) as NodeKind[]).map((kind) => <button className={styles.menuItem} type="button" role="menuitem" key={kind} onClick={() => addNode(kind)}><Icon name={kindIcons[kind]} size={14} />{kindLabels[kind]}</button>)}</div>}</div>
          </div>
        </div>

        <div className={styles.canvasViewport} aria-label="Área de trabalho do fluxo">
          <div className={styles.canvasSurface} style={{ width: CANVAS_WIDTH, height: CANVAS_HEIGHT }}>
            <svg className={styles.edges} viewBox={`0 0 ${CANVAS_WIDTH} ${CANVAS_HEIGHT}`} aria-hidden="true" preserveAspectRatio="none"><defs><marker id="flow-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#a7b5c5" /></marker><marker id="flow-arrow-active" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#0b72e7" /></marker></defs>{edges.map((edge) => { const source = nodes.find((node) => node.id === edge.source); const target = nodes.find((node) => node.id === edge.target); if (!source || !target) return null; const active = activePath.includes(edge.source) && activePath.includes(edge.target); return <g key={edge.id}><path className={`${styles.edge} ${active ? styles.edgeActive : ""}`} d={edgePath(source, target)} markerEnd={`url(#${active ? "flow-arrow-active" : "flow-arrow"})`} />{edge.label && <text x={(source.x + target.x + 220) / 2} y={(source.y + target.y + 112) / 2 - 5} fill={active ? "#0b72e7" : "#7c8999"} fontSize="10" textAnchor="middle">{edge.label}</text>}</g>; })}</svg>
            {nodes.map((node) => { const active = activePath.includes(node.id); return <div className={`${styles.node} ${selectedId === node.id ? styles.nodeSelected : ""} ${active ? styles.nodeActive : ""}`} data-kind={node.kind} key={node.id} role="button" tabIndex={0} aria-pressed={selectedId === node.id} aria-label={`${kindLabels[node.kind]}: ${node.title}`} style={{ left: node.x, top: node.y }} onClick={() => setSelectedId(node.id)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setSelectedId(node.id); } }}><span className={`${styles.nodePort} ${styles.nodePortLeft}`} aria-hidden="true" /><span className={`${styles.nodePort} ${styles.nodePortRight}`} aria-hidden="true" /><span className={styles.nodeHeader}><span className={styles.nodeIcon}><Icon name={kindIcons[node.kind]} size={14} /></span><span className={styles.nodeKind}>{kindLabels[node.kind]}</span></span><strong className={styles.nodeTitle}>{node.title}</strong><span className={styles.nodeDescription}>{node.description}</span></div>; })}
            <div className={styles.canvasLegend}><span className={styles.legendItem}><span className={`${styles.legendLine} ${styles.legendLineActive}`} />Caminho simulado</span><span className={styles.legendItem}><span className={styles.legendLine} />Conexão</span></div>
          </div>
        </div>
      </div>
    </section>
  </main>;
}
