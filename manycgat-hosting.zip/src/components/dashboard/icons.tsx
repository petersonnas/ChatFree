import type { ReactNode, SVGProps } from "react";

export type IconName =
  | "home" | "automation" | "inbox" | "settings" | "help" | "user" | "logout"
  | "plus" | "search" | "bell" | "chevronDown" | "chevronRight" | "chevronLeft"
  | "more" | "link" | "message" | "click" | "chart" | "template" | "comment"
  | "play" | "pause" | "check" | "arrowUp" | "filter" | "send" | "paperclip"
  | "smile" | "external" | "eye" | "lock" | "shield" | "menu" | "close";

const paths: Record<IconName, ReactNode> = {
  home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/></>,
  automation: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.41 1.41-.06-.06A1.7 1.7 0 0 0 16.45 18a1.7 1.7 0 0 0-1 .99 1.7 1.7 0 0 0-.12.65V20h-2v-.36A1.7 1.7 0 0 0 12.3 18a1.7 1.7 0 0 0-1.75.36l-.06.06-1.41-1.41.06-.06A1.7 1.7 0 0 0 9.5 15a1.7 1.7 0 0 0-.99-1A1.7 1.7 0 0 0 7.86 14H7v-2h.86A1.7 1.7 0 0 0 9.5 9a1.7 1.7 0 0 0-.36-1.75l-.06-.06 1.41-1.41.06.06A1.7 1.7 0 0 0 12 6.5a1.7 1.7 0 0 0 1-1A1.7 1.7 0 0 0 13.14 5H15v.5A1.7 1.7 0 0 0 16.45 7a1.7 1.7 0 0 0 1.88-.34l.06-.06 1.41 1.41-.06.06A1.7 1.7 0 0 0 19.4 10a1.7 1.7 0 0 0 .99 1c.21.08.43.12.65.12H21v2h-.36A1.7 1.7 0 0 0 19.4 15Z"/></>,
  inbox: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v10a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 15.5Z"/><path d="M4 13h4l1.3 2h5.4l1.3-2h4"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.41 1.41-.06-.06A1.7 1.7 0 0 0 16.45 18a1.7 1.7 0 0 0-1 .99 1.7 1.7 0 0 0-.12.65V20h-2v-.36A1.7 1.7 0 0 0 12.3 18a1.7 1.7 0 0 0-1.75.36l-.06.06-1.41-1.41.06-.06A1.7 1.7 0 0 0 9.5 15a1.7 1.7 0 0 0-.99-1A1.7 1.7 0 0 0 7.86 14H7v-2h.86A1.7 1.7 0 0 0 9.5 9a1.7 1.7 0 0 0-.36-1.75l-.06-.06 1.41-1.41.06.06A1.7 1.7 0 0 0 12 6.5a1.7 1.7 0 0 0 1-1A1.7 1.7 0 0 0 13.14 5H15v.5A1.7 1.7 0 0 0 16.45 7a1.7 1.7 0 0 0 1.88-.34l.06-.06 1.41 1.41-.06.06A1.7 1.7 0 0 0 19.4 10a1.7 1.7 0 0 0 .99 1c.21.08.43.12.65.12H21v2h-.36A1.7 1.7 0 0 0 19.4 15Z"/></>,
  help: <><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.4 2.4 0 1 1 3.76 1.96c-.93.62-1.46 1.13-1.46 2.04"/><path d="M12 16.4h.01"/></>,
  user: <><circle cx="12" cy="8" r="3.2"/><path d="M5 20a7 7 0 0 1 14 0"/></>,
  logout: <><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 4v16"/></>,
  plus: <><path d="M12 5v14M5 12h14"/></>,
  search: <><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/></>,
  bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  chevronDown: <path d="m6 9 6 6 6-6"/>,
  chevronRight: <path d="m9 18 6-6-6-6"/>,
  chevronLeft: <path d="m15 18-6-6 6-6"/>,
  more: <><circle cx="5" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1" fill="currentColor" stroke="none"/></>,
  link: <><path d="M10 13a5 5 0 0 0 7.07.07l1.41-1.41a5 5 0 0 0-7.07-7.07L10.6 5.4"/><path d="M14 11a5 5 0 0 0-7.07-.07l-1.41 1.41a5 5 0 0 0 7.07 7.07l.81-.81"/></>,
  message: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 3v-3.3A2.5 2.5 0 0 1 4 13.5Z"/><path d="M8 8h8M8 11h5"/></>,
  click: <><path d="m5 3 5.5 17 2.3-7.1L20 10 5 3Z"/><path d="m13 13 5 5"/></>,
  chart: <><path d="M4 19V5M4 19h16"/><path d="m7 15 3-4 3 2 5-6"/></>,
  template: <><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 9h16M9 9v11"/></>,
  comment: <><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3h9A2.5 2.5 0 0 1 19 5.5v7a2.5 2.5 0 0 1-2.5 2.5H11l-4.5 3v-3.3A2.5 2.5 0 0 1 5 12.5Z"/><path d="M9 8h6M9 11h4"/></>,
  play: <path d="m8 5 11 7-11 7V5Z"/>,
  pause: <><path d="M8 5v14M16 5v14"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  arrowUp: <><path d="m6 14 6-6 6 6"/><path d="M12 8v11"/></>,
  filter: <path d="M4 5h16l-6.5 7.2V18l-5 2v-7.8L4 5Z"/>,
  send: <><path d="m21 3-7.2 18-3.6-7.2L3 10.2 21 3Z"/><path d="M10.2 13.8 21 3"/></>,
  paperclip: <path d="m20 11.5-8.8 8.8a5 5 0 0 1-7.1-7.1l9.5-9.5a3.5 3.5 0 0 1 5 5l-9.5 9.5a2 2 0 0 1-2.8-2.8l8.8-8.8"/>,
  smile: <><circle cx="12" cy="12" r="9"/><path d="M8 14.5a5 5 0 0 0 8 0M9 9h.01M15 9h.01"/></>,
  external: <><path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5"/></>,
  eye: <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></>,
  lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
  shield: <path d="M12 3 19 6v5c0 4.7-3 8.3-7 10-4-1.7-7-5.3-7-10V6l7-3Z"/>,
  menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
  close: <><path d="m6 6 12 12M18 6 6 18"/></>,
};

export function Icon({ name, size = 18, strokeWidth = 1.8, ...props }: { name: IconName; size?: number; strokeWidth?: number } & Omit<SVGProps<SVGSVGElement>, "name">) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>{paths[name]}</svg>;
}

export function BrandMark({ size = 28 }: { size?: number }) {
  return <svg width={size} height={size * 0.7} viewBox="0 0 40 28" fill="none" aria-label="Manyflow"><path d="M3 24V4h6l6 11L21 4h6v20h-5V12l-5 9h-4l-5-9v12H3Z" fill="currentColor"/><path d="M28 4h8l-3 20h-5l3-15h-3V4Z" fill="currentColor"/></svg>;
}
