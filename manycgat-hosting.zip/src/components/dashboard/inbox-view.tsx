"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { ErrorNote, PageHeader } from "./dashboard-ui";
import { Icon } from "./icons";
import styles from "./inbox.module.css";

type Channel = "dm" | "comment" | "story";
type Filter = "all" | Channel;
type Direction = "inbound" | "outbound";

type ConversationSummary = {
  id: string;
  username: string;
  name: string;
  avatar: string;
  channel: Channel;
  preview: string;
  time: string;
  unread: boolean;
  tags: string[];
};

type ConversationMessage = {
  id: string;
  direction: Direction;
  channel: Channel;
  text: string;
  status?: string;
  createdAt: string;
};

type ConversationDetail = ConversationSummary & {
  status: "open" | "closed";
  note: string;
  automationPaused: boolean;
  messages: ConversationMessage[];
};

type ApiRecord = Record<string, unknown>;

const quickReplies = [
  { label: "Agradecer", text: "Obrigado por escrever! Como posso ajudar?" },
  { label: "Enviar material", text: "Claro! Vou te enviar o material por aqui. Se precisar de algo, me avise." },
  { label: "Verificar e retornar", text: "Vou verificar essa informação e retorno por aqui em breve." },
];

function isRecord(value: unknown): value is ApiRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function unwrap(value: unknown): unknown {
  if (isRecord(value) && "data" in value) return value.data;
  return value;
}

function stringValue(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function booleanValue(value: unknown, fallback = false) {
  return typeof value === "boolean" ? value : fallback;
}

function channelValue(value: unknown): Channel {
  const normalized = stringValue(value).toLowerCase();
  if (normalized.includes("coment") || normalized === "comment") return "comment";
  if (normalized.includes("story")) return "story";
  return "dm";
}

function channelLabel(channel: Channel) {
  return channel === "comment" ? "Comentário" : channel === "story" ? "Story" : "DM";
}

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return parts.slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function displayTime(value: unknown) {
  const raw = stringValue(value);
  if (!raw) return "";
  if (!/^\d{4}-\d{2}-\d{2}T/.test(raw)) return raw;

  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) return raw;
  const elapsed = Date.now() - date.getTime();
  if (elapsed >= 0 && elapsed < 60_000) return "agora";
  if (elapsed >= 0 && elapsed < 3_600_000) return `há ${Math.max(1, Math.floor(elapsed / 60_000))} min`;
  if (elapsed >= 0 && elapsed < 86_400_000) return `há ${Math.floor(elapsed / 3_600_000)} h`;
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(date);
}

function tagsValue(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((tag) => stringValue(tag).trim()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((tag) => tag.trim()).filter(Boolean);
  return [];
}

function summaryFrom(value: unknown, fallback?: ConversationSummary): ConversationSummary {
  const raw = isRecord(value) ? value : {};
  const contact = isRecord(raw.contact) ? raw.contact : {};
  const username = stringValue(raw.username, stringValue(contact.username, fallback?.username ?? "contato"));
  const name = stringValue(raw.name, stringValue(raw.displayName, stringValue(contact.displayName, fallback?.name ?? username)));
  const preview = stringValue(raw.preview, stringValue(raw.lastMessage, fallback?.preview ?? "Sem mensagens ainda"));
  const tag = stringValue(raw.tag);
  const tags = tagsValue(raw.tags ?? contact.tags);

  return {
    id: stringValue(raw.id, fallback?.id ?? ""),
    username,
    name,
    avatar: stringValue(raw.avatar, initials(name)),
    channel: channelValue(raw.channel ?? fallback?.channel),
    preview,
    time: displayTime(raw.time ?? raw.lastMessageAt ?? fallback?.time),
    unread: booleanValue(raw.unread, fallback?.unread ?? false),
    tags: tags.length ? tags : tag ? [tag] : (fallback?.tags ?? []),
  };
}

function messageFrom(value: unknown, index: number): ConversationMessage {
  const raw = isRecord(value) ? value : {};
  const direction = stringValue(raw.direction).toLowerCase() === "outbound" ? "outbound" : "inbound";
  return {
    id: stringValue(raw.id, `message-${index}`),
    direction,
    channel: channelValue(raw.channel),
    text: stringValue(raw.text, stringValue(raw.body)),
    status: stringValue(raw.status) || undefined,
    createdAt: stringValue(raw.createdAt, stringValue(raw.timestamp)),
  };
}

function detailFrom(value: unknown, fallback?: ConversationSummary): ConversationDetail {
  const unwrapped = unwrap(value);
  const raw = isRecord(unwrapped) ? unwrapped : {};
  const conversation = isRecord(raw.conversation) ? raw.conversation : raw;
  const contact = isRecord(raw.contact) ? raw.contact : undefined;
  const summary = summaryFrom({ ...conversation, contact: contact ?? conversation.contact }, fallback);
  const rawMessages = Array.isArray(conversation.messages) ? conversation.messages : [];
  const conversationTags = tagsValue(conversation.tags);

  return {
    ...summary,
    status: stringValue(conversation.status).toLowerCase() === "closed" ? "closed" : "open",
    tags: conversationTags.length ? conversationTags : contact ? tagsValue(contact.tags) : summary.tags,
    note: stringValue(conversation.note, stringValue(conversation.notes, stringValue(raw.note, stringValue(raw.notes)))),
    automationPaused: booleanValue(conversation.automationPaused, stringValue(conversation.automationStatus).toLowerCase() === "paused"),
    messages: rawMessages.map(messageFrom).filter((message) => message.text),
  };
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, cache: "no-store", headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) } });
  const body = await response.json().catch(() => undefined);
  if (!response.ok) {
    const message = isRecord(body) ? stringValue(body.message, stringValue(body.error)) : "";
    throw new Error(message || `A solicitação falhou (${response.status}).`);
  }
  return body as T;
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error && error.message ? error.message : fallback;
}

function Avatar({ value, size = "normal" }: { value: string; size?: "normal" | "small" }) {
  return <span className={`${styles.avatar} ${size === "small" ? styles.avatarSmall : ""}`} aria-hidden="true">{value}</span>;
}

function ListSkeleton() {
  return <div className={styles.skeletonList} aria-label="Carregando conversas">{[1, 2, 3, 4].map((item) => <div className={styles.skeletonItem} key={item}><span className={styles.skeletonAvatar} /><span className={styles.skeletonCopy}><span /><span /><span /></span></div>)}</div>;
}

function DetailSkeleton() {
  return <div className={styles.detailSkeleton} aria-label="Carregando conversa"><span /><span /><span /><span /></div>;
}

function ConversationList({ items, selectedId, onSelect }: { items: ConversationSummary[]; selectedId: string; onSelect: (id: string) => void }) {
  if (!items.length) return <div className={styles.emptyList}><Icon name="search" size={20} /><strong>Nenhuma conversa encontrada</strong><span>Tente mudar o filtro ou a busca.</span></div>;

  return <div className={styles.listItems}>{items.map((item) => <button type="button" key={item.id} className={`${styles.conversationItem} ${item.id === selectedId ? styles.conversationItemSelected : ""}`} onClick={() => onSelect(item.id)} aria-current={item.id === selectedId ? "true" : undefined}>
    <Avatar value={item.avatar} />
    <span className={styles.itemContent}>
      <span className={styles.itemTop}><span className={styles.itemName}>{item.name}{item.unread && <span className={styles.unreadDot} aria-label="Não lida" />}</span><span className={styles.itemTime}>{item.time}</span></span>
      <span className={styles.itemUsername}>@{item.username} · {channelLabel(item.channel)}</span>
      <span className={styles.itemPreview}>{item.preview}</span>
      {item.tags.length > 0 && <span className={styles.tagRow}>{item.tags.slice(0, 2).map((tag) => <span className={styles.tag} key={tag}>{tag}</span>)}</span>}
    </span>
  </button>)}</div>;
}

export function InboxView() {
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [selected, setSelected] = useState<ConversationDetail | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [listLoading, setListLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [listError, setListError] = useState("");
  const [detailError, setDetailError] = useState("");
  const [mutationError, setMutationError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [composer, setComposer] = useState("");
  const [sending, setSending] = useState(false);
  const [savingNote, setSavingNote] = useState(false);
  const [savingTags, setSavingTags] = useState(false);
  const [togglingAutomation, setTogglingAutomation] = useState(false);
  const [noteDraft, setNoteDraft] = useState("");
  const [tagDraft, setTagDraft] = useState("");

  const loadList = useCallback(async () => {
    setListLoading(true);
    setListError("");
    try {
      const payload = unwrap(await request<unknown>("/api/inbox"));
      const value = Array.isArray(payload) ? payload : isRecord(payload) && Array.isArray(payload.conversations) ? payload.conversations : [];
      const next = value.map((item) => summaryFrom(item)).filter((item) => item.id);
      setConversations(next);
      setSelectedId((current) => current && next.some((item) => item.id === current) ? current : next[0]?.id ?? "");
    } catch (error) {
      setConversations([]);
      setSelectedId("");
      setListError(errorMessage(error, "Não foi possível carregar as conversas."));
    } finally {
      setListLoading(false);
    }
  }, []);

  const loadConversation = useCallback(async (id: string) => {
    if (!id) {
      setSelected(null);
      return;
    }
    setDetailLoading(true);
    setDetailError("");
    setMutationError("");
    try {
      const summary = conversations.find((item) => item.id === id);
      const payload = await request<unknown>(`/api/inbox/${encodeURIComponent(id)}`);
      const detail = detailFrom(payload, summary);
      setSelected(detail);
      setNoteDraft(detail.note);
      setTagDraft("");
    } catch (error) {
      setSelected(null);
      setDetailError(errorMessage(error, "Não foi possível carregar esta conversa."));
    } finally {
      setDetailLoading(false);
    }
  }, [conversations]);

  useEffect(() => { void loadList(); }, [loadList]);
  useEffect(() => { void loadConversation(selectedId); }, [loadConversation, selectedId]);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return conversations.filter((item) => {
      const matchesFilter = filter === "all" || item.channel === filter;
      const searchable = `${item.name} ${item.username} ${item.preview} ${item.tags.join(" ")}`.toLowerCase();
      return matchesFilter && (!normalized || searchable.includes(normalized));
    });
  }, [conversations, filter, query]);

  const runMutation = useCallback(async (body: ApiRecord, success: string) => {
    if (!selectedId) throw new Error("Selecione uma conversa antes de continuar.");
    setMutationError("");
    setSuccessMessage("");
    const payload = await request<unknown>(`/api/inbox/${encodeURIComponent(selectedId)}`, { method: "PATCH", body: JSON.stringify(body) });
    const updated = detailFrom(payload, selected ?? conversations.find((item) => item.id === selectedId));
    setSelected(updated);
    setConversations((items) => items.map((item) => item.id === updated.id ? { ...item, ...updated } : item));
    setSuccessMessage(success);
    return updated;
  }, [conversations, selected, selectedId]);

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = composer.trim();
    if (!text || !selectedId || sending) return;
    setSending(true);
    setMutationError("");
    setSuccessMessage("");
    try {
      const payload = await request<unknown>(`/api/inbox/${encodeURIComponent(selectedId)}/messages`, { method: "POST", body: JSON.stringify({ text }) });
      const value = unwrap(payload);
      const returnedConversation = isRecord(value) && (Array.isArray(value.messages) || isRecord(value.conversation)) ? detailFrom(value, selected ?? undefined) : null;
      const returnedMessage = isRecord(value) && !returnedConversation && (typeof value.text === "string" || typeof value.body === "string") ? messageFrom(value, selected?.messages.length ?? 0) : null;
      if (returnedConversation) {
        setSelected(returnedConversation);
        setConversations((items) => items.map((item) => item.id === returnedConversation.id ? { ...item, ...returnedConversation } : item));
      } else if (returnedMessage && selected) {
        setSelected({ ...selected, messages: [...selected.messages, returnedMessage], preview: returnedMessage.text, time: displayTime(returnedMessage.createdAt) });
      } else {
        await loadConversation(selectedId);
      }
      setComposer("");
      setSuccessMessage("Mensagem enviada.");
    } catch (error) {
      setMutationError(errorMessage(error, "Não foi possível enviar a mensagem."));
    } finally {
      setSending(false);
    }
  }

  async function saveNote() {
    if (!selected || savingNote || noteDraft === selected.note) return;
    setSavingNote(true);
    try {
      await runMutation({ note: noteDraft }, "Nota salva.");
    } catch (error) {
      setMutationError(errorMessage(error, "Não foi possível salvar a nota."));
    } finally {
      setSavingNote(false);
    }
  }

  async function addTag(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const tag = tagDraft.trim();
    if (!selected || !tag || savingTags || selected.tags.includes(tag)) return;
    setSavingTags(true);
    try {
      await runMutation({ tags: [...selected.tags, tag] }, "Tag adicionada.");
      setTagDraft("");
    } catch (error) {
      setMutationError(errorMessage(error, "Não foi possível atualizar as tags."));
    } finally {
      setSavingTags(false);
    }
  }

  async function removeTag(tag: string) {
    if (!selected || savingTags) return;
    setSavingTags(true);
    try {
      await runMutation({ tags: selected.tags.filter((item) => item !== tag) }, "Tag removida.");
    } catch (error) {
      setMutationError(errorMessage(error, "Não foi possível atualizar as tags."));
    } finally {
      setSavingTags(false);
    }
  }

  async function toggleAutomation() {
    if (!selected || togglingAutomation) return;
    const next = !selected.automationPaused;
    setTogglingAutomation(true);
    try {
      await runMutation({ automationPaused: next }, next ? "Automação pausada nesta conversa." : "Automação retomada nesta conversa.");
    } catch (error) {
      setMutationError(errorMessage(error, "Não foi possível atualizar a automação."));
    } finally {
      setTogglingAutomation(false);
    }
  }

  const retry = () => { void loadList(); };

  return <main className={styles.main}>
    <PageHeader eyebrow="Atendimento" title="Inbox" subtitle="Responda mensagens, organize contatos e assuma o controle das conversas." />
    {(mutationError || successMessage) && <div className={styles.feedback} role="status" aria-live="polite">{mutationError ? <ErrorNote message={mutationError} /> : <div className={styles.successNote}><Icon name="check" size={15} />{successMessage}</div>}</div>}
    {listError && <div className={styles.feedback}><ErrorNote message={listError} onRetry={retry} /></div>}
    <div className={styles.inboxLayout}>
      <section className={styles.listPanel} aria-label="Lista de conversas">
        <div className={styles.listHeader}>
          <div className={styles.listTitleRow}><div><h2>Conversas</h2><span>{conversations.length} {conversations.length === 1 ? "contato" : "contatos"}</span></div><button type="button" className={styles.iconButton} onClick={retry} disabled={listLoading} aria-label="Atualizar conversas"><span aria-hidden="true" className={styles.refreshGlyph}>↻</span></button></div>
          <label className={styles.searchField}><Icon name="search" size={15} /><span className={styles.visuallyHidden}>Buscar conversa</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar por nome ou mensagem" /></label>
          <div className={styles.filterTabs} role="tablist" aria-label="Filtrar conversas">{([{ value: "all", label: "Todos" }, { value: "dm", label: "DMs" }, { value: "comment", label: "Comentários" }] as const).map((item) => <button type="button" key={item.value} role="tab" aria-selected={filter === item.value} className={`${styles.filterTab} ${filter === item.value ? styles.filterTabActive : ""}`} onClick={() => setFilter(item.value)}>{item.label}</button>)}</div>
        </div>
        {listLoading ? <ListSkeleton /> : <ConversationList items={filtered} selectedId={selectedId} onSelect={setSelectedId} />}
      </section>

      <section className={styles.conversationPanel} aria-label="Conversa selecionada">
        {!selectedId ? <div className={styles.panelEmpty}><Icon name="inbox" size={28} /><strong>Selecione uma conversa</strong><span>Escolha um contato para ver o histórico e responder.</span></div> : detailLoading ? <DetailSkeleton /> : detailError ? <div className={styles.panelEmpty}><Icon name="message" size={28} /><strong>Não foi possível carregar a conversa</strong><span>{detailError}</span><button type="button" className={styles.secondaryButton} onClick={() => void loadConversation(selectedId)}>Tentar novamente</button></div> : selected ? <>
          <header className={styles.conversationHeader}><div className={styles.contactIdentity}><Avatar value={selected.avatar} /><div><h2>{selected.name}</h2><p>@{selected.username} · {channelLabel(selected.channel)}</p></div></div><div className={styles.headerActions}><button type="button" className={styles.secondaryButton} onClick={toggleAutomation} disabled={togglingAutomation}>{togglingAutomation ? "Salvando…" : selected.automationPaused ? <><Icon name="play" size={13} /> Retomar automação</> : <><Icon name="pause" size={13} /> Pausar automação</>}</button></div></header>
          <div className={styles.conversationBody}>
            {selected.automationPaused && <div className={styles.pausedBanner}><Icon name="pause" size={14} /><span><strong>Automação pausada</strong> As respostas automáticas estão suspensas para esta conversa.</span></div>}
            <div className={styles.dateDivider}>Histórico da conversa</div>
            {selected.messages.length ? selected.messages.map((message) => <div className={`${styles.messageRow} ${message.direction === "outbound" ? styles.messageRowOutgoing : ""}`} key={message.id}><div className={styles.messageMeta}>{message.direction === "outbound" ? "Você" : selected.name} · {displayTime(message.createdAt)}{message.status === "failed" && <span className={styles.failedStatus}>Falhou</span>}</div><div className={`${styles.messageBubble} ${message.direction === "outbound" ? styles.messageBubbleOutgoing : ""}`}>{message.text}</div></div>) : <div className={styles.emptyHistory}>Ainda não há mensagens nesta conversa.</div>}
          </div>
          <div className={styles.quickReplyBar} aria-label="Respostas rápidas"><span>Respostas rápidas</span>{quickReplies.map((reply) => <button type="button" key={reply.label} onClick={() => setComposer(reply.text)}>{reply.label}</button>)}</div>
          <form className={styles.composer} onSubmit={sendMessage}><label className={styles.visuallyHidden} htmlFor="inbox-composer">Escreva uma resposta</label><textarea id="inbox-composer" value={composer} onChange={(event) => setComposer(event.target.value)} onKeyDown={(event) => { if ((event.ctrlKey || event.metaKey) && event.key === "Enter") { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} placeholder="Escreva uma resposta…" rows={2} disabled={sending} /><div className={styles.composerFooter}><span>{sending ? "Enviando…" : "Enter para nova linha · Ctrl/Cmd + Enter para enviar"}</span><button type="submit" className={styles.primaryButton} disabled={!composer.trim() || sending}>{sending ? "Enviando…" : <><Icon name="send" size={14} /> Enviar</>}</button></div></form>
        </> : null}
      </section>

      <aside className={styles.contactPanel} aria-label="Detalhes do contato">{selected ? <>
        <div className={styles.contactPanelHeader}><h2>Contato</h2><button type="button" className={styles.iconButton} aria-label="Mais opções"><Icon name="more" size={16} /></button></div>
        <div className={styles.contactSummary}><Avatar value={selected.avatar} /><strong>{selected.name}</strong><span>@{selected.username}</span></div>
        <div className={styles.contactSection}><div className={styles.sectionTitle}><h3>Tags</h3><span>{savingTags ? "Salvando…" : ""}</span></div><div className={styles.tagList}>{selected.tags.map((tag) => <span className={styles.detailTag} key={tag}>{tag}<button type="button" onClick={() => void removeTag(tag)} disabled={savingTags} aria-label={`Remover tag ${tag}`}>×</button></span>)}</div><form className={styles.tagForm} onSubmit={addTag}><input value={tagDraft} onChange={(event) => setTagDraft(event.target.value)} placeholder="Adicionar tag" aria-label="Nova tag" disabled={savingTags} /><button type="submit" className={styles.addButton} disabled={!tagDraft.trim() || savingTags} aria-label="Adicionar tag"><Icon name="plus" size={14} /></button></form></div>
        <div className={styles.contactSection}><div className={styles.sectionTitle}><h3>Nota interna</h3><button type="button" className={styles.textButton} onClick={() => void saveNote()} disabled={savingNote || noteDraft === selected.note}>{savingNote ? "Salvando…" : "Salvar"}</button></div><textarea className={styles.noteInput} value={noteDraft} onChange={(event) => setNoteDraft(event.target.value)} placeholder="Adicione uma nota para sua equipe…" rows={4} disabled={savingNote} /><p className={styles.privateHint}>Visível apenas para sua equipe.</p></div>
        <div className={styles.contactSection}><div className={styles.sectionTitle}><h3>Status</h3></div><div className={styles.statusRow}><span className={`${styles.statusDot} ${selected.status === "open" ? styles.statusOpen : styles.statusClosed}`} />{selected.status === "open" ? "Conversa aberta" : "Conversa encerrada"}</div></div>
      </> : <div className={styles.panelHint}>Os detalhes do contato aparecem quando você seleciona uma conversa.</div>}</aside>
    </div>
  </main>;
}
