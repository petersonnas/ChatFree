"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import type { Link } from "../../types/backend";
import { AnalyticsFunnel } from "./analytics-funnel";
import { AnalyticsSummary, type AnalyticsSnapshot } from "./analytics-summary";
import { Icon } from "./icons";
import styles from "./links.module.css";

type ApiRecord = Record<string, unknown>;
type LinkWithOptionalUtm = Link & { utm?: Record<string, string> };
type LinkForm = { name: string; url: string; slug: string; source: string; medium: string; campaign: string };
const emptyForm: LinkForm = { name: "", url: "", slug: "", source: "", medium: "", campaign: "" };

function unwrap(payload: unknown): unknown { return payload && typeof payload === "object" && "data" in payload ? (payload as ApiRecord).data : payload; }
function record(value: unknown): ApiRecord { return value && typeof value === "object" ? value as ApiRecord : {}; }
function numberAt(...values: unknown[]): number | null { for (const value of values) { if (typeof value === "number" && Number.isFinite(value)) return value; if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value); } return null; }
function percentValue(value: number | null): number | null { return value === null ? null : value <= 1 ? value * 100 : value; }

function normalizeLinks(payload: unknown): LinkWithOptionalUtm[] {
  const value = unwrap(payload);
  if (!Array.isArray(value)) throw new Error("A API não retornou uma lista de links.");
  return value.map((item, index) => { const link = record(item); return { id: String(link.id ?? `link-${index}`), name: String(link.name ?? link.slug ?? "Link sem nome"), slug: String(link.slug ?? ""), url: String(link.url ?? ""), active: link.active !== false, clicks: numberAt(link.clicks) ?? 0, uniqueClicks: numberAt(link.uniqueClicks) ?? 0, uniqueVisitorHashes: [], createdAt: String(link.createdAt ?? ""), updatedAt: String(link.updatedAt ?? ""), utm: link.utm && typeof link.utm === "object" ? Object.fromEntries(Object.entries(link.utm as ApiRecord).map(([key, value]) => [key, String(value)])) : undefined }; });
}

function normalizeAnalytics(payload: unknown, links: LinkWithOptionalUtm[]): AnalyticsSnapshot {
  const value = record(unwrap(payload));
  const summary = record(value.summary ?? value.metrics);
  const totalClicks = numberAt(value.totalClicks, value.clicks, value.linkClicks, summary.totalClicks, summary.clicks, summary.linkClicks) ?? links.reduce((total, link) => total + (link.clicks ?? 0), 0);
  const uniqueClicks = numberAt(value.uniqueClicks, value.uniqueLinkClicks, summary.uniqueClicks, summary.uniqueLinkClicks) ?? links.reduce((total, link) => total + (link.uniqueClicks ?? 0), 0);
  const rawFunnel = Array.isArray(value.funnel) ? value.funnel : Array.isArray(value.steps) ? value.steps : [];
  const funnel = rawFunnel.map((item, index) => { const step = record(item); return { id: String(step.id ?? `step-${index}`), label: String(step.label ?? step.name ?? `Etapa ${index + 1}`), value: numberAt(step.value, step.count, step.total) ?? 0, description: typeof step.description === "string" ? step.description : undefined }; });
  const funnelCtr = funnel.length > 1 && funnel[0].value > 0 ? (funnel[funnel.length - 1].value / funnel[0].value) * 100 : null;
  const ctr = percentValue(numberAt(value.ctr, value.clickThroughRate, summary.ctr, summary.clickThroughRate)) ?? funnelCtr;
  if (funnel.length === 0) { const reached = numberAt(value.impressions, value.reached, value.visits, summary.impressions, summary.reached, summary.visits); if (reached !== null) funnel.push({ id: "reached", label: "Pessoas alcançadas", value: reached, description: "Visualizações do conteúdo" }); if (totalClicks > 0) funnel.push({ id: "clicks", label: "Cliques nos links", value: totalClicks, description: "Interações nos links rastreados" }); if (uniqueClicks > 0) funnel.push({ id: "unique-clicks", label: "Cliques únicos", value: uniqueClicks, description: "Visitantes distintos" }); }
  return { totalClicks, uniqueClicks, ctr, funnel };
}

function errorMessage(error: unknown, fallback: string): string { return error instanceof Error ? error.message : fallback; }
async function fetchJson(endpoint: string, init?: RequestInit): Promise<unknown> { const response = await fetch(endpoint, { ...init, headers: { Accept: "application/json", ...(init?.headers ?? {}) } }); const payload = await response.json().catch(() => null) as unknown; if (!response.ok) throw new Error(record(payload).error ? String(record(payload).error) : `Não foi possível carregar os dados (${response.status}).`); return payload; }
function trackedUrl(link: Link): string { return typeof window === "undefined" ? `/r/${encodeURIComponent(link.slug)}` : `${window.location.origin}/r/${encodeURIComponent(link.slug)}`; }
function destinationWithUtms(form: LinkForm): string { const url = new URL(form.url.trim()); [["utm_source", form.source], ["utm_medium", form.medium], ["utm_campaign", form.campaign]].forEach(([key, value]) => { if (value.trim()) url.searchParams.set(key, value.trim()); }); return url.toString(); }
function utmTags(link: Link): string[] { try { const url = new URL(link.url); return ["utm_source", "utm_medium", "utm_campaign"].flatMap((key) => { const value = url.searchParams.get(key); return value ? [`${key.replace("utm_", "")}: ${value}`] : []; }); } catch { return []; } }

export function LinksView() {
  const [links, setLinks] = useState<LinkWithOptionalUtm[]>([]);
  const [linksLoading, setLinksLoading] = useState(true);
  const [linksError, setLinksError] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsSnapshot | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(true);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);
  const [reload, setReload] = useState(0);
  const [query, setQuery] = useState("");
  const [form, setForm] = useState<LinkForm>(emptyForm);
  const [formOpen, setFormOpen] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  const loadData = useCallback(async (signal: AbortSignal) => {
    setLinksLoading(true); setAnalyticsLoading(true); setLinksError(null); setAnalyticsError(null);
    const [linkResult, analyticsResult] = await Promise.allSettled([fetchJson("/api/links", { signal }), fetchJson("/api/analytics?days=30", { signal })]);
    if (signal.aborted) return;
    let nextLinks: LinkWithOptionalUtm[] = [];
    if (linkResult.status === "fulfilled") { try { nextLinks = normalizeLinks(linkResult.value); setLinks(nextLinks); } catch (error) { setLinksError(errorMessage(error, "Não foi possível carregar os links.")); } } else setLinksError(errorMessage(linkResult.reason, "Não foi possível carregar os links."));
    setLinksLoading(false);
    if (analyticsResult.status === "fulfilled") { try { setAnalytics(normalizeAnalytics(analyticsResult.value, nextLinks)); } catch (error) { setAnalyticsError(errorMessage(error, "A resposta de analytics é inválida.")); } } else { setAnalytics({ totalClicks: nextLinks.reduce((total, link) => total + link.clicks, 0), uniqueClicks: nextLinks.reduce((total, link) => total + link.uniqueClicks, 0), ctr: null, funnel: [] }); setAnalyticsError(errorMessage(analyticsResult.reason, "O endpoint de analytics está indisponível.")); }
    setAnalyticsLoading(false);
  }, []);

  useEffect(() => { const controller = new AbortController(); void loadData(controller.signal); return () => controller.abort(); }, [loadData, reload]);
  const filteredLinks = useMemo(() => { const value = query.trim().toLowerCase(); return value ? links.filter((link) => `${link.name} ${link.slug} ${link.url}`.toLowerCase().includes(value)) : links; }, [links, query]);
  function updateForm(field: keyof LinkForm, value: string) { setForm((current) => ({ ...current, [field]: value })); setFormError(null); setFormSuccess(null); }

  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormLoading(true); setFormError(null); setFormSuccess(null);
    try { const createdLinks = normalizeLinks(await fetchJson("/api/links", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: form.name.trim(), url: destinationWithUtms(form), slug: form.slug.trim() || undefined }) })); const created = createdLinks[0]; if (!created) throw new Error("A API não retornou o link criado."); setLinks((current) => [created, ...current]); setForm(emptyForm); setFormSuccess("Link criado. O slug já está pronto para ser copiado."); } catch (error) { setFormError(errorMessage(error, "Não foi possível criar o link.")); } finally { setFormLoading(false); }
  }

  async function copySlug(link: Link) { try { await navigator.clipboard.writeText(link.slug); setCopiedSlug(link.id); window.setTimeout(() => setCopiedSlug((current) => current === link.id ? null : current), 1800); } catch { setFormError("Não foi possível copiar o slug. Verifique as permissões do navegador."); } }

  return <main className={styles.page}><header className={styles.pageHeader}><div><p className={styles.eyebrow}>Aquisição</p><h1 className={styles.pageTitle}>Links e analytics</h1><p className={styles.pageSubtitle}>Crie links rastreáveis, acompanhe os cliques e entenda o caminho até a conversão.</p></div><button className={styles.primaryButton} type="button" onClick={() => { setFormOpen((open) => !open); setFormSuccess(null); }}><Icon name="plus" size={16} /> {formOpen ? "Fechar formulário" : "Criar link"}</button></header>
    {formOpen && <section className={styles.createCard} aria-labelledby="create-link-title"><div className={styles.cardHeader}><div><p className={styles.eyebrow}>Novo rastreamento</p><h2 className={styles.cardTitle} id="create-link-title">Criar link</h2><p className={styles.cardHint}>Adicione UTMs para identificar a origem de cada campanha.</p></div><span className={styles.formStep}>01 / 01</span></div><form className={styles.createForm} onSubmit={submitForm}><div className={styles.formGrid}><label className={styles.field}><span>Nome do link</span><input required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="Ex.: Guia gratuito" /></label><label className={styles.field}><span>URL de destino</span><input required type="url" value={form.url} onChange={(event) => updateForm("url", event.target.value)} placeholder="https://seusite.com/guia" /></label><label className={styles.field}><span>Slug <small>opcional</small></span><input value={form.slug} onChange={(event) => updateForm("slug", event.target.value)} placeholder="guia-gratuito" /></label></div><fieldset className={styles.utmFieldset}><legend>Parâmetros UTM <small>opcionais</small></legend><div className={styles.formGrid}><label className={styles.field}><span>Origem <small>utm_source</small></span><input value={form.source} onChange={(event) => updateForm("source", event.target.value)} placeholder="instagram" /></label><label className={styles.field}><span>Mídia <small>utm_medium</small></span><input value={form.medium} onChange={(event) => updateForm("medium", event.target.value)} placeholder="dm" /></label><label className={styles.field}><span>Campanha <small>utm_campaign</small></span><input value={form.campaign} onChange={(event) => updateForm("campaign", event.target.value)} placeholder="lancamento" /></label></div></fieldset><div className={styles.formFooter}>{formError && <span className={styles.errorMessage} role="alert">{formError}</span>}{formSuccess && <span className={styles.successMessage} role="status"><Icon name="check" size={14} /> {formSuccess}</span>}<button className={styles.primaryButton} type="submit" disabled={formLoading}>{formLoading ? "Criando…" : "Salvar link"}</button></div></form></section>}
    <AnalyticsSummary analytics={analytics} loading={analyticsLoading} />{analyticsError && <div className={styles.analyticsNotice} role="status"><Icon name="chart" size={16} /><span>O catálogo está disponível, mas os dados de analytics não carregaram. {analyticsError}</span><button type="button" onClick={() => setReload((value) => value + 1)}>Atualizar</button></div>}<AnalyticsFunnel analytics={analytics} loading={analyticsLoading} error={analyticsError} onRetry={() => setReload((value) => value + 1)} />
    <section className={styles.catalogCard} aria-labelledby="catalog-title"><div className={styles.cardHeader}><div><p className={styles.eyebrow}>Biblioteca</p><h2 className={styles.cardTitle} id="catalog-title">Todos os links</h2><p className={styles.cardHint}>{links.length} {links.length === 1 ? "link criado" : "links criados"} no workspace.</p></div><label className={styles.searchField}><Icon name="search" size={15} /><span className={styles.srOnly}>Pesquisar links</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Pesquisar por nome ou slug" /></label></div><div className={styles.catalogBody}>{linksLoading && <div className={styles.listLoading} aria-label="Carregando links"><span /><span /><span /></div>}{!linksLoading && linksError && <div className={styles.inlineState} role="alert"><div><strong>Não foi possível carregar os links.</strong><span>{linksError}</span></div><button className={styles.textButton} type="button" onClick={() => setReload((value) => value + 1)}>Tentar novamente</button></div>}{!linksLoading && !linksError && filteredLinks.length === 0 && <div className={styles.emptyState}>{query ? "Nenhum link corresponde à busca." : "Você ainda não criou nenhum link."}</div>}{!linksLoading && !linksError && filteredLinks.length > 0 && <div className={styles.linkList}>{filteredLinks.map((link) => <article className={styles.linkItem} key={link.id}><div className={styles.linkIdentity}><span className={`${styles.statusDot} ${link.active ? styles.statusActive : styles.statusInactive}`} aria-label={link.active ? "Link ativo" : "Link inativo"} /><div><h3>{link.name}</h3><div className={styles.slugLine}><code>{link.slug}</code><span>{link.active ? "Ativo" : "Inativo"}</span></div><p className={styles.destination}>{link.url}</p><p className={styles.trackedUrl}>URL rastreável: {trackedUrl(link)}</p>{utmTags(link).length > 0 && <div className={styles.tagList}>{utmTags(link).map((tag) => <span key={tag}>{tag}</span>)}</div>}</div></div><div className={styles.linkNumbers}><strong>{new Intl.NumberFormat("pt-BR").format(link.clicks ?? 0)}</strong><span>cliques</span><strong>{new Intl.NumberFormat("pt-BR").format(link.uniqueClicks ?? 0)}</strong><span>únicos</span></div><div className={styles.linkActions}><button className={styles.copyButton} type="button" onClick={() => void copySlug(link)}><Icon name={copiedSlug === link.id ? "check" : "link"} size={14} /> {copiedSlug === link.id ? "Copiado" : "Copiar slug"}</button><a className={styles.externalButton} href={trackedUrl(link)} target="_blank" rel="noreferrer" aria-label={`Abrir URL rastreável de ${link.name}`}><Icon name="external" size={14} /></a></div></article>)}</div>}</div></section>
  </main>;
}
