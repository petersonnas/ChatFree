"use client";

import { useState } from "react";
import { Button, Card } from "./dashboard-ui";
import { Icon } from "./icons";
import dashboardStyles from "./dashboard.module.css";
import styles from "./settings.module.css";

type ActionState = "idle" | "working" | "success" | "error";

async function readEndpoint(endpoint: string): Promise<unknown> {
  const response = await fetch(endpoint, { headers: { Accept: "application/json" }, cache: "no-store" });
  const payload = await response.json().catch(() => undefined);
  if (!response.ok && endpoint !== "/api/health") throw new Error();
  return payload;
}

function downloadFile(filename: string, content: string) {
  const blob = new Blob([content], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function OperationDataActions() {
  const [exportState, setExportState] = useState<ActionState>("idle");
  const [copyState, setCopyState] = useState<ActionState>("idle");
  const [message, setMessage] = useState<string | null>(null);

  async function buildSnapshot() {
    const backup = await readEndpoint("/api/ops/backup");
    return JSON.stringify(backup, null, 2);
  }

  async function exportSnapshot() {
    setExportState("working");
    setMessage(null);
    try {
      const snapshot = await buildSnapshot();
      downloadFile(`manycgat-snapshot-${new Date().toISOString().slice(0, 10)}.json`, snapshot);
      setExportState("success");
      setMessage("Snapshot operacional baixado.");
    } catch {
      setExportState("error");
      setMessage("Não foi possível montar o snapshot agora.");
    }
  }

  async function copySnapshot() {
    setCopyState("working");
    setMessage(null);
    try {
      await navigator.clipboard.writeText(await buildSnapshot());
      setCopyState("success");
      setMessage("Snapshot copiado para a área de transferência.");
    } catch {
      setCopyState("error");
      setMessage("Não foi possível copiar o snapshot.");
    }
  }

  return (
    <Card className={`${dashboardStyles.card} ${styles.settingsCard} ${styles.dataActionCard}`}>
      <div className={styles.cardHeading}>
        <div><h2>Backup e exportação</h2><p className={styles.settingsCardLead}>Baixe uma cópia completa do estado do workspace para auditoria ou backup local.</p></div>
        <span className={styles.sectionMarker}><Icon name="template" size={15} /> JSON</span>
      </div>
      <div className={styles.actionRow}>
        <div className={styles.actionCopy}><strong>Backup completo em JSON</strong><span>Inclui automações, conversas, links, eventos, métricas, fila de envios e configurações do workspace.</span></div>
        <div className={styles.actionButtons}><Button onClick={() => void exportSnapshot()} disabled={exportState === "working"}><Icon name="chevronDown" size={14} /> {exportState === "working" ? "Preparando…" : "Baixar snapshot"}</Button><Button variant="secondary" onClick={() => void copySnapshot()} disabled={copyState === "working"}><Icon name="link" size={14} /> {copyState === "working" ? "Copiando…" : "Copiar JSON"}</Button></div>
      </div>
      {message && <p className={`${styles.actionMessage} ${exportState === "error" || copyState === "error" ? styles.errorMessage : styles.successMessage}`} role="status">{message}</p>}
      <p className={styles.helperText}>O arquivo baixado não substitui o backup do servidor. Proteja qualquer cópia que contenha dados de contatos ou conversas.</p>
    </Card>
  );
}
