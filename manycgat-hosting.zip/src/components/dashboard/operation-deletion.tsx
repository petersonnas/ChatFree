"use client";

import { useState, type FormEvent } from "react";
import { Button, Card } from "./dashboard-ui";
import { Icon } from "./icons";
import dashboardStyles from "./dashboard.module.css";
import styles from "./settings.module.css";

type DeletionScope = "conversations" | "events" | "all";
type DeletionRequest = { id: string; scope: DeletionScope; createdAt: string };
type RequestState = "idle" | "working" | "error";

const scopeLabels: Record<DeletionScope, string> = {
  conversations: "Conversas e dados de contato",
  events: "Eventos e métricas operacionais",
  all: "Todos os dados do workspace",
};

export function OperationDeletion() {
  const [open, setOpen] = useState(false);
  const [scope, setScope] = useState<DeletionScope>("conversations");
  const [phrase, setPhrase] = useState("");
  const [understood, setUnderstood] = useState(false);
  const [request, setRequest] = useState<DeletionRequest | null>(null);
  const [requestState, setRequestState] = useState<RequestState>("idle");
  const [error, setError] = useState<string | null>(null);

  function close() {
    setOpen(false);
    setPhrase("");
    setUnderstood(false);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (phrase !== "EXCLUIR" || !understood) return;
    setRequestState("working");
    setError(null);
    try {
      const response = await fetch("/api/ops/deletion", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ reason: scopeLabels[scope] }),
      });
      const payload = await response.json().catch(() => undefined) as { data?: { id?: string; requestedAt?: string }; error?: string } | undefined;
      if (!response.ok || !payload?.data?.id) throw new Error(payload?.error ?? "Não foi possível registrar a solicitação.");
      setRequest({ id: payload.data.id, scope, createdAt: payload.data.requestedAt ?? new Date().toISOString() });
      setRequestState("idle");
      close();
    } catch (submissionError) {
      setRequestState("error");
      setError(submissionError instanceof Error ? submissionError.message : "Não foi possível registrar a solicitação.");
    }
  }

  return (
    <>
      <Card className={`${dashboardStyles.card} ${styles.settingsCard} ${styles.deletionCard}`}>
        <div className={styles.cardHeading}>
          <div><h2>Solicitação de exclusão</h2><p className={styles.settingsCardLead}>Inicie uma solicitação com escopo definido e confirmação em duas etapas.</p></div>
          <span className={styles.dangerMarker}><Icon name="shield" size={15} /> Ação sensível</span>
        </div>
        {request ? <div className={styles.requestSubmitted} role="status"><span className={styles.requestIcon}><Icon name="check" size={17} /></span><div><strong>Solicitação confirmada</strong><p>{scopeLabels[request.scope]} · protocolo {request.id}</p><span>Preparada em {new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date(request.createdAt))}. A revisão pode ser acompanhada pelo protocolo.</span></div></div> : <div className={styles.actionRow}><div className={styles.actionCopy}><strong>Excluir dados do workspace</strong><span>Escolha o escopo, leia o impacto e confirme digitando EXCLUIR.</span></div><Button variant="secondary" onClick={() => { setError(null); setOpen(true); }}>Solicitar exclusão</Button></div>}
        {error && <p className={styles.errorMessage} role="alert">{error}</p>}
      </Card>

      {open && <div className={styles.dialogBackdrop} role="presentation"><div className={styles.dialog} role="dialog" aria-modal="true" aria-labelledby="deletion-title"><div className={styles.dialogHeader}><div><span className={styles.sectionEyebrow}>Confirmação necessária</span><h2 id="deletion-title">Solicitar exclusão de dados</h2></div><button className={styles.closeButton} onClick={close} aria-label="Fechar confirmação"><Icon name="close" size={17} /></button></div><form onSubmit={submit}><p className={styles.dialogLead}>A solicitação será registrada para revisão. Esta ação não pode ser desfeita depois de aprovada.</p><label className={styles.settingsField}><span className={styles.formLabel}>Escopo da solicitação</span><select className={styles.textInput} value={scope} onChange={(event) => setScope(event.target.value as DeletionScope)}>{Object.entries(scopeLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><label className={styles.confirmCheck}><input type="checkbox" checked={understood} onChange={(event) => setUnderstood(event.target.checked)} /><span>Entendo que dados dentro deste escopo poderão ser removidos após a revisão.</span></label><label className={styles.settingsField}><span className={styles.formLabel}>Digite EXCLUIR para continuar</span><input className={styles.textInput} value={phrase} onChange={(event) => setPhrase(event.target.value)} autoComplete="off" /></label><div className={styles.dialogActions}><Button variant="secondary" onClick={close} disabled={requestState === "working"}>Cancelar</Button><Button type="submit" disabled={phrase !== "EXCLUIR" || !understood || requestState === "working"}>{requestState === "working" ? "Registrando…" : "Registrar solicitação"}</Button></div></form></div></div>}
    </>
  );
}
