"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Button, Card } from "./dashboard-ui";
import { Icon } from "./icons";
import dashboardStyles from "./dashboard.module.css";
import styles from "./settings.module.css";

type IntegrationStatus = {
  mode: "mock" | "live";
  accountConfigured: boolean;
  webhookSignatureConfigured: boolean;
};

type HealthPayload = {
  status?: "ok" | "degraded";
  database?: string;
  storage?: {
    ready?: boolean;
    cached?: boolean;
    pendingWrites?: number;
    lastLoadedAt?: string;
    lastWriteAt?: string;
  };
  instagram?: IntegrationStatus;
  timestamp?: string;
};

type DashboardPayload = {
  summary?: {
    dmsSent?: number;
    failedDms?: number;
    webhookEvents?: number;
    failedWebhookEvents?: number;
  };
};

type DiagnosticState = {
  health: HealthPayload | null;
  dashboard: DashboardPayload | null;
  loading: boolean;
  error: string | null;
  checkedAt: string | null;
};

const initialState: DiagnosticState = { health: null, dashboard: null, loading: true, error: null, checkedAt: null };

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? value as Record<string, unknown> : {};
}

async function getJson(endpoint: string): Promise<{ payload: unknown; ok: boolean }> {
  const response = await fetch(endpoint, { headers: { Accept: "application/json" }, cache: "no-store" });
  const payload = await response.json().catch(() => undefined);
  return { payload, ok: response.ok };
}

function normalizeHealth(payload: unknown): HealthPayload {
  const value = record(payload);
  const storage = record(value.storage);
  const instagram = record(value.instagram);
  return {
    status: value.status === "ok" ? "ok" : "degraded",
    database: typeof value.database === "string" ? value.database : "json",
    storage: {
      ready: storage.ready === true,
      cached: storage.cached === true,
      pendingWrites: Number(storage.pendingWrites ?? 0),
      lastLoadedAt: typeof storage.lastLoadedAt === "string" ? storage.lastLoadedAt : undefined,
      lastWriteAt: typeof storage.lastWriteAt === "string" ? storage.lastWriteAt : undefined,
    },
    instagram: {
      mode: instagram.mode === "live" ? "live" : "mock",
      accountConfigured: instagram.accountConfigured === true,
      webhookSignatureConfigured: instagram.webhookSignatureConfigured === true,
    },
    timestamp: typeof value.timestamp === "string" ? value.timestamp : undefined,
  };
}

function normalizeDashboard(payload: unknown): DashboardPayload {
  const value = record(payload);
  const data = record(value.data ?? value.summary);
  const summary = record(data.summary ?? data);
  return { summary: {
    dmsSent: Number(summary.dmsSent ?? 0),
    failedDms: Number(summary.failedDms ?? 0),
    webhookEvents: Number(summary.webhookEvents ?? 0),
    failedWebhookEvents: Number(summary.failedWebhookEvents ?? 0),
  } };
}

function formatDate(value?: string | null): string {
  if (!value) return "Ainda não registrado";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data indisponível";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(date);
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat("pt-BR").format(value);
}

function StatusPill({ tone, children }: { tone: "success" | "warning" | "neutral"; children: string }) {
  const toneClass = tone === "success" ? styles.statusPillSuccess : tone === "warning" ? styles.statusPillWarning : styles.statusPillNeutral;
  return <span className={`${styles.statusPill} ${toneClass}`}><span />{children}</span>;
}

export function OperationDiagnostics() {
  const [state, setState] = useState<DiagnosticState>(initialState);

  const refresh = useCallback(async () => {
    setState((current) => ({ ...current, loading: true, error: null }));
    try {
      const [healthResult, dashboardResult] = await Promise.all([getJson("/api/health"), getJson("/api/dashboard?days=30")]);
      if (!healthResult.ok && !healthResult.payload) throw new Error("O health check não respondeu.");
      setState({ health: normalizeHealth(healthResult.payload), dashboard: normalizeDashboard(dashboardResult.payload), loading: false, error: dashboardResult.ok ? null : "O diagnóstico carregou, mas as métricas não puderam ser atualizadas.", checkedAt: new Date().toISOString() });
    } catch {
      setState((current) => ({ ...current, loading: false, error: "Não foi possível consultar o diagnóstico agora." }));
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const health = state.health;
  const integration = health?.instagram;
  const storage = health?.storage;
  const summary = state.dashboard?.summary;
  const webhookUrl = "/api/webhook/instagram";
  const modeTone = integration?.mode === "live" && integration.accountConfigured ? "success" : "warning";
  const modeLabel = integration?.mode === "live" && integration.accountConfigured ? "Live conectado" : "Mock ativo";
  const jsonTone = storage?.ready ? "success" : "warning";
  const jsonLabel = storage?.ready ? "JSON saudável" : "JSON em atenção";
  const errorRate = summary && summary.webhookEvents ? Math.round(((summary.failedWebhookEvents ?? 0) / summary.webhookEvents) * 100) : 0;
  const checkedLabel = useMemo(() => state.checkedAt ? `Atualizado ${formatDate(state.checkedAt)}` : "Aguardando diagnóstico", [state.checkedAt]);

  async function copyWebhookUrl() {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${webhookUrl}`);
      setState((current) => ({ ...current, error: "URL do webhook copiada." }));
    } catch {
      setState((current) => ({ ...current, error: "Não foi possível copiar a URL do webhook." }));
    }
  }

  return (
    <div className={styles.operationGrid}>
      <Card className={`${dashboardStyles.card} ${styles.operationCard} ${styles.operationCardWide}`}>
        <div className={styles.operationCardHeader}>
          <div className={styles.operationCardTitle}><span className={styles.operationIcon}><Icon name="link" size={17} /></span><div><h3>Conexão com a Meta</h3><p>O estado que o servidor está usando agora.</p></div></div>
          <StatusPill tone={modeTone}>{state.loading ? "Verificando" : modeLabel}</StatusPill>
        </div>
        <div className={styles.modePanel}>
          <div><span className={styles.dataLabel}>Modo de operação</span><strong>{integration?.mode === "live" ? "Live" : "Mock"}</strong><p>{integration?.mode === "live" ? "As chamadas podem chegar à Meta Graph API." : "Nenhuma chamada externa é feita sem credenciais válidas."}</p></div>
          <div className={styles.modeChecks}><span className={integration?.accountConfigured ? styles.checkOk : styles.checkPending}><Icon name={integration?.accountConfigured ? "check" : "close"} size={13} /> Conta configurada</span><span className={integration?.webhookSignatureConfigured ? styles.checkOk : styles.checkPending}><Icon name={integration?.webhookSignatureConfigured ? "check" : "close"} size={13} /> Assinatura disponível</span></div>
        </div>
        <div className={styles.operationFooter}><span className={styles.lastChecked}>{checkedLabel}</span><Button variant="secondary" onClick={() => void refresh()} disabled={state.loading}><Icon name="arrowUp" size={13} /> Atualizar diagnóstico</Button></div>
      </Card>

      <Card className={`${dashboardStyles.card} ${styles.operationCard}`}>
        <div className={styles.operationCardHeader}><div className={styles.operationCardTitle}><span className={styles.operationIcon}><Icon name="shield" size={17} /></span><div><h3>Assinatura do webhook</h3><p>Validação dos eventos recebidos da Meta.</p></div></div><StatusPill tone={integration?.webhookSignatureConfigured ? "success" : "warning"}>{integration?.webhookSignatureConfigured ? "Configurada" : "Pendente"}</StatusPill></div>
        <div className={styles.endpointBox}><span>Endpoint</span><code>{webhookUrl}</code><button className={styles.copyButton} onClick={() => void copyWebhookUrl()}><Icon name="link" size={13} /> Copiar</button></div>
        <p className={styles.operationNote}>{integration?.webhookSignatureConfigured ? "X-Hub-Signature-256 será conferido antes do processamento." : "Configure META_APP_SECRET antes de aceitar eventos em produção."}</p>
      </Card>

      <Card className={`${dashboardStyles.card} ${styles.operationCard}`}>
        <div className={styles.operationCardHeader}><div className={styles.operationCardTitle}><span className={styles.operationIcon}><Icon name="template" size={17} /></span><div><h3>Saúde do JSON</h3><p>Cache e escrita atômica do armazenamento.</p></div></div><StatusPill tone={jsonTone}>{jsonLabel}</StatusPill></div>
        <div className={styles.healthStats}><div><span className={styles.dataLabel}>Banco</span><strong>{health?.database?.toUpperCase() ?? "JSON"}</strong></div><div><span className={styles.dataLabel}>Cache</span><strong>{storage?.cached ? "Ativo" : "Inativo"}</strong></div><div><span className={styles.dataLabel}>Pendências</span><strong>{formatNumber(storage?.pendingWrites ?? 0)}</strong></div></div>
        <p className={styles.operationNote}>Última leitura: {formatDate(storage?.lastLoadedAt)} · Última gravação: {formatDate(storage?.lastWriteAt)}</p>
      </Card>

      <Card className={`${dashboardStyles.card} ${styles.operationCard} ${styles.operationCardWide}`}>
        <div className={styles.operationCardHeader}><div className={styles.operationCardTitle}><span className={styles.operationIcon}><Icon name="automation" size={17} /></span><div><h3>Fila e limites</h3><p>Capacidade operacional observada nos últimos 30 dias.</p></div></div><StatusPill tone={errorRate > 5 ? "warning" : "success"}>{errorRate > 5 ? "Revisar falhas" : "Operação normal"}</StatusPill></div>
        <div className={styles.limitGrid}><div className={styles.limitMetric}><strong>{formatNumber(storage?.pendingWrites ?? 0)}</strong><span>gravações pendentes agora</span></div><div className={styles.limitMetric}><strong>{formatNumber(summary?.dmsSent ?? 0)}</strong><span>DMs processadas</span></div><div className={styles.limitMetric}><strong>{formatNumber(summary?.webhookEvents ?? 0)}</strong><span>webhooks recebidos</span></div><div className={styles.limitMetric}><strong>{formatNumber(summary?.failedDms ?? 0)}</strong><span>DMs com falha</span></div></div>
        <div className={styles.operationalRules}><span><Icon name="check" size={13} /> Idempotência por evento</span><span><Icon name="check" size={13} /> Até 2.000 eventos retidos</span><span><Icon name="check" size={13} /> Até 200 mensagens por conversa</span></div>
      </Card>
      {state.error && <p className={styles.inlineStatus} role="status">{state.error}</p>}
    </div>
  );
}
