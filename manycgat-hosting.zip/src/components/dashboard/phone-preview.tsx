"use client";

import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import type { InstagramMedia } from "../../types/backend";
import styles from "./phone-preview.module.css";

const previewTabs = ["Publicação", "Comentários", "DM"] as const;

export type PreviewTab = (typeof previewTabs)[number];

/** @deprecated Use PreviewTab. Kept as an alias while existing integrations migrate. */
export type PhonePreviewTab = PreviewTab;

export type PhonePreviewProps = {
  /** The opening message shown in the Direct preview. */
  message?: string;
  /** The text displayed in the call-to-action button. */
  button?: string;
  /** The public reply displayed below the simulated Instagram comment. */
  publicReply?: string;
  /** Whether the public reply step is enabled in the current draft. */
  sendPublicReply?: boolean;
  /** A comma separated string or a list of keywords used in the comment preview. */
  keywords?: string | string[];
  /** Shows the follow gate in the Direct preview. */
  askToFollow?: boolean;
  /** Shows the email collection step before the simulated delivery. */
  askEmail?: boolean;
  /** Shows the reminder state after the simulated delivery. */
  sendReminder?: boolean;
  /** Display data supplied by the Quick Automation editor. */
  username?: string;
  media?: InstagramMedia;
  isExample?: boolean;
  mediaScope?: "any" | "specific" | "next";
  triggerType?: string;
  openingEnabled?: boolean;
  deliveryEnabled?: boolean;
  deliveryMessage?: string;
  linkLabel?: string;
  linkUrl?: string;
  publicReplies?: string[];
  followMessage?: string;
  followButton?: string;
  emailMessage?: string;
  emailButton?: string;
  reminderMessage?: string;
  reminderDelaySeconds?: number;
  /** Controls the selected tab when supplied. Omit it to let the preview manage its own tab. */
  activeTab?: PreviewTab;
  /** Receives tab changes when the preview is used as a controlled component. */
  onTabChange?: (tab: PreviewTab) => void;
  className?: string;
};

type DirectStage = "initial" | "requesting" | "delivered";

const fallbackMessage = "Oi! Vi seu comentário 😊\n\nClique no botão abaixo para receber o material gratuito.";
const fallbackButton = "Me envie o link";
const fallbackPublicReply = "Enviei uma mensagem no seu direct! 📩";

function normalizeKeywords(keywords?: PhonePreviewProps["keywords"]) {
  const values = (Array.isArray(keywords) ? keywords : keywords?.split(",") ?? [])
    .map((keyword) => keyword.trim())
    .filter(Boolean);

  return values.length ? values.slice(0, 2) : ["link"];
}

function Icon({ name, size = 16 }: { name: "arrow" | "more" | "send" | "heart" | "image" | "plus" | "smile" | "bookmark"; size?: number }) {
  const paths = {
    arrow: <path d="m13.5 5.5-5.5 5.5 5.5 5.5M8.5 11h7" />,
    more: <path d="M6 12h.01M12 12h.01M18 12h.01" />,
    send: <path d="m21 3-7.15 17-3.9-7.95L2 8.15 21 3Zm-11.05 9.05L14.5 7.5" />,
    heart: <path d="M20.8 8.9c0 5.1-8.8 10.1-8.8 10.1s-8.8-5-8.8-10.1C3.2 6.1 5.3 4 8.1 4c1.8 0 3.3.9 3.9 2.3C12.6 4.9 14.1 4 15.9 4c2.8 0 4.9 2.1 4.9 4.9Z" />,
    image: <><rect x="3.5" y="3.5" width="17" height="17" rx="4" /><path d="m5.5 17 4.1-4.1 2.8 2.8 2.1-2.1 3.5 3.5M9 9.2h.01" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    smile: <><circle cx="12" cy="12" r="8.5" /><path d="M8.5 14.5c.9 1 2.1 1.5 3.5 1.5s2.6-.5 3.5-1.5M9 9.5h.01M15 9.5h.01" /></>,
    bookmark: <path d="M6.2 4.5c0-1 .8-1.8 1.8-1.8h8c1 0 1.8.8 1.8 1.8v16.8L12 17.5l-5.8 3.8V4.5Z" />,
  } satisfies Record<string, ReactNode>;

  return <svg aria-hidden="true" className={styles.icon} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function Avatar({ initials = "GP", small = false }: { initials?: string; small?: boolean }) {
  return <span aria-hidden="true" className={`${styles.avatar} ${small ? styles.avatarSmall : ""}`}>{initials}</span>;
}

function PostArtwork({ compact = false }: { compact?: boolean }) {
  return <div aria-hidden="true" className={`${styles.postArtwork} ${compact ? styles.postArtworkCompact : ""}`}>
    <span className={styles.artBrowserBar} />
    <span className={styles.artSidebar} />
    <span className={styles.artCard} />
    <span className={styles.artLineOne} />
    <span className={styles.artLineTwo} />
    <span className={styles.artChip}>LINK</span>
    <span className={styles.artHeadline}>O conteúdo que você queria ver está aqui</span>
    <span className={styles.artDevice} />
  </div>;
}

function PublicationScene({ keyword, username, media, isExample }: { keyword: string; username: string; media?: InstagramMedia; isExample: boolean }) {
  const mediaSource = media?.mediaUrl || media?.thumbnailUrl;
  const accountName = username || "conversa.app";
  const caption = media?.caption?.trim() || `Comente “${keyword}” para receber o material no direct.`;
  return <div className={styles.publicationScene}>
    <div className={styles.igTitleBar}>
      <Icon name="arrow" size={16} />
      <div><span>CONVERSA</span><strong>Publicação</strong></div>
      <Icon name="more" size={18} />
    </div>
    <div className={styles.postAccount}>
      <Avatar small />
      <strong>{accountName}</strong>
      <Icon name="more" size={15} />
    </div>
    {mediaSource ? <div className={styles.mediaArtwork}><img src={mediaSource} alt={media?.caption || "Publicação selecionada"} /></div> : <PostArtwork />}
    <div className={styles.postActions} aria-hidden="true">
      <span>♡</span><span>◯</span><Icon name="send" size={17} /><Icon name="bookmark" size={17} />
    </div>
    <p className={styles.postCaption}><strong>{accountName}</strong> {caption}{isExample && <span className={styles.exampleMark}> · exemplo</span>}</p>
    <p className={styles.postMeta}>Ver todos os comentários · agora</p>
    <div className={styles.igNav} aria-hidden="true"><span>⌂</span><span>⌕</span><span>⊞</span><span>◉</span><Avatar small /></div>
  </div>;
}

function CommentsScene({ keyword, publicReply, username }: { keyword: string; publicReply: string; username: string }) {
  return <div className={styles.commentsScene}>
    <div className={styles.dimmedPost} aria-hidden="true">
      <div className={styles.compactTitle}>Publicação</div>
      <div className={styles.compactAccount}><Avatar small /><span>{username || "conversa.app"}</span></div>
      <PostArtwork compact />
      <div className={styles.compactCaption}>Comente “{keyword}” para receber no direct.</div>
    </div>
    <div className={styles.commentScrim} aria-hidden="true" />
    <section className={styles.commentsSheet} aria-label="Prévia de comentários">
      <span className={styles.sheetHandle} />
      <header className={styles.sheetHeading}><strong>Comentários</strong><Icon name="send" size={20} /></header>
      <div className={styles.commentList}>
        <div className={`${styles.commentRow} ${styles.commentIncoming}`}>
          <Avatar initials="MS" />
          <div><p><strong>marina.silva</strong><span>Agora</span></p><p>Quero o {keyword}!</p><button type="button" className={styles.replyText}>Responder</button></div>
          <Icon name="heart" size={15} />
        </div>
        {publicReply && <div className={`${styles.commentRow} ${styles.commentReply}`}>
          <Avatar initials="CO" />
          <div><p><strong>{username || "conversa.app"}</strong><span>Agora</span></p><p>{publicReply}</p></div>
        </div>}
      </div>
      <div className={styles.commentReactions} aria-hidden="true"><span>❤️</span><span>🙌</span><span>🔥</span><span>👏</span><span>🥹</span><span>😍</span></div>
      <div className={styles.commentComposer} aria-hidden="true"><Avatar small /><span>Insira um comentário para o nome de usuário…</span></div>
    </section>
  </div>;
}

function DirectMessageScene({
  message,
  button,
  askToFollow,
  askEmail,
  sendReminder,
  openingEnabled,
  deliveryEnabled,
  deliveryMessage,
  linkLabel,
  linkUrl,
  followMessage,
  followButton,
  emailMessage,
  emailButton,
  reminderMessage,
  reminderDelaySeconds,
  username,
  stage,
  onRequestDelivery,
}: {
  message: string;
  button: string;
  askToFollow: boolean;
  askEmail: boolean;
  sendReminder: boolean;
  openingEnabled: boolean;
  deliveryEnabled: boolean;
  deliveryMessage: string;
  linkLabel: string;
  linkUrl: string;
  followMessage: string;
  followButton: string;
  emailMessage: string;
  emailButton: string;
  reminderMessage: string;
  reminderDelaySeconds: number;
  username: string;
  stage: DirectStage;
  onRequestDelivery: () => void;
}) {
  const hasRequested = stage === "requesting" || stage === "delivered";
  const hasDelivered = stage === "delivered";

  return <div className={styles.dmScene}>
    <header className={styles.dmHeader}>
      <Icon name="arrow" size={17} />
      <Avatar small />
      <strong>{username || "conversa.app"}</strong>
      <span className={styles.dmHeaderSpacer} />
      <span aria-hidden="true">⌕</span>
      <Icon name="more" size={18} />
    </header>
    <div className={styles.dmMessages}>
      <div className={`${styles.dmRow} ${styles.dmFirstMessage}`}>
        <Avatar small />
        <div className={styles.dmBubble}>
          <p>{message}</p>
          {askToFollow && <p className={styles.followHint}>{followMessage || "Siga o perfil para liberar o material."}</p>}
          {openingEnabled && <button type="button" className={styles.dmCta} onClick={onRequestDelivery} disabled={hasRequested}>{button || followButton || "Continuar"}</button>}
          {!openingEnabled && <span className={styles.previewMuted}>Mensagem de abertura desativada</span>}
        </div>
      </div>
      {hasRequested && <div className={`${styles.dmRow} ${styles.dmUserRow}`}><div className={styles.dmUserBubble}>{button}</div></div>}
      {stage === "requesting" && <div className={`${styles.dmRow} ${styles.dmTyping}`}><Avatar small /><div className={styles.typingBubble}><span /><span /><span /></div></div>}
      {hasDelivered && <>
        {askEmail && <div className={`${styles.dmRow} ${styles.dmStaggerOne}`}><Avatar small /><div className={styles.dmBubble}><p>{emailMessage || "Antes de enviar, qual é o melhor e-mail para você?"}</p><button type="button" className={styles.dmCta}>{emailButton || "Enviar e-mail"}</button></div></div>}
        {askEmail && <div className={`${styles.dmRow} ${styles.dmUserRow} ${styles.dmStaggerTwo}`}><div className={styles.dmUserBubble}>nome@exemplo.com</div></div>}
        {deliveryEnabled ? <div className={`${styles.dmRow} ${styles.dmDelivery}`}>
          <Avatar small />
          <div className={styles.dmBubble}>
            <p>{deliveryMessage || "Pronto! Aqui está o seu material."}</p>
            <span className={styles.linkCard}><Icon name="image" size={15} /><span><strong>{linkLabel || "Material gratuito"}</strong><small>{linkUrl || "conversa.app/link"}</small></span></span>
          </div>
        </div> : <p className={styles.previewMuted}>Entrega do link desativada</p>}
        {sendReminder && <p className={`${styles.reminderState} ${styles.dmStaggerTwo}`}>{reminderMessage || `Lembrete ativo${reminderDelaySeconds ? ` após ${Math.round(reminderDelaySeconds / 60)} min` : ""} caso o link não seja acessado.`}</p>}
      </>}
    </div>
    <footer className={styles.dmComposer} aria-hidden="true"><span className={styles.composerPlus}><Icon name="plus" size={14} /></span><span>Mensagem…</span><Icon name="image" size={16} /><Icon name="smile" size={16} /></footer>
  </div>;
}

export function PhonePreview({
  message = fallbackMessage,
  button = fallbackButton,
  publicReply = fallbackPublicReply,
  keywords,
  askToFollow = false,
  askEmail = false,
  sendReminder = false,
  username = "",
  media,
  isExample = false,
  mediaScope,
  triggerType,
  openingEnabled = true,
  deliveryEnabled = true,
  deliveryMessage = "",
  linkLabel = "",
  linkUrl = "",
  publicReplies,
  sendPublicReply = true,
  followMessage = "",
  followButton = "",
  emailMessage = "",
  emailButton = "",
  reminderMessage = "",
  reminderDelaySeconds = 0,
  activeTab,
  onTabChange,
  className,
}: PhonePreviewProps) {
  const [internalTab, setInternalTab] = useState<PreviewTab>(activeTab ?? "DM");
  const [directStage, setDirectStage] = useState<DirectStage>("initial");
  const [replayKey, setReplayKey] = useState(0);
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const id = useId();
  const isControlled = activeTab !== undefined;
  const currentTab = activeTab ?? internalTab;
  const selectedKeyword = normalizeKeywords(keywords)[0];
  const safeMessage = message.trim() || fallbackMessage;
  const safeButton = button.trim() || fallbackButton;
  const safePublicReply = publicReply.trim();
  const tabListId = `${id}-tabs`;
  const panelId = `${id}-panel`;
  const selectedTabId = `${id}-tab-${previewTabs.indexOf(currentTab)}`;

  useEffect(() => {
    if (directStage !== "requesting") return;

    const deliveryTimer = window.setTimeout(() => setDirectStage("delivered"), askEmail ? 1050 : 650);
    return () => window.clearTimeout(deliveryTimer);
  }, [askEmail, directStage]);

  function selectTab(tab: PreviewTab) {
    if (!isControlled) setInternalTab(tab);
    onTabChange?.(tab);
    setDirectStage("initial");
    setReplayKey((value) => value + 1);
  }

  function handleTabKeyDown(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let nextIndex: number | null = null;
    if (event.key === "ArrowRight") nextIndex = (index + 1) % previewTabs.length;
    if (event.key === "ArrowLeft") nextIndex = (index - 1 + previewTabs.length) % previewTabs.length;
    if (event.key === "Home") nextIndex = 0;
    if (event.key === "End") nextIndex = previewTabs.length - 1;
    if (nextIndex === null) return;

    event.preventDefault();
    const nextTab = previewTabs[nextIndex];
    selectTab(nextTab);
    tabRefs.current[nextIndex]?.focus();
  }

  function replayPreview() {
    setDirectStage("initial");
    setReplayKey((value) => value + 1);
  }

  const statusText = directStage === "requesting"
    ? "A pessoa pediu o material. A entrega está sendo simulada."
    : directStage === "delivered"
      ? "Material entregue na prévia."
      : "Prévia pronta para simular a conversa.";

  return <section className={`${styles.root} ${className ?? ""}`} aria-label="Prévia da automação no Instagram">
    <div className={styles.previewHeader}>
      <span>Visualização em tempo real</span>
      <button type="button" className={styles.replayButton} onClick={replayPreview}>↻ Repetir prévia</button>
    </div>
    <div className={styles.phone}>
      <div className={styles.statusBar} aria-hidden="true"><strong>11:32</strong><span className={styles.phoneNotch} /><span>▮▮▮</span></div>
      <div id={panelId} role="tabpanel" aria-labelledby={selectedTabId} className={styles.screen} key={`${currentTab}-${replayKey}`}>
        {currentTab === "Publicação" && <PublicationScene keyword={selectedKeyword} username={username} media={media} isExample={isExample} />}
        {currentTab === "Comentários" && <CommentsScene keyword={selectedKeyword} publicReply={sendPublicReply ? (safePublicReply || publicReplies?.find(Boolean) || "") : ""} username={username} />}
        {currentTab === "DM" && <DirectMessageScene message={safeMessage} button={safeButton} askToFollow={askToFollow} askEmail={askEmail} sendReminder={sendReminder} openingEnabled={openingEnabled} deliveryEnabled={deliveryEnabled} deliveryMessage={deliveryMessage} linkLabel={linkLabel} linkUrl={linkUrl} followMessage={followMessage} followButton={followButton} emailMessage={emailMessage} emailButton={emailButton} reminderMessage={reminderMessage} reminderDelaySeconds={reminderDelaySeconds} username={username} stage={directStage} onRequestDelivery={() => setDirectStage("requesting")} />}
      </div>
    </div>
    <div id={tabListId} className={styles.tabs} role="tablist" aria-label="Modo de visualização do Instagram">
      {previewTabs.map((tab, index) => {
        const selected = tab === currentTab;
        return <button
          key={tab}
          id={`${id}-tab-${index}`}
          ref={(element) => { tabRefs.current[index] = element; }}
          type="button"
          role="tab"
          aria-selected={selected}
          aria-controls={panelId}
          tabIndex={selected ? 0 : -1}
          className={`${styles.tab} ${selected ? styles.tabSelected : ""}`}
          onClick={() => selectTab(tab)}
          onKeyDown={(event) => handleTabKeyDown(event, index)}
        >{tab}</button>;
      })}
    </div>
    <p className={styles.screenReaderStatus} aria-live="polite">{statusText}</p>
  </section>;
}
