"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { InstagramMedia, Link } from "../../types/backend";
import { readApi } from "./quick-automation-state";
import styles from "./quick-automation.module.css";

type MediaResult = { data: InstagramMedia[]; mode: "mock" | "live"; paging?: { after?: string } };
const errorText = (error: unknown) => error instanceof Error ? error.message : "Não foi possível conectar ao servidor.";

export function useEditorResources() {
  const [links, setLinks] = useState<Link[]>([]);
  const [linksError, setLinksError] = useState("");
  const [linksLoading, setLinksLoading] = useState(true);
  const [username, setUsername] = useState("");
  const [settingsError, setSettingsError] = useState("");
  const [media, setMedia] = useState<InstagramMedia[]>([]);
  const [mode, setMode] = useState<MediaResult["mode"]>();
  const [after, setAfter] = useState<string>();
  const [mediaError, setMediaError] = useState("");
  const [mediaLoading, setMediaLoading] = useState(true);
  const mediaBusy = useRef(false);

  const refreshLinks = useCallback(async (signal?: AbortSignal) => {
    setLinksLoading(true);
    try {
      const result = await readApi<{ data: Link[] }>(await fetch("/api/links", { cache: "no-store", signal }));
      if (!Array.isArray(result.data)) throw new Error("O servidor não retornou a lista de links.");
      setLinks(result.data);
      setLinksError("");
      return result.data;
    } catch (error) {
      if (!signal?.aborted) setLinksError(errorText(error));
      throw error;
    } finally { if (!signal?.aborted) setLinksLoading(false); }
  }, []);

  const loadMedia = useCallback(async (cursor?: string, signal?: AbortSignal) => {
    if (mediaBusy.current && !signal) return;
    mediaBusy.current = true;
    setMediaLoading(true);
    setMediaError("");
    try {
      const result = await readApi<MediaResult>(await fetch(`/api/instagram/media${cursor ? `?after=${encodeURIComponent(cursor)}` : ""}`, { cache: "no-store", signal }));
      if (!Array.isArray(result.data) || !["mock", "live"].includes(result.mode)) throw new Error("Resposta de publicações inválida.");
      setMedia((previous) => cursor ? [...new Map([...previous, ...result.data].map((item) => [item.id, item])).values()] : result.data);
      setMode(result.mode);
      setAfter(result.paging?.after);
    } catch (error) { if (!signal?.aborted) setMediaError(errorText(error)); }
    finally { mediaBusy.current = false; if (!signal?.aborted) setMediaLoading(false); }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refreshLinks(controller.signal).catch(() => undefined);
    void loadMedia(undefined, controller.signal);
    void fetch("/api/settings", { cache: "no-store", signal: controller.signal })
      .then(readApi<{ data: { username: string } }>)
      .then((result) => {
        if (typeof result.data?.username !== "string") throw new Error("O servidor não retornou o usuário do Instagram.");
        setUsername(result.data.username.replace(/^@/, ""));
      })
      .catch((error) => { if (!controller.signal.aborted) setSettingsError(errorText(error)); });
    return () => controller.abort();
  }, [refreshLinks, loadMedia]);

  return { links, setLinks, linksError, linksLoading, refreshLinks, username, settingsError, media, mode, after, mediaError, mediaLoading, loadMedia };
}

export function MediaPicker({ resources, selectedId, onSelect }: {
  resources: ReturnType<typeof useEditorResources>; selectedId?: string; onSelect: (media: InstagramMedia) => void;
}) {
  return <div className={styles.mediaPicker}>
    <p className={styles.hint}>{resources.mode === "mock" ? "Modo de demonstração · publicações de exemplo" : "Publicações da conta conectada"}</p>
    {resources.mediaError && <p role="alert" className={styles.error}>{resources.mediaError} <button type="button" className={styles.textButton} onClick={() => void resources.loadMedia()}>Tentar novamente</button></p>}
    <div className={styles.mediaGrid}>
      {resources.media.map((item, index) => <button type="button" key={item.id} className={styles.mediaTile} aria-pressed={selectedId === item.id} onClick={() => onSelect(item)}>
        {item.thumbnailUrl || (item.mediaType !== "VIDEO" && item.mediaUrl) ? <img src={item.thumbnailUrl || item.mediaUrl} alt={item.caption || `Publicação ${index + 1}`} loading="lazy" /> : <span className={styles.mediaPlaceholder}>{item.mediaType === "VIDEO" ? "▶ Vídeo" : "Sem imagem"}</span>}
        <span>{resources.mode === "mock" && "Exemplo · "}{item.caption || `Publicação ${index + 1}`}</span>
        {selectedId === item.id && <strong className={styles.selectedMark}>✓ Selecionada</strong>}
      </button>)}
    </div>
    {resources.mediaLoading && <p role="status" className={styles.hint}>Carregando publicações…</p>}
    {!resources.mediaLoading && !resources.mediaError && !resources.media.length && <p className={styles.hint}>Nenhuma publicação encontrada nesta conta.</p>}
    {selectedId && !resources.media.some((item) => item.id === selectedId) && <p className={styles.hint}>Publicação salva: {selectedId}. A seleção será preservada.</p>}
    {resources.after && <button type="button" className={styles.secondary} disabled={resources.mediaLoading} onClick={() => void resources.loadMedia(resources.after)}>Carregar mais</button>}
  </div>;
}

export function LinkPicker({ resources, linkId, onSelect, onBusy }: {
  resources: ReturnType<typeof useEditorResources>; linkId?: string; onSelect: (id: string) => void; onBusy: (value: boolean) => void;
}) {
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const lock = useRef(false);
  async function create() {
    if (lock.current) return;
    setError("");
    if (!name.trim()) { setError("Informe um nome para o link."); return; }
    try { if (!["http:", "https:"].includes(new URL(url).protocol)) throw new Error(); }
    catch { setError("Informe uma URL válida começando com https:// ou http://."); return; }
    lock.current = true; setPending(true); onBusy(true);
    try {
      const result = await readApi<{ data: Link }>(await fetch("/api/links", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: name.trim(), url: url.trim() }) }));
      if (!result.data?.id || !result.data.url) throw new Error("O servidor não confirmou a criação do link.");
      resources.setLinks((previous) => [...previous.filter((link) => link.id !== result.data.id), result.data]);
      onSelect(result.data.id);
      setCreating(false); setName(""); setUrl("");
      await resources.refreshLinks().catch(() => undefined);
    } catch (reason) { setError(errorText(reason)); }
    finally { lock.current = false; setPending(false); onBusy(false); }
  }
  return <div className={styles.linkPicker}>
    <label className={styles.field}><span>Link de entrega</span><select value={linkId ?? ""} onChange={(event) => onSelect(event.target.value)} disabled={pending}>
      <option value="">{resources.linksLoading ? "Carregando links…" : "Selecione um link"}</option>
      {linkId && !resources.links.some((link) => link.id === linkId) && <option value={linkId}>Link salvo · {linkId}</option>}
      {resources.links.map((link) => <option key={link.id} value={link.id} disabled={!link.active}>{link.name}{!link.active ? " (inativo)" : ""}</option>)}
    </select></label>
    {resources.links.find((link) => link.id === linkId)?.url && <p className={styles.linkUrl}>{resources.links.find((link) => link.id === linkId)?.url}</p>}
    {resources.linksError && <p role="alert" className={styles.error}>{resources.linksError} <button type="button" className={styles.textButton} onClick={() => void resources.refreshLinks().catch(() => undefined)}>Recarregar links</button></p>}
    {!creating && <button type="button" className={styles.textButton} onClick={() => setCreating(true)}>＋ Criar novo link</button>}
    {creating && <div className={styles.inset}>
      <label className={styles.field}><span>Nome do link</span><input value={name} maxLength={120} onChange={(event) => setName(event.target.value)} disabled={pending} /></label>
      <label className={styles.field}><span>URL de destino</span><input type="url" value={url} placeholder="https://" maxLength={2000} onChange={(event) => setUrl(event.target.value)} disabled={pending} /></label>
      <div className={styles.actions}><button type="button" className={styles.secondary} disabled={pending} onClick={() => setCreating(false)}>Cancelar</button><button type="button" className={styles.primary} disabled={pending} onClick={() => void create()}>{pending ? "Criando…" : "Criar e selecionar"}</button></div>
    </div>}
    {error && <p role="alert" className={styles.error}>{error}</p>}
  </div>;
}
