import type { AutomationAction, AutomationTrigger, QuickAutomation, QuickAutomationDraft } from "../../lib/automation-templates";

export type EditorAction = QuickAutomationDraft["actions"][number];
export type EditorState = Omit<QuickAutomationDraft, "actions"> & { actions: EditorAction[]; keywordText: string };

export function hydrateEditor(source?: QuickAutomation | QuickAutomationDraft): EditorState {
  const draft: QuickAutomationDraft = source ?? {
    name: "Nova automação", description: "", status: "draft",
    trigger: { type: "comment_any", keywords: [], mediaScope: "any" },
    actions: [{ type: "send_link", enabled: true, message: "", buttonText: "" }],
  };
  const copy = structuredClone(draft);
  return {
    name: copy.name, description: copy.description, status: copy.status,
    trigger: { ...copy.trigger, mediaScope: copy.trigger.mediaScope ?? (copy.trigger.mediaId || copy.trigger.media ? "specific" : "any") },
    actions: copy.actions,
    keywordText: copy.trigger.keywords.join(", "),
  };
}

export function actionOf(form: EditorState, type: AutomationAction["type"]): EditorAction | undefined {
  return form.actions.find((action) => action.type === type);
}

export function changeAction(form: EditorState, type: AutomationAction["type"], patch: Partial<EditorAction>): EditorState {
  const index = form.actions.findIndex((action) => action.type === type);
  const actions = [...form.actions];
  if (index < 0) {
    actions.push({ type, enabled: false, ...patch });
  } else {
    actions[index] = { ...actions[index], ...patch };
  }
  return { ...form, actions };
}

export function draftFromEditor(form: EditorState, status: QuickAutomationDraft["status"]): QuickAutomationDraft {
  const actions = form.actions.map((action) => {
    if (action.type !== "public_reply" || !action.variants) return { ...action };
    const variants = action.variants.map((value) => value.trim()).filter(Boolean);
    return { ...action, variants, message: variants[0] ?? "" };
  });
  return {
    name: form.name.trim(), description: form.description, status,
    trigger: { ...form.trigger, keywords: form.keywordText.split(",").map((value) => value.trim()).filter(Boolean) },
    actions,
  };
}

export function validateEditor(draft: QuickAutomationDraft): string | undefined {
  if (!draft.name) return "Dê um nome à automação.";
  if (draft.status !== "active") return;
  if (draft.trigger.type === "new_follower") return "Novo seguidor está indisponível. Selecione outro gatilho para ativar.";
  if (draft.trigger.type === "comment_keyword" && !draft.trigger.keywords.length) return "Informe pelo menos uma palavra-chave para ativar.";
  if (draft.trigger.mediaScope === "specific" && !draft.trigger.mediaId) return "Selecione a publicação específica antes de ativar.";
  const active = draft.actions.filter((action) => action.enabled);
  if (!active.length) return "Habilite pelo menos uma ação antes de ativar.";
  for (const action of active) {
    if (!action.message?.trim()) return `Preencha o texto de ${actionLabels[action.type]} antes de ativar.`;
    if (action.type === "send_link" && !action.linkId) return "Escolha um link para a entrega antes de ativar.";
    if (action.type === "send_dm" && !action.buttonText?.trim()) return "Preencha o botão da mensagem de abertura.";
    if (action.type === "reminder" && (!Number.isFinite(action.delaySeconds) || (action.delaySeconds ?? 0) <= 0)) return "Informe um atraso maior que zero para o lembrete.";
  }
}

export const actionLabels: Record<AutomationAction["type"], string> = {
  public_reply: "resposta pública", send_dm: "abertura", send_link: "entrega", request_follow: "pedido para seguir", request_email: "pedido de e-mail", reminder: "lembrete",
};
export const triggerLabels: Record<AutomationTrigger["type"], string> = {
  comment_any: "Todos os comentários", comment_keyword: "Comentários com palavras-chave", dm_received: "Mensagem direta", story_reply: "Resposta ao story", story_mention: "Menção no story", new_follower: "Novo seguidor (indisponível)",
};

// Compare the submitted fields with the saved representation; older servers may
// accept a request while silently stripping Phase 2 fields or replacing IDs.
export function saveMismatch(sent: QuickAutomationDraft, saved: QuickAutomation): string | undefined {
  function includes(actual: unknown, expected: unknown): boolean {
    if (expected === undefined || expected === "") return actual === expected || actual === undefined;
    if (Array.isArray(expected)) return Array.isArray(actual) && actual.length === expected.length && expected.every((item, index) => includes(actual[index], item));
    if (expected && typeof expected === "object") return Boolean(actual && typeof actual === "object") && Object.entries(expected).every(([key, value]) => includes((actual as Record<string, unknown>)[key], value));
    return actual === expected;
  }
  if (!includes(saved, sent)) return "O servidor respondeu, mas não preservou todos os campos enviados. O salvamento completo não foi confirmado. Suas alterações continuam no editor; tente novamente após atualizar o servidor.";
}

export async function readApi<T>(response: Response): Promise<T> {
  const result = await response.json().catch(() => null) as (T & { error?: string | { message?: string } }) | null;
  if (!response.ok) {
    const message = typeof result?.error === "string" ? result.error : result?.error?.message;
    throw new Error(message || `O servidor retornou HTTP ${response.status}. Tente novamente.`);
  }
  if (!result) throw new Error("O servidor retornou uma resposta inválida. Não foi possível confirmar a operação.");
  return result;
}
