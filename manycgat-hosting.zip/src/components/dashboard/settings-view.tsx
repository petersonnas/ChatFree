"use client";

import { useEffect, useState } from "react";
import { Button, Card, ErrorNote, PageHeader, useApiFallback } from "./dashboard-ui";
import { Icon } from "./icons";
import { OperationDataActions } from "./operation-data-actions";
import { OperationDeletion } from "./operation-deletion";
import { OperationDiagnostics } from "./operation-diagnostics";
import dashboardStyles from "./dashboard.module.css";
import styles from "./settings.module.css";

type SettingsData = { name: string; username: string; email: string; timezone: string; connected: boolean };
const fallbackSettings: SettingsData = { name: "Gabriel Peterson", username: "gpeterson.co", email: "gabriel@exemplo.com", timezone: "America/Sao_Paulo", connected: true };

export function SettingsView() {
  const settings = useApiFallback<SettingsData>("/api/settings", fallbackSettings);
  const [form, setForm] = useState(settings.data);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "success" | "error">("idle");
  const [logoutStatus, setLogoutStatus] = useState<"idle" | "working" | "error">("idle");

  useEffect(() => {
    setForm(settings.data);
  }, [settings.data]);

  async function save() {
    setSaveStatus("saving");
    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!response.ok) throw new Error();
      setSaveStatus("success");
    } catch {
      setSaveStatus("error");
    }
  }

  async function logout() {
    setLogoutStatus("working");
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" });
      if (!response.ok) throw new Error();
      window.location.assign("/login");
    } catch {
      setLogoutStatus("error");
    }
  }

  return (
    <main className={dashboardStyles.main}>
      <PageHeader
        eyebrow="Workspace"
        title="Configurações"
        subtitle="Gerencie o perfil, a operação Meta e os controles de segurança do painel."
      />

      {settings.error && <div className={styles.pageMessage}><ErrorNote message={settings.error} onRetry={settings.retry} /></div>}

      <div className={styles.settingsLayout}>
        <nav className={styles.settingsNav} aria-label="Seções das configurações">
          <a href="#perfil" className={`${styles.settingsNavItem} ${styles.settingsNavItemActive}`}><Icon name="user" size={15} /> Perfil</a>
          <a href="#operacao" className={styles.settingsNavItem}><Icon name="automation" size={15} /> Operação Meta</a>
          <a href="#seguranca" className={styles.settingsNavItem}><Icon name="shield" size={15} /> Segurança</a>
          <a href="#dados" className={styles.settingsNavItem}><Icon name="lock" size={15} /> Dados</a>
        </nav>

        <div className={styles.settingsContent}>
          <Card className={styles.settingsCard} id="perfil">
            <div className={styles.cardHeading}>
              <div>
                <h2>Dados do perfil</h2>
                <p className={styles.settingsCardLead}>Estas informações identificam o workspace dentro do painel.</p>
              </div>
              <span className={styles.sectionMarker}><Icon name="user" size={15} /> Conta</span>
            </div>

            <div className={styles.settingsFormGrid}>
              <label className={styles.settingsField}>
                <span className={styles.formLabel}>Nome</span>
                <input className={styles.textInput} value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
              </label>
              <label className={styles.settingsField}>
                <span className={styles.formLabel}>Usuário do Instagram</span>
                <input className={styles.textInput} value={form.username} onChange={(event) => setForm({ ...form, username: event.target.value })} />
              </label>
              <label className={`${styles.settingsField} ${styles.settingsFieldFull}`}>
                <span className={styles.formLabel}>E-mail para alertas</span>
                <input className={styles.textInput} type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
              </label>
              <label className={`${styles.settingsField} ${styles.settingsFieldFull}`}>
                <span className={styles.formLabel}>Fuso horário</span>
                <select className={styles.textInput} value={form.timezone} onChange={(event) => setForm({ ...form, timezone: event.target.value })}>
                  <option value="America/Sao_Paulo">Brasília (GMT-3)</option>
                  <option value="America/New_York">Nova York (GMT-4)</option>
                  <option value="Europe/Lisbon">Lisboa (GMT+1)</option>
                </select>
              </label>
            </div>

            <div className={styles.formActions}>
              <Button onClick={save} disabled={saveStatus === "saving"}>
                {saveStatus === "saving" ? "Salvando…" : "Salvar alterações"}
              </Button>
            </div>
            {saveStatus === "success" && <p className={styles.successMessage} role="status">Alterações salvas no workspace.</p>}
            {saveStatus === "error" && <p className={styles.errorMessage} role="alert">Não foi possível confirmar a alteração no servidor.</p>}
          </Card>

          <section id="operacao" className={styles.operationSection} aria-labelledby="operacao-title">
            <div className={styles.sectionIntro}>
              <div>
                <span className={styles.sectionEyebrow}>Meta / Instagram</span>
                <h2 id="operacao-title">Operação</h2>
                <p>Confira o ambiente em execução, o webhook e a integridade do armazenamento antes de publicar.</p>
              </div>
              <span className={styles.liveHint}><span className={styles.liveDot} /> Diagnóstico ao vivo</span>
            </div>
            <OperationDiagnostics />
          </section>

          <Card className={styles.settingsCard} id="seguranca">
            <div className={styles.cardHeading}>
              <div>
                <h2>Segurança</h2>
                <p className={styles.settingsCardLead}>Proteja o acesso ao painel e mantenha os segredos fora do navegador.</p>
              </div>
              <span className={styles.sectionMarker}><Icon name="shield" size={15} /> Protegido</span>
            </div>

            <div className={styles.securityList}>
              <div className={styles.securityRow}>
                <div className={styles.securityRowInfo}><Icon name="lock" size={18} className={styles.securityIcon} /><div><h3>Chave de acesso</h3><p>Quando APP_ACCESS_KEY estiver configurada, o painel exige uma sessão segura por cookie HttpOnly.</p></div></div>
                <span className={styles.statusPillNeutral}>Configurável</span>
              </div>
              <div className={styles.securityRow}>
                <div className={styles.securityRowInfo}><Icon name="shield" size={18} className={styles.securityIcon} /><div><h3>Token do Instagram</h3><p>Armazenado somente no servidor e nunca exibido no navegador.</p></div></div>
                <span className={styles.statusPillNeutral}>Servidor</span>
              </div>
              <div className={styles.securityRow}>
                <div className={styles.securityRowInfo}><Icon name="logout" size={18} className={styles.securityIcon} /><div><h3>Encerrar sessão atual</h3><p>Invalide o cookie de acesso quando terminar de operar em um dispositivo compartilhado.</p></div></div>
                <Button variant="secondary" onClick={logout} disabled={logoutStatus === "working"}>{logoutStatus === "working" ? "Encerrando…" : "Encerrar"}</Button>
              </div>
            </div>
            {logoutStatus === "error" && <p className={styles.errorMessage} role="alert">Não foi possível encerrar a sessão agora.</p>}
          </Card>

          <section id="dados" className={styles.operationSection} aria-labelledby="dados-title">
            <div className={styles.sectionIntro}>
              <div>
                <span className={styles.sectionEyebrow}>Governança</span>
                <h2 id="dados-title">Dados e continuidade</h2>
                <p>Exporte um snapshot para conferência e registre solicitações de exclusão com confirmação explícita.</p>
              </div>
            </div>
            <OperationDataActions />
            <OperationDeletion />
          </section>
        </div>
      </div>
    </main>
  );
}
