import { Inter } from "next/font/google";
import Link from "next/link";
import type { ReactNode } from "react";

import styles from "./marketing.module.css";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

type MarketingFrameProps = {
  children: ReactNode;
};

function Brand() {
  return (
    <span className={styles.brand}>
      <span className={styles.brandMark} aria-hidden="true">
        ia
      </span>
      <span>Automação Instagram</span>
    </span>
  );
}

export function MarketingFrame({ children }: MarketingFrameProps) {
  return (
    <div className={`${inter.variable} ${styles.siteRoot}`}>
      <header className={styles.siteHeader}>
        <div className={styles.headerInner}>
          <Link className={styles.brand} href="/" aria-label="Ir para a página inicial">
            <Brand />
          </Link>

          <nav className={styles.headerNav} aria-label="Navegação pública">
            <Link href="/#recursos">Recursos</Link>
            <Link href="/#como-funciona">Como funciona</Link>
            <Link href="/privacy">Privacidade</Link>
            <Link href="/security">Segurança</Link>
            <Link className={styles.headerCta} href="/dashboard">
              Acessar painel
            </Link>
          </nav>
        </div>
      </header>

      <main>{children}</main>

      <footer className={styles.siteFooter}>
        <div className={styles.footerInner}>
          <div className={styles.footerBrand}>
            <Link className={styles.brand} href="/" aria-label="Ir para a página inicial">
              <Brand />
            </Link>
            <p className={styles.footerDescription}>
              Um painel pessoal para organizar automações, comentários e mensagens do Instagram em um só lugar.
            </p>
          </div>

          <div>
            <p className={styles.footerHeading}>Produto</p>
            <nav className={styles.footerLinks} aria-label="Links do produto">
              <Link href="/#recursos">Recursos</Link>
              <Link href="/#como-funciona">Como funciona</Link>
              <Link href="/dashboard">Acessar painel</Link>
            </nav>
          </div>

          <div>
            <p className={styles.footerHeading}>Transparência</p>
            <nav className={styles.footerLinks} aria-label="Links legais">
              <Link href="/privacy">Privacidade</Link>
              <Link href="/security">Segurança</Link>
              <Link href="/privacy#contato">Contato</Link>
            </nav>
          </div>
        </div>
        <div className={styles.footerBottom}>
          Uso pessoal e interno. Preencha os dados de contato e revise os textos legais antes de publicar.
        </div>
      </footer>
    </div>
  );
}
