import type { Automation as BackendAutomation, AutomationAction as BackendAction, AutomationTrigger as BackendTrigger } from "../types/backend";

// Structural compatibility with Phase 2 while the backend contract is integrated.
export interface InstagramMedia {
  id: string;
  mediaType: "IMAGE" | "VIDEO" | "CAROUSEL_ALBUM";
  mediaUrl?: string;
  thumbnailUrl?: string;
  caption: string;
  permalink?: string;
  timestamp?: string;
}
export type AutomationTrigger = Omit<BackendTrigger, "type"> & {
  type: BackendTrigger["type"] | "story_reply";
  mediaScope?: "any" | "specific" | "next";
  media?: InstagramMedia;
};
export type AutomationAction = BackendAction & { variants?: string[] };
export type AutomationVersion = { revision: number; savedAt: string; name: string; trigger: AutomationTrigger; actions: AutomationAction[] };
export type QuickAutomation = Omit<BackendAutomation, "trigger" | "actions"> & {
  trigger: AutomationTrigger;
  actions: AutomationAction[];
  revision?: number;
  versions?: AutomationVersion[];
};
export type QuickAutomationDraft = {
  name: string;
  description: string;
  status: BackendAutomation["status"];
  trigger: AutomationTrigger;
  actions: Array<Omit<AutomationAction, "id"> & { id?: string }>;
};
export type AutomationTemplate = {
  id: string;
  name: string;
  description: string;
  unavailableReason?: string;
  config: QuickAutomationDraft;
};

function config(name: string, type: AutomationTrigger["type"], keywords: string[], message: string, comment = false): QuickAutomationDraft {
  return {
    name, description: "", status: "draft",
    trigger: { type, keywords, mediaScope: "any" },
    actions: [
      ...(comment ? [{ type: "public_reply" as const, enabled: true, message: "Te enviei uma mensagem no direct!", variants: ["Te enviei uma mensagem no direct!", "O link está no seu direct. Dá uma olhada!", "Acabei de te enviar os detalhes por mensagem."] }] : []),
      { type: "send_dm", enabled: true, message, buttonText: "Quero receber" },
      { type: "send_link", enabled: true, message: "Aqui está! Acesse pelo botão abaixo.", buttonText: "Acessar conteúdo" },
    ],
  };
}

export const automationTemplates: readonly AutomationTemplate[] = [
  { id: "comment-link", name: "Enviar links por comentário", description: "Converse no direct e entregue um link após um comentário.", config: config("Enviar links por comentário", "comment_any", [], "Oi! Obrigado pelo interesse. Quer receber o link?", true) },
  { id: "new-follower", name: "Boas-vindas a novos seguidores", description: "Boas-vindas por mensagem.", unavailableReason: "O Instagram não disponibiliza um evento de novo seguidor para esta integração. Escolha outro gatilho.", config: config("Boas-vindas a novos seguidores", "new_follower", [], "Que bom ter você por aqui!") },
  { id: "dm-reply", name: "Responder todas as DMs", description: "Inicie uma conversa quando receber uma mensagem.", config: config("Responder todas as DMs", "dm_received", [], "Olá! Obrigado pela mensagem. Como podemos ajudar?") },
  { id: "story-mention", name: "Mencione você no story", description: "Responda quando alguém mencionar seu perfil em um story.", config: config("Mencione você no story", "story_mention", [], "Obrigado por mencionar nosso perfil no seu story!") },
  { id: "comment-keywords", name: "Palavras-chave em comentários", description: "Entregue conteúdo para comentários com palavras específicas.", config: config("Palavras-chave em comentários", "comment_keyword", ["preço", "link", "comprar"], "Oi! Vi seu comentário. Quer receber mais informações?", true) },
  { id: "faq", name: "Menu de perguntas frequentes", description: "Convide a pessoa a acessar sua página de perguntas frequentes.", config: config("Menu de perguntas frequentes", "dm_received", [], "Olá! Reunimos as respostas mais comuns em uma página. Quer acessar?") },
  { id: "story-reply", name: "Resposta ao story", description: "Converse com quem responder ao seu story.", config: config("Resposta ao story", "story_reply", [], "Oi! Obrigado por responder ao nosso story. Quer saber mais?") },
];

export function getAutomationTemplate(value?: string): AutomationTemplate | undefined {
  return automationTemplates.find((template) => template.id === value || template.name === value);
}
