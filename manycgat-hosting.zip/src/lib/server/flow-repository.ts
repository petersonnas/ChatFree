import { promises as fs } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";
import type { Flow, FlowDraft, FlowVersion } from "../../types/flow";
import { parseFlowDraft, validateFlowDatabase, validateFlowPublication } from "./flow-validation";

type FlowDatabase = { schemaVersion: 1; flows: Flow[] };
const filePath = process.env.FLOWS_JSON_PATH ? path.resolve(process.env.FLOWS_JSON_PATH) : path.join(process.cwd(), "data", "flows.json");
let cache: FlowDatabase | null = null;
let loadPromise: Promise<void> | null = null;
let queue: Promise<void> = Promise.resolve();

const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
const now = () => new Date().toISOString();

async function atomicWrite(value: FlowDatabase): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.tmp-${process.pid}-${randomUUID()}`;
  await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(temporary, filePath).catch(async (error) => { await fs.unlink(temporary).catch(() => undefined); throw error; });
}

async function load(): Promise<void> {
  if (cache) return;
  if (!loadPromise) loadPromise = (async () => {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    try {
      const parsed = JSON.parse(await fs.readFile(filePath, "utf8")) as unknown;
      validateFlowDatabase(parsed);
      cache = clone(parsed);
    } catch (error) {
      const code = error && typeof error === "object" && "code" in error ? (error as { code?: string }).code : undefined;
      if (code !== "ENOENT") throw error;
      cache = { schemaVersion: 1, flows: [] };
      await atomicWrite(cache);
    }
  })();
  try { await loadPromise; } finally { loadPromise = null; }
}

async function transact(mutator: (database: FlowDatabase) => void): Promise<void> {
  const operation = queue.catch(() => undefined).then(async () => {
    await load();
    const next = clone(cache as FlowDatabase);
    mutator(next);
    validateFlowDatabase(next);
    cache = next;
    await atomicWrite(next);
  });
  queue = operation.then(() => undefined, () => undefined);
  await operation;
}

export async function listFlows(): Promise<Flow[]> { await load(); return clone((cache as FlowDatabase).flows).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); }
export async function getFlow(id: string): Promise<Flow | undefined> { await load(); return clone((cache as FlowDatabase).flows.find((flow) => flow.id === id)); }

export async function createFlow(input: FlowDraft): Promise<Flow> {
  const draft = parseFlowDraft(input);
  const stamp = now();
  const flow: Flow = { id: `flow-${randomUUID()}`, automationId: draft.automationId, name: draft.name, status: draft.status ?? "draft", nodes: draft.nodes, edges: draft.edges, revision: 1, versions: [], createdAt: stamp, updatedAt: stamp };
  validateFlowPublication(flow);
  await transact((database) => { database.flows.unshift(flow); });
  return clone(flow);
}

export async function updateFlow(id: string, input: FlowDraft): Promise<Flow | undefined> {
  const draft = parseFlowDraft(input);
  let result: Flow | undefined;
  await transact((database) => {
    const flow = database.flows.find((candidate) => candidate.id === id);
    if (!flow) return;
    const previous: FlowVersion = { revision: flow.revision, savedAt: flow.updatedAt, name: flow.name, nodes: clone(flow.nodes), edges: clone(flow.edges) };
    flow.automationId = draft.automationId ?? flow.automationId;
    flow.name = draft.name; flow.status = draft.status ?? flow.status; flow.nodes = draft.nodes; flow.edges = draft.edges;
    validateFlowPublication(flow);
    flow.revision += 1; flow.versions = [...flow.versions, previous].slice(-20); flow.updatedAt = now(); result = flow;
  });
  return clone(result);
}

export async function archiveFlow(id: string): Promise<boolean> {
  let archived = false;
  await transact((database) => {
    const flow = database.flows.find((candidate) => candidate.id === id);
    if (!flow) return;
    flow.status = "archived";
    flow.revision += 1;
    flow.updatedAt = now();
    archived = true;
  });
  return archived;
}
export function flowDatabasePath(): string { return filePath; }
