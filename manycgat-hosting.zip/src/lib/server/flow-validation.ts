import { ValidationError, isRecord } from "./validation";
import type { Flow, FlowDraft, FlowEdge, FlowNode, FlowNodeKind, FlowStatus } from "../../types/flow";

const NODE_KINDS: readonly FlowNodeKind[] = ["trigger", "message", "condition", "delay", "action", "handoff", "end"];
const STATUSES: readonly FlowStatus[] = ["draft", "active", "paused", "archived"];

function text(value: unknown, field: string, max: number, allowEmpty = false): string {
  if (typeof value !== "string" || (!allowEmpty && !value.trim())) throw new ValidationError(`${field} precisa ser um texto${allowEmpty ? "" : " não vazio"}.`);
  if (value.length > max) throw new ValidationError(`${field} excede o limite de ${max} caracteres.`);
  return value;
}

function numberValue(value: unknown, field: string): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 10000) throw new ValidationError(`${field} precisa ser um número entre 0 e 10000.`);
  return value;
}

function parseNode(input: unknown, index: number): FlowNode {
  if (!isRecord(input)) throw new ValidationError(`nodes[${index}] precisa ser um objeto.`);
  const kind = input.kind;
  if (typeof kind !== "string" || !NODE_KINDS.includes(kind as FlowNodeKind)) throw new ValidationError(`nodes[${index}].kind é inválido.`);
  const node: FlowNode = {
    id: text(input.id, `nodes[${index}].id`, 120),
    kind: kind as FlowNodeKind,
    title: text(input.title, `nodes[${index}].title`, 120),
    description: text(input.description, `nodes[${index}].description`, 500, true),
    x: numberValue(input.x, `nodes[${index}].x`),
    y: numberValue(input.y, `nodes[${index}].y`),
  };
  if (input.config !== undefined) {
    if (!isRecord(input.config)) throw new ValidationError(`nodes[${index}].config precisa ser um objeto.`);
    node.config = input.config;
  }
  return node;
}

function parseEdge(input: unknown, index: number): FlowEdge {
  if (!isRecord(input)) throw new ValidationError(`edges[${index}] precisa ser um objeto.`);
  const edge: FlowEdge = {
    id: text(input.id, `edges[${index}].id`, 120),
    source: text(input.source, `edges[${index}].source`, 120),
    target: text(input.target, `edges[${index}].target`, 120),
  };
  if (input.label !== undefined) edge.label = text(input.label, `edges[${index}].label`, 120, true);
  return edge;
}

export function parseFlowDraft(input: unknown): FlowDraft {
  if (!isRecord(input)) throw new ValidationError("O corpo do fluxo precisa ser um objeto.");
  if (!Array.isArray(input.nodes) || input.nodes.length < 1 || input.nodes.length > 100) throw new ValidationError("nodes precisa ter entre 1 e 100 itens.");
  if (!Array.isArray(input.edges) || input.edges.length > 200) throw new ValidationError("edges precisa ter até 200 itens.");
  const nodes = input.nodes.map(parseNode);
  const edges = input.edges.map(parseEdge);
  const nodeIds = new Set(nodes.map((node) => node.id));
  if (nodeIds.size !== nodes.length) throw new ValidationError("nodes contém IDs duplicados.");
  const edgeIds = new Set(edges.map((edge) => edge.id));
  if (edgeIds.size !== edges.length) throw new ValidationError("edges contém IDs duplicados.");
  for (const edge of edges) {
    if (edge.source === edge.target) throw new ValidationError(`A conexão ${edge.id} não pode ligar um nó a ele mesmo.`);
    if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) throw new ValidationError(`A conexão ${edge.id} aponta para um nó inexistente.`);
  }
  const status = input.status === undefined ? undefined : input.status;
  if (status !== undefined && (typeof status !== "string" || !STATUSES.includes(status as FlowStatus))) throw new ValidationError("status de fluxo inválido.");
  return {
    id: input.id === undefined ? undefined : text(input.id, "id", 120),
    automationId: input.automationId === undefined ? undefined : text(input.automationId, "automationId", 120),
    name: text(input.name, "name", 120),
    status: status as FlowStatus | undefined,
    nodes,
    edges,
  };
}

function hasCycle(nodes: readonly FlowNode[], edges: readonly FlowEdge[]): boolean {
  const state = new Map<string, 0 | 1 | 2>();
  const outgoing = new Map<string, string[]>();
  for (const node of nodes) outgoing.set(node.id, []);
  for (const edge of edges) outgoing.get(edge.source)?.push(edge.target);
  function visit(id: string): boolean {
    if (state.get(id) === 1) return true;
    if (state.get(id) === 2) return false;
    state.set(id, 1);
    for (const next of outgoing.get(id) ?? []) if (visit(next)) return true;
    state.set(id, 2);
    return false;
  }
  return nodes.some((node) => visit(node.id));
}

export function validateFlowPublication(flow: Pick<Flow, "status" | "nodes" | "edges" | "name">): void {
  if (flow.status !== "active") return;
  if (!flow.name.trim()) throw new ValidationError("Informe o nome do fluxo antes de ativar.");
  const triggers = flow.nodes.filter((node) => node.kind === "trigger");
  if (triggers.length !== 1) throw new ValidationError("O fluxo ativo precisa ter exatamente um gatilho.");
  if (hasCycle(flow.nodes, flow.edges)) throw new ValidationError("O fluxo ativo não pode conter ciclos.");
  const reachable = new Set<string>([triggers[0].id]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of flow.edges) if (reachable.has(edge.source) && !reachable.has(edge.target)) { reachable.add(edge.target); changed = true; }
  }
  if (reachable.size !== flow.nodes.length) throw new ValidationError("Todos os nós precisam estar conectados ao gatilho antes de ativar.");
  if (!flow.nodes.some((node) => node.kind === "end" || node.kind === "handoff" || node.kind === "action")) throw new ValidationError("Adicione uma ação, transferência ou finalização ao fluxo.");
}

export function validateFlowDatabase(value: unknown): asserts value is { schemaVersion: 1; flows: Flow[] } {
  if (!isRecord(value) || value.schemaVersion !== 1 || !Array.isArray(value.flows)) throw new Error("Banco de fluxos inválido.");
}
