import { NextResponse } from "next/server";
import { ValidationError } from "./validation";

export class HttpError extends Error {
  constructor(public readonly statusCode: number, message: string) {
    super(message);
    this.name = "HttpError";
  }
}

export async function readJson(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch {
    throw new ValidationError("O corpo precisa ser um JSON válido.");
  }
}

export function errorResponse(error: unknown): NextResponse {
  if (error instanceof ValidationError || error instanceof HttpError) {
    return NextResponse.json({ error: error.message }, { status: error.statusCode });
  }
  console.error("Backend request failed", error);
  return NextResponse.json({ error: "Erro interno do servidor." }, { status: 500 });
}

export function notFound(resource = "Recurso"): NextResponse {
  return NextResponse.json({ error: `${resource} não encontrado.` }, { status: 404 });
}
