import { randomUUID } from "node:crypto";
import type { Contact, Conversation, JsonDatabase, Message, QuickReply } from "../../types/backend";
import { HttpError } from "./http";
import { jsonStore, MAX_MESSAGES_PER_CONVERSATION } from "./json-store";
import { incrementMetric } from "./repository";
import { isRecord, normalizedText, ValidationError } from "./validation";

const MAX_MESSAGE_LENGTH = 4000;
const MAX_ID_LENGTH = 160;
const MAX_TAGS = 30;
const MAX_TAG_LENGTH = 50;
const MAX_NOTES = 100;
const MAX_NOTE_LENGTH = 2000;

const DEFAULT_QUICK_REPLIES: QuickReply[] = [
  { id: "greeting", title: "Saudação", text: "Olá! Como posso ajudar?" },
  { id: "follow-up", title: "Acompanhamento", text: "Passando para saber se conseguiu acessar o material." },
  { id: "thanks", title: "Agradecimento", text: "Obrigado pela mensagem! Se precisar, estou por aqui." },
];

type InboxStatus = Conversation["status"];

export interface InboxListQuery {
  status?: InboxStatus;
  query?: string;
  tag?: string;
}

export interface InboxSummary {
  id: string;
  contactId: string;
  instagramUserId: string;
  username: string;
  name: string;
  avatar: string;
  channel: Message["channel"];
  preview: string;
  time: string;
  unread: boolean;
  tag?: string;
  tags: string[];
  status: InboxStatus;
  pauseAutomation: boolean;
  lastMessage?: Message;
}

export interface InboxDetail {
  contact: Contact;
  conversation: Conversation;
  quickReplies: QuickReply[];
}

export interface ManualMessageInput {
  id?: string;
  idempotencyKey?: string;
  text?: string;
  quickReplyId?: string;
  channel: Message["channel"];
}

export interface InboxPatch {
  status?: InboxStatus;
  pauseAutomation?: boolean;
  automationPaused?: boolean;
  note?: string;
  tags?: string[];
  notes?: string[];
}

export interface SendMessageResult {
  message: Message;
  conversation: Conversation;
  idempotent: boolean;
}

function now(): string {
  return new Date().toISOString();
}

function clone<T>(value: T): T {
  return structuredClone(value);
}

function parseId(value: unknown, field: string): string {
  if (typeof value !== "string") throw new ValidationError(`${field} precisa ser um ID válido.`);
  const result = value.trim();
  if (!result || result !== value || result.length > MAX_ID_LENGTH || !/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(result)) {
    throw new ValidationError(`${field} precisa ser um ID válido.`);
  }
  return result;
}

function optionalId(value: unknown, field: string): string | undefined {
  return value === undefined || value === null || value === "" ? undefined : parseId(value, field);
}

function parseMessageText(value: unknown, field = "text"): string {
  if (typeof value !== "string") throw new ValidationError(`${field} precisa ser um texto.`);
  const result = value.trim();
  if (!result) throw new ValidationError(`${field} precisa ser uma mensagem não vazia.`);
  if (result.length > MAX_MESSAGE_LENGTH) throw new ValidationError(`${field} excede o limite de ${MAX_MESSAGE_LENGTH} caracteres.`);
  return result;
}

function parseTags(value: unknown): string[] {
  if (!Array.isArray(value) || value.length > MAX_TAGS) {
    throw new ValidationError(`tags precisa ser uma lista com até ${MAX_TAGS} itens.`);
  }
  const tags = value.map((item, index) => {
    if (typeof item !== "string") throw new ValidationError(`tags[${index}] precisa ser um texto.`);
    const tag = item.trim();
    if (!tag || tag.length > MAX_TAG_LENGTH || /[\r\n]/.test(tag)) {
      throw new ValidationError(`tags[${index}] precisa ter entre 1 e ${MAX_TAG_LENGTH} caracteres.`);
    }
    return tag;
  });
  const normalized = tags.map(normalizedText);
  if (new Set(normalized).size !== normalized.length) throw new ValidationError("tags não podem conter duplicatas.");
  return tags;
}

function parseNotes(value: unknown): string[] {
  if (!Array.isArray(value) || value.length > MAX_NOTES) {
    throw new ValidationError(`notes precisa ser uma lista com até ${MAX_NOTES} itens.`);
  }
  return value.map((item, index) => {
    if (typeof item !== "string") throw new ValidationError(`notes[${index}] precisa ser um texto.`);
    const note = item.trim();
    if (!note || note.length > MAX_NOTE_LENGTH) {
      throw new ValidationError(`notes[${index}] precisa ter entre 1 e ${MAX_NOTE_LENGTH} caracteres.`);
    }
    return note;
  });
}

function parseNote(value: unknown): string {
  if (typeof value !== "string") throw new ValidationError("note precisa ser um texto.");
  if (value.length > MAX_NOTE_LENGTH) throw new ValidationError(`note excede o limite de ${MAX_NOTE_LENGTH} caracteres.`);
  return value.trim();
}

export function parseInboxListQuery(input: { status: string | null; q: string | null; tag: string | null }): InboxListQuery {
  const status = input.status === null || input.status === "" ? undefined : input.status;
  if (status !== undefined && status !== "open" && status !== "closed") {
    throw new ValidationError("status precisa ser open ou closed.");
  }
  const query = input.q === null || input.q.trim() === "" ? undefined : input.q.trim();
  if (query && query.length > 120) throw new ValidationError("q excede o limite de 120 caracteres.");
  const tag = input.tag === null || input.tag.trim() === "" ? undefined : input.tag.trim();
  if (tag && tag.length > MAX_TAG_LENGTH) throw new ValidationError(`tag excede o limite de ${MAX_TAG_LENGTH} caracteres.`);
  return { status: status as InboxStatus | undefined, query, tag };
}

export function parseManualMessage(input: unknown): ManualMessageInput {
  if (!isRecord(input)) throw new ValidationError("O corpo da mensagem precisa ser um objeto.");
  const id = optionalId(input.id ?? input.messageId, "id");
  const idempotencyKey = optionalId(input.idempotencyKey ?? input.clientMessageId ?? input.requestId, "idempotencyKey");
  const quickReplyId = optionalId(input.quickReplyId, "quickReplyId");
  const rawText = input.text ?? input.message;
  if (rawText !== undefined && typeof rawText !== "string") throw new ValidationError("text precisa ser um texto.");
  const text = rawText === undefined ? undefined : parseMessageText(rawText);
  if (!text && !quickReplyId) throw new ValidationError("Informe text ou quickReplyId.");
  const channel = input.channel === undefined ? "dm" : input.channel;
  if (channel !== "dm" && channel !== "comment" && channel !== "story") {
    throw new ValidationError("channel contém um valor inválido.");
  }
  return { id, idempotencyKey, text, quickReplyId, channel };
}

export function parseInboxPatch(input: unknown): InboxPatch {
  if (!isRecord(input)) throw new ValidationError("O corpo do Inbox precisa ser um objeto.");
  const contact = input.contact;
  if (contact !== undefined && !isRecord(contact)) throw new ValidationError("contact precisa ser um objeto.");
  const tagsValue = input.tags ?? (isRecord(contact) ? contact.tags : undefined);
  const notesValue = input.notes ?? (isRecord(contact) ? contact.notes : undefined);
  const patch: InboxPatch = {};
  if (input.status !== undefined) {
    if (input.status !== "open" && input.status !== "closed") throw new ValidationError("status precisa ser open ou closed.");
    patch.status = input.status;
  }
  if (input.pauseAutomation !== undefined) {
    if (typeof input.pauseAutomation !== "boolean") throw new ValidationError("pauseAutomation precisa ser booleano.");
    patch.pauseAutomation = input.pauseAutomation;
  }
  if (input.automationPaused !== undefined) {
    if (typeof input.automationPaused !== "boolean") throw new ValidationError("automationPaused precisa ser booleano.");
    if (patch.pauseAutomation !== undefined && patch.pauseAutomation !== input.automationPaused) {
      throw new ValidationError("pauseAutomation e automationPaused precisam ter o mesmo valor.");
    }
    patch.automationPaused = input.automationPaused;
  }
  if (input.note !== undefined) patch.note = parseNote(input.note);
  if (tagsValue !== undefined) patch.tags = parseTags(tagsValue);
  if (notesValue !== undefined) patch.notes = parseNotes(notesValue);
  if (Object.keys(patch).length === 0) throw new ValidationError("Informe ao menos um campo para atualizar.");
  return patch;
}

function normalizedContact(contact: Contact): Contact {
  const notes = [...(contact.notes ?? [])];
  return { ...clone(contact), tags: [...contact.tags], notes, note: contact.note ?? notes.at(-1) ?? "" };
}

function contactFor(database: JsonDatabase, conversation: Conversation): Contact {
  const contact = database.contacts.find((item) => item.instagramUserId === conversation.instagramUserId);
  if (contact) return normalizedContact(contact);
  return {
    id: `contact-${conversation.instagramUserId}`,
    instagramUserId: conversation.instagramUserId,
    username: conversation.username,
    displayName: undefined,
    tags: [],
    notes: [],
    note: "",
    createdAt: conversation.createdAt,
    updatedAt: conversation.updatedAt,
    lastInteractionAt: conversation.lastMessageAt,
  };
}

function normalizedConversation(conversation: Conversation): Conversation {
  const paused = conversation.pauseAutomation ?? conversation.automationPaused ?? false;
  return {
    ...clone(conversation),
    pauseAutomation: paused,
    automationPaused: paused,
    note: conversation.note ?? conversation.notes?.at(-1) ?? "",
    notes: [...(conversation.notes ?? [])],
    messages: clone(conversation.messages),
  };
}

function quickRepliesFor(database: JsonDatabase): QuickReply[] {
  return clone(database.quickReplies?.length ? database.quickReplies : DEFAULT_QUICK_REPLIES);
}

function detailFor(database: JsonDatabase, conversation: Conversation): InboxDetail {
  const contact = contactFor(database, conversation);
  const conversationWithContact = {
    ...conversation,
    note: contact.note ?? contact.notes?.at(-1) ?? "",
    notes: [...(contact.notes ?? [])],
  };
  return {
    contact,
    conversation: normalizedConversation(conversationWithContact),
    quickReplies: quickRepliesFor(database),
  };
}

function summaryFor(database: JsonDatabase, conversation: Conversation): InboxSummary {
  const contact = contactFor(database, conversation);
  const lastMessage = conversation.messages.at(-1);
  const channel = lastMessage?.channel ?? "dm";
  return {
    id: conversation.id,
    contactId: contact.id,
    instagramUserId: conversation.instagramUserId,
    username: contact.username || conversation.username,
    name: contact.displayName || contact.username || conversation.username,
    avatar: (contact.displayName || contact.username || conversation.username).slice(0, 2).toUpperCase(),
    channel,
    preview: lastMessage?.text ?? "",
    time: conversation.lastMessageAt,
    unread: conversation.status === "open" && lastMessage?.direction === "inbound",
    tag: contact.tags[0],
    tags: [...contact.tags],
    status: conversation.status,
    pauseAutomation: conversation.pauseAutomation ?? false,
    lastMessage: lastMessage ? clone(lastMessage) : undefined,
  };
}

function findConversation(database: JsonDatabase, id: string): Conversation | undefined {
  return database.conversations.find((item) => item.id === id) ?? (() => {
    const contact = database.contacts.find((item) => item.id === id);
    return contact ? database.conversations.find((item) => item.instagramUserId === contact.instagramUserId) : undefined;
  })();
}

export class InboxRepository {
  constructor(private readonly store = jsonStore) {}

  async list(query: InboxListQuery = {}): Promise<InboxSummary[]> {
    const database = await this.store.snapshot();
    const normalizedQuery = query.query ? normalizedText(query.query) : undefined;
    const normalizedTag = query.tag ? normalizedText(query.tag) : undefined;
    return database.conversations
      .filter((conversation) => !query.status || conversation.status === query.status)
      .map((conversation) => summaryFor(database, conversation))
      .filter((item) => !normalizedQuery || normalizedText(`${item.name} ${item.username} ${item.preview}`).includes(normalizedQuery))
      .filter((item) => !normalizedTag || item.tags.some((tag) => normalizedText(tag) === normalizedTag))
      .sort((a, b) => b.time.localeCompare(a.time));
  }

  async get(id: string): Promise<InboxDetail | undefined> {
    const parsedId = parseId(id, "id");
    const database = await this.store.snapshot();
    const conversation = findConversation(database, parsedId);
    return conversation ? detailFor(database, conversation) : undefined;
  }

  async send(id: string, input: ManualMessageInput): Promise<SendMessageResult | undefined> {
    const conversationId = parseId(id, "id");
    let result: SendMessageResult | undefined;
    await this.store.transact((database) => {
      const conversation = findConversation(database, conversationId);
      if (!conversation) return;
      const quickReply = input.quickReplyId ? quickRepliesFor(database).find((item) => item.id === input.quickReplyId) : undefined;
      if (input.quickReplyId && !quickReply) throw new ValidationError("quickReplyId não encontrado.");
      const text = input.text ?? quickReply?.text;
      if (!text) throw new ValidationError("Informe text ou quickReplyId.");
      const matching = conversation.messages.find((message) =>
        message.direction === "outbound" &&
        ((input.idempotencyKey && message.idempotencyKey === input.idempotencyKey) || (input.id && message.id === input.id)),
      );
      if (matching) {
        if (matching.text !== text || matching.channel !== input.channel) throw new HttpError(409, "A chave de idempotência já foi usada com outra mensagem.");
        result = { message: clone(matching), conversation: detailFor(database, conversation).conversation, idempotent: true };
        return;
      }
      if (input.id && database.conversations.some((item) => item.messages.some((message) => message.id === input.id))) {
        throw new HttpError(409, "id de mensagem já está em uso.");
      }
      const timestamp = now();
      const message: Message = {
        id: input.id ?? randomUUID(),
        direction: "outbound",
        channel: input.channel,
        text,
        status: "mocked",
        idempotencyKey: input.idempotencyKey,
        createdAt: timestamp,
      };
      conversation.messages.push(message);
      if (conversation.messages.length > MAX_MESSAGES_PER_CONVERSATION) conversation.messages = conversation.messages.slice(-MAX_MESSAGES_PER_CONVERSATION);
      conversation.updatedAt = timestamp;
      conversation.lastMessageAt = timestamp;
      const contact = database.contacts.find((item) => item.instagramUserId === conversation.instagramUserId);
      if (contact) {
        contact.updatedAt = timestamp;
        contact.lastInteractionAt = timestamp;
      }
      incrementMetric(database, "dmsSent");
      if (input.channel === "dm") incrementMetric(database, "mockedDms");
      database.updatedAt = timestamp;
      result = { message: clone(message), conversation: detailFor(database, conversation).conversation, idempotent: false };
    });
    return result;
  }

  async update(id: string, patch: InboxPatch): Promise<InboxDetail | undefined> {
    const conversationId = parseId(id, "id");
    let result: InboxDetail | undefined;
    await this.store.transact((database) => {
      const conversation = findConversation(database, conversationId);
      if (!conversation) return;
      let contact = database.contacts.find((item) => item.instagramUserId === conversation.instagramUserId);
      if (!contact && (patch.tags !== undefined || patch.notes !== undefined || patch.note !== undefined)) {
        contact = {
          id: `contact-${conversation.instagramUserId}`,
          instagramUserId: conversation.instagramUserId,
          username: conversation.username,
          tags: [],
          notes: [],
          note: "",
          createdAt: conversation.createdAt,
          updatedAt: conversation.updatedAt,
          lastInteractionAt: conversation.lastMessageAt,
        };
        database.contacts.unshift(contact);
      }
      if (patch.status !== undefined) conversation.status = patch.status;
      const paused = patch.automationPaused ?? patch.pauseAutomation;
      if (paused !== undefined) {
        conversation.pauseAutomation = paused;
        conversation.automationPaused = paused;
      }
      if (contact && patch.tags !== undefined) contact.tags = [...patch.tags];
      if (contact && patch.notes !== undefined) {
        contact.notes = [...patch.notes];
        contact.note = patch.notes.at(-1) ?? "";
      }
      if (contact && patch.note !== undefined) {
        contact.note = patch.note;
        contact.notes = patch.note ? [patch.note] : [];
      }
      const timestamp = now();
      conversation.updatedAt = timestamp;
      if (contact) contact.updatedAt = timestamp;
      database.updatedAt = timestamp;
      result = detailFor(database, conversation);
    });
    return result;
  }
}

export const inboxRepository = new InboxRepository();

export async function listInbox(query: InboxListQuery = {}): Promise<InboxSummary[]> {
  return inboxRepository.list(query);
}

export async function getInbox(id: string): Promise<InboxDetail | undefined> {
  return inboxRepository.get(id);
}

export async function sendInboxMessage(id: string, input: ManualMessageInput): Promise<SendMessageResult | undefined> {
  return inboxRepository.send(id, input);
}

export async function updateInbox(id: string, patch: InboxPatch): Promise<InboxDetail | undefined> {
  return inboxRepository.update(id, patch);
}
