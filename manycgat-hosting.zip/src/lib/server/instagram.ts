import { randomUUID } from "node:crypto";
import type { InstagramMedia } from "../../types/backend";

export interface ProviderResult {
  ok: boolean;
  mode: "mock" | "live";
  providerMessageId?: string;
  error?: string;
}

interface InstagramConfig {
  accessToken?: string;
  accountId?: string;
  appSecret?: string;
  mock: boolean;
  graphBaseUrl: string;
}

function config(): InstagramConfig {
  const accessToken = process.env.INSTAGRAM_ACCESS_TOKEN ?? process.env.META_ACCESS_TOKEN;
  const accountId = process.env.INSTAGRAM_ACCOUNT_ID ?? process.env.META_INSTAGRAM_ACCOUNT_ID;
  const appSecret = process.env.META_APP_SECRET;
  const explicitlyMock = ["1", "true", "yes"].includes((process.env.INSTAGRAM_MOCK_MODE ?? "").toLowerCase());
  return {
    accessToken,
    accountId,
    appSecret,
    mock: explicitlyMock || !accessToken || !accountId,
    graphBaseUrl: (process.env.META_GRAPH_API_BASE_URL ?? `https://graph.${process.env.INSTAGRAM_LOGIN_MODE === "instagram" ? "instagram" : "facebook"}.com/${process.env.META_GRAPH_API_VERSION ?? "v23.0"}`).replace(/\/$/, ""),
  };
}

function safeGraphBaseUrl(value: string): string {
  try {
    const url = new URL(value);
    url.username = "";
    url.password = "";
    url.search = "";
    url.hash = "";
    return url.toString().replace(/\/$/, "");
  } catch {
    return "configured";
  }
}

export function getInstagramIntegrationStatus(): {
  mode: "mock" | "live";
  accountConfigured: boolean;
  webhookSignatureConfigured: boolean;
} {
  const current = config();
  return {
    mode: current.mock ? "mock" : "live",
    accountConfigured: Boolean(current.accessToken && current.accountId),
    webhookSignatureConfigured: Boolean(current.appSecret),
  };
}

export function getInstagramIntegrationDiagnostics(): {
  status: "ok" | "degraded";
  mode: "mock" | "live";
  accountConfigured: boolean;
  accessTokenConfigured: boolean;
  accountIdConfigured: boolean;
  appSecretConfigured: boolean;
  verifyTokenConfigured: boolean;
  graphApiBaseUrl: string;
  mockReason?: "explicit" | "credentials_missing";
} {
  const current = config();
  const explicitMock = ["1", "true", "yes"].includes((process.env.INSTAGRAM_MOCK_MODE ?? "").toLowerCase());
  const accountConfigured = Boolean(current.accessToken && current.accountId);
  return {
    status: current.mock ? "degraded" : "ok",
    mode: current.mock ? "mock" : "live",
    accountConfigured,
    accessTokenConfigured: Boolean(current.accessToken),
    accountIdConfigured: Boolean(current.accountId),
    appSecretConfigured: Boolean(current.appSecret),
    verifyTokenConfigured: Boolean(getWebhookVerifyToken()),
    graphApiBaseUrl: safeGraphBaseUrl(current.graphBaseUrl),
    mockReason: current.mock ? explicitMock ? "explicit" : "credentials_missing" : undefined,
  };
}

function safeProviderError(error: unknown, current: InstagramConfig): string {
  const value = error instanceof Error ? error.message : "Falha de rede com a Meta Graph API.";
  let safe = value;
  for (const secret of [current.accessToken, current.appSecret]) {
    if (secret) safe = safe.replaceAll(secret, "[redacted]");
  }
  return safe.slice(0, 500);
}

async function postGraph(pathname: string, body: unknown): Promise<ProviderResult> {
  const current = config();
  if (current.mock) {
    return { ok: true, mode: "mock", providerMessageId: `mock-${randomUUID()}` };
  }

  try {
    const response = await fetch(`${current.graphBaseUrl}/${pathname.replace(/^\//, "")}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${current.accessToken}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    });
    const responseText = await response.text();
    let parsed: unknown;
    try {
      parsed = responseText ? JSON.parse(responseText) : undefined;
    } catch {
      parsed = undefined;
    }

    if (!response.ok) {
      const message = typeof parsed === "object" && parsed !== null && "error" in parsed
        ? JSON.stringify((parsed as { error: unknown }).error)
        : responseText.slice(0, 500);
      return { ok: false, mode: "live", error: `Meta Graph API ${response.status}: ${message}` };
    }

    const providerMessageId = typeof parsed === "object" && parsed !== null && "message_id" in parsed
      ? String((parsed as { message_id: unknown }).message_id)
      : undefined;
    return { ok: true, mode: "live", providerMessageId };
  } catch (error) {
    return { ok: false, mode: "live", error: safeProviderError(error, current) };
  }
}

export async function sendDirectMessage(recipientId: string, text: string): Promise<ProviderResult> {
  const current = config();
  return postGraph(`${current.accountId}/messages`, {
    recipient: { id: recipientId },
    message: { text },
  });
}

export async function replyToComment(commentId: string, text: string): Promise<ProviderResult> {
  return postGraph(`${commentId}/replies`, { message: text });
}

export function getWebhookAppSecret(): string | undefined {
  return config().appSecret;
}

export function getWebhookVerifyToken(): string | undefined {
  return process.env.META_VERIFY_TOKEN ?? process.env.INSTAGRAM_WEBHOOK_VERIFY_TOKEN ?? process.env.META_WEBHOOK_VERIFY_TOKEN;
}

export async function listInstagramMedia(after?: string): Promise<{ data: InstagramMedia[]; mode: "mock" | "live"; paging?: { after?: string } }> {
  const current = config();
  if (current.mock) {
    return { mode: "mock", data: [
      { id: "media-demo-01", mediaType: "IMAGE", mediaUrl: "/demo/guide.svg", caption: "Exemplo · Comente GUIA para receber o material no Direct." },
      { id: "media-demo-02", mediaType: "IMAGE", mediaUrl: "/demo/community.svg", caption: "Exemplo · Sua próxima conversa começa aqui. Comente GRUPO." },
      { id: "media-demo-03", mediaType: "IMAGE", mediaUrl: "/demo/class.svg", caption: "Exemplo · Uma aula para tirar a sua ideia do papel. Comente AULA." },
    ] };
  }
  const url = new URL(`${current.graphBaseUrl}/${encodeURIComponent(current.accountId!)}/media`);
  url.searchParams.set("fields", "id,caption,media_type,media_url,thumbnail_url,permalink,timestamp");
  url.searchParams.set("limit", "24");
  if (after) url.searchParams.set("after", after);
  const response = await fetch(url, { headers: { authorization: `Bearer ${current.accessToken}` }, cache: "no-store", signal: AbortSignal.timeout(15000) });
  const payload = await response.json() as { data?: Array<{ id: string; caption?: string; media_type?: string; media_url?: string; thumbnail_url?: string; permalink?: string; timestamp?: string }>; paging?: { next?: string; cursors?: { after?: string } } };
  if (!response.ok) throw new Error("Não foi possível carregar as publicações. Verifique a conexão e a permissão de leitura de mídia do Instagram.");
  return { mode: "live", data: (payload.data ?? []).map((item) => ({ id: item.id, caption: item.caption ?? "", mediaType: item.media_type === "VIDEO" ? "VIDEO" : item.media_type === "CAROUSEL_ALBUM" ? "CAROUSEL_ALBUM" : "IMAGE", mediaUrl: item.media_url, thumbnailUrl: item.thumbnail_url, permalink: item.permalink, timestamp: item.timestamp })), paging: payload.paging?.next ? { after: payload.paging.cursors?.after } : undefined };
}
