import { promises as fs } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { JsonDatabase } from "../../types/backend";
import { validateDatabase } from "./validation";
import { createSeedDatabase } from "./seed";

const MAX_STORED_EVENTS = 2000;
const MAX_MESSAGES_PER_CONVERSATION = 200;

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

export class JsonStore {
  private cache: JsonDatabase | null = null;
  private loadPromise: Promise<void> | null = null;
  private mutationQueue: Promise<void> = Promise.resolve();
  private writeQueue: Promise<void> = Promise.resolve();
  private pendingWrites = 0;
  private lastLoadedAt?: string;
  private lastWriteAt?: string;

  public readonly filePath: string;

  constructor(filePath = resolveDatabasePath()) {
    this.filePath = filePath;
  }

  async snapshot(): Promise<JsonDatabase> {
    await this.ensureLoaded();
    return clone(this.cache as JsonDatabase);
  }

  async transact(mutator: (database: JsonDatabase) => JsonDatabase | void): Promise<JsonDatabase> {
    let result: JsonDatabase | undefined;
    const operation = this.mutationQueue.catch(() => undefined).then(async () => {
      await this.ensureLoaded();
      const next = clone(this.cache as JsonDatabase);
      const changed = mutator(next);
      result = changed ?? next;
      validateDatabase(result);
      this.cache = clone(result);
      this.pendingWrites += 1;
      await this.enqueueWrite(this.cache);
      return result;
    });

    this.mutationQueue = operation.then(() => undefined, () => undefined);
    await operation;
    return clone(result as JsonDatabase);
  }

  async flush(): Promise<void> {
    await this.writeQueue;
  }

  async health(): Promise<{
    ready: boolean;
    cached: boolean;
    pendingWrites: number;
    filePath: string;
    lastLoadedAt?: string;
    lastWriteAt?: string;
  }> {
    try {
      await this.ensureLoaded();
      return {
        ready: true,
        cached: this.cache !== null,
        pendingWrites: this.pendingWrites,
        filePath: this.filePath,
        lastLoadedAt: this.lastLoadedAt,
        lastWriteAt: this.lastWriteAt,
      };
    } catch {
      return { ready: false, cached: false, pendingWrites: this.pendingWrites, filePath: this.filePath };
    }
  }

  private async ensureLoaded(): Promise<void> {
    if (this.cache) return;
    if (!this.loadPromise) this.loadPromise = this.loadFromDisk();
    try {
      await this.loadPromise;
    } finally {
      this.loadPromise = null;
    }
  }

  private async loadFromDisk(): Promise<void> {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });

    try {
      const text = await fs.readFile(this.filePath, "utf8");
      const parsed: unknown = JSON.parse(text);
      validateDatabase(parsed);
      this.cache = clone(parsed);
      this.lastLoadedAt = new Date().toISOString();
      return;
    } catch (error) {
      const code = error && typeof error === "object" && "code" in error ? (error as { code?: string }).code : undefined;
      if (code !== "ENOENT") throw error;
    }

    const seed = createSeedDatabase();
    validateDatabase(seed);
    this.cache = clone(seed);
    await this.atomicWrite(this.cache);
    this.lastLoadedAt = new Date().toISOString();
  }

  private async enqueueWrite(database: JsonDatabase): Promise<void> {
    const payload = JSON.stringify(database, null, 2) + "\n";
    const operation = this.writeQueue
      .catch(() => undefined)
      .then(async () => {
        await this.atomicWrite(payload);
        this.pendingWrites = Math.max(0, this.pendingWrites - 1);
      });
    this.writeQueue = operation;
    await operation;
  }

  private async atomicWrite(databaseOrPayload: JsonDatabase | string): Promise<void> {
    const payload = typeof databaseOrPayload === "string" ? databaseOrPayload : JSON.stringify(databaseOrPayload, null, 2) + "\n";
    const temporaryPath = `${this.filePath}.tmp-${process.pid}-${randomUUID()}`;
    let handle: Awaited<ReturnType<typeof fs.open>> | undefined;

    try {
      handle = await fs.open(temporaryPath, "w");
      await handle.writeFile(payload, "utf8");
      await handle.sync();
      await handle.close();
      handle = undefined;
      await fs.rename(temporaryPath, this.filePath);
      this.lastWriteAt = new Date().toISOString();
    } catch (error) {
      if (handle) await handle.close().catch(() => undefined);
      await fs.unlink(temporaryPath).catch(() => undefined);
      throw error;
    }
  }
}

export function resolveDatabasePath(): string {
  const configured = process.env.JSON_DB_PATH;
  return configured ? path.resolve(configured) : path.join(process.cwd(), "data", "db.json");
}

export const jsonStore = new JsonStore();

export { MAX_MESSAGES_PER_CONVERSATION, MAX_STORED_EVENTS };
