import { timingSafeEqual } from "node:crypto";
import { isValidSessionToken } from "../session";

const SESSION_COOKIE = "conversa_session";

function sameSecret(left: string, right: string): boolean {
  const a = Buffer.from(left, "utf8");
  const b = Buffer.from(right, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Protects operational endpoints without ever returning the configured key. */
export async function isAuthorizedForOperations(request: Request): Promise<boolean> {
  const appKey = process.env.APP_ACCESS_KEY;
  const operationsKey = process.env.OPS_ACCESS_KEY ?? appKey;
  if (!operationsKey) return process.env.NODE_ENV !== "production";

  const suppliedKey = request.headers.get("x-ops-key") ?? request.headers.get("x-operation-key");
  if (suppliedKey && sameSecret(suppliedKey, operationsKey)) return true;

  const authorization = request.headers.get("authorization");
  if (authorization?.startsWith("Bearer ") && sameSecret(authorization.slice("Bearer ".length), operationsKey)) return true;

  const sessionToken = request.headers.get("cookie")?.split(";").map((item) => item.trim()).find((item) => item.startsWith(`${SESSION_COOKIE}=`))?.slice(SESSION_COOKIE.length + 1);
  return Boolean(appKey && await isValidSessionToken(sessionToken, appKey));
}

export function operationsAuthError(): Response {
  return Response.json(
    { error: process.env.OPS_ACCESS_KEY || process.env.APP_ACCESS_KEY ? "Autenticação necessária." : "Proteção operacional não configurada." },
    { status: process.env.OPS_ACCESS_KEY || process.env.APP_ACCESS_KEY ? 401 : 503, headers: { "cache-control": "no-store" } },
  );
}

export async function requireOperationsAccess(request: Request): Promise<Response | undefined> {
  if (await isAuthorizedForOperations(request)) return undefined;
  return operationsAuthError();
}
