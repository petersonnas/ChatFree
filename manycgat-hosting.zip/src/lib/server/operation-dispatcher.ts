import type { Message, SendOperation } from "../../types/backend";
import { addConversationMessage, incrementMetric } from "./repository";
import { jsonStore } from "./json-store";
import { replyToComment, sendDirectMessage, type ProviderResult } from "./instagram";
import { operationQueue, type EnqueueSendInput, type OperationProcessResult } from "./operation-queue";

export async function enqueueSendOperation(input: EnqueueSendInput): Promise<ReturnType<typeof operationQueue.enqueue>> {
  return operationQueue.enqueue(input);
}

async function deliver(operation: SendOperation): Promise<ProviderResult> {
  if (operation.kind === "dm") return sendDirectMessage(operation.recipientId as string, operation.text);
  return replyToComment(operation.commentId as string, operation.text);
}

function messageStatus(operation: SendOperation): Message["status"] {
  if (operation.status === "failed") return "failed";
  if (operation.status === "sent") return operation.providerMode === "mock" ? "mocked" : "sent";
  return "queued";
}

async function recordOperationResult(result: OperationProcessResult): Promise<void> {
  const operation = result.operation;
  const databaseAfterOperation = await operationQueue.snapshot();
  await jsonStore.transact((database) => {
    if (operation.instagramUserId) {
      const conversation = database.conversations.find((item) => item.instagramUserId === operation.instagramUserId);
      const message = conversation?.messages.find((item) => item.operationId === operation.id || item.idempotencyKey === operation.idempotencyKey);
      if (message) {
        message.status = messageStatus(operation);
        message.providerMessageId = operation.providerMessageId;
      }
    }

    if (!operation.eventId || (operation.status !== "sent" && operation.status !== "failed")) {
      database.updatedAt = new Date().toISOString();
      return;
    }

    const event = database.events.find((item) => item.id === operation.eventId);
    if (!event || event.deliveryRecorded) {
      database.updatedAt = new Date().toISOString();
      return;
    }

    const eventOperations = databaseAfterOperation.sends.filter((item) => item.eventId === operation.eventId);
    if (eventOperations.some((item) => item.status === "queued" || item.status === "processing")) {
      database.updatedAt = new Date().toISOString();
      return;
    }

    const failed = eventOperations.some((item) => item.status === "failed");
    event.status = failed ? "failed" : "processed";
    event.processedAt = new Date().toISOString();
    event.error = eventOperations.find((item) => item.status === "failed")?.error;
    event.deliveryRecorded = true;

    const automation = event.automationId ? database.automations.find((item) => item.id === event.automationId) : undefined;
    if (automation) {
      automation.stats.runs += 1;
      automation.stats.messagesSent += eventOperations.filter((item) => item.status === "sent" && item.kind === "dm").length;
      automation.stats.lastRunAt = event.processedAt;
    }
    for (const item of eventOperations) {
      if (item.status === "sent") {
        if (item.channel === "dm") {
          incrementMetric(database, "dmsSent");
          if (item.providerMode === "mock") incrementMetric(database, "mockedDms");
        } else {
          incrementMetric(database, "publicRepliesSent");
          if (item.providerMode === "mock") incrementMetric(database, "mockedPublicReplies");
        }
      } else if (item.channel === "dm") {
        incrementMetric(database, "failedDms");
      } else {
        incrementMetric(database, "failedPublicReplies");
      }
    }
    if (failed) incrementMetric(database, "failedWebhookEvents");
    database.updatedAt = new Date().toISOString();
  });
}

export async function processPendingSendOperations(options: { limit?: number; ids?: string[] } = {}): Promise<OperationProcessResult[]> {
  const results = await operationQueue.process(deliver, options);
  for (const result of results) await recordOperationResult(result);
  return results;
}
