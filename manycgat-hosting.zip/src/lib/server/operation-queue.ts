import { promises as fs } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";
import type {
  DataDeletionRequest,
  OperationDatabase,
  OperationSendKind,
  SendOperation,
  WebhookLog,
} from "../../types/backend";

const MINUTE_MS = 60_000;
const MAX_BACKOFF_MS = 5 * 60_000;
const MAX_SENDS = 5_000;
const MAX_WEBHOOK_LOGS = 2_000;
const MAX_DELETION_REQUESTS = 500;

export interface EnqueueSendInput {
  idempotencyKey: string;
  kind: OperationSendKind;
  recipientId?: string;
  commentId?: string;
  text: string;
  instagramUserId?: string;
  username?: string;
  channel: "dm" | "comment";
  automationId?: string;
  eventId?: string;
  messageId?: string;
  maxAttempts?: number;
}

export interface OperationDeliveryResult {
  ok: boolean;
  mode: "mock" | "live";
  providerMessageId?: string;
  error?: string;
}

export interface OperationProcessResult {
  operation: SendOperation;
  result?: OperationDeliveryResult;
  skippedReason?: "rate_limited";
}

export interface OperationQueueHealth {
  ready: boolean;
  cached: boolean;
  pendingWrites: number;
  filePath: string;
  sendsPerMinute: number;
  counts: Record<SendOperation["status"], number>;
  lastLoadedAt?: string;
  lastWriteAt?: string;
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function isoNow(): string {
  return new Date().toISOString();
}

function positiveInteger(value: string | undefined, fallback: number, maximum: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.min(Math.floor(parsed), maximum) : fallback;
}

export function getOperationQueueConfig(): { sendsPerMinute: number; maxAttempts: number; retryBaseMs: number } {
  return {
    sendsPerMinute: positiveInteger(
      process.env.OPERATION_SENDS_PER_MINUTE ?? process.env.LOCAL_SENDS_PER_MINUTE ?? process.env.INSTAGRAM_SENDS_PER_MINUTE ?? process.env.INSTAGRAM_LOCAL_SENDS_PER_MINUTE ?? process.env.META_SEND_LIMIT_PER_MINUTE ?? process.env.META_LOCAL_SENDS_PER_MINUTE,
      30,
      10_000,
    ),
    maxAttempts: positiveInteger(process.env.OPERATION_MAX_ATTEMPTS, 3, 10),
    retryBaseMs: positiveInteger(process.env.OPERATION_RETRY_BASE_MS, 1_000, 60_000),
  };
}

export function resolveOperationQueuePath(): string {
  const configured = process.env.OPERATION_QUEUE_PATH ?? process.env.SEND_QUEUE_PATH;
  if (configured) return path.resolve(configured);
  if (process.env.DATA_DIR) return path.join(path.resolve(process.env.DATA_DIR), "operation-queue.json");
  if (process.env.JSON_DB_PATH) return path.join(path.dirname(path.resolve(process.env.JSON_DB_PATH)), "operation-queue.json");
  return path.join(process.cwd(), "data", "operation-queue.json");
}

function emptyDatabase(): OperationDatabase {
  const now = isoNow();
  return { schemaVersion: 1, createdAt: now, updatedAt: now, sends: [], webhooks: [], deletionRequests: [] };
}

function validateDatabase(value: unknown): asserts value is OperationDatabase {
  if (!value || typeof value !== "object") throw new Error("Arquivo de operações inválido.");
  const database = value as Partial<OperationDatabase>;
  if (database.schemaVersion !== 1 || !Array.isArray(database.sends) || !Array.isArray(database.webhooks) || !Array.isArray(database.deletionRequests)) {
    throw new Error("Arquivo de operações incompatível.");
  }
}

function retryDelay(attempts: number): number {
  const { retryBaseMs } = getOperationQueueConfig();
  return Math.min(MAX_BACKOFF_MS, retryBaseMs * 2 ** Math.max(0, attempts - 1));
}

function isDue(operation: SendOperation, now: number): boolean {
  return !operation.nextAttemptAt || Date.parse(operation.nextAttemptAt) <= now;
}

function isInLastMinute(value: string | undefined, now: number): boolean {
  if (!value) return false;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) && timestamp > now - MINUTE_MS && timestamp <= now;
}

function counts(database: OperationDatabase): Record<SendOperation["status"], number> {
  return {
    queued: database.sends.filter((item) => item.status === "queued").length,
    processing: database.sends.filter((item) => item.status === "processing").length,
    sent: database.sends.filter((item) => item.status === "sent").length,
    failed: database.sends.filter((item) => item.status === "failed").length,
  };
}

export class OperationQueue {
  private cache: OperationDatabase | null = null;
  private loadPromise: Promise<void> | null = null;
  private mutationQueue: Promise<void> = Promise.resolve();
  private writeQueue: Promise<void> = Promise.resolve();
  private pendingWrites = 0;
  private lastLoadedAt?: string;
  private lastWriteAt?: string;

  public readonly filePath: string;

  constructor(filePath = resolveOperationQueuePath()) {
    this.filePath = filePath;
  }

  async snapshot(): Promise<OperationDatabase> {
    await this.ensureLoaded();
    return clone(this.cache as OperationDatabase);
  }

  async enqueue(input: EnqueueSendInput): Promise<{ operation: SendOperation; created: boolean }> {
    if (!input.idempotencyKey || input.idempotencyKey.length > 300) throw new Error("Chave de idempotência inválida.");
    if (!input.text || input.text.length > 4_000) throw new Error("Texto do envio inválido.");
    if (input.kind === "dm" && !input.recipientId) throw new Error("Destinatário do Direct ausente.");
    if (input.kind === "comment" && !input.commentId) throw new Error("Comentário ausente.");

    let result!: { operation: SendOperation; created: boolean };
    await this.transact((database) => {
      const existing = database.sends.find((item) => item.idempotencyKey === input.idempotencyKey);
      if (existing) {
        result = { operation: clone(existing), created: false };
        return;
      }

      const now = isoNow();
      const operation: SendOperation = {
        id: `send-${randomUUID()}`,
        idempotencyKey: input.idempotencyKey,
        kind: input.kind,
        status: "queued",
        recipientId: input.recipientId,
        commentId: input.commentId,
        text: input.text,
        instagramUserId: input.instagramUserId,
        username: input.username,
        channel: input.channel,
        automationId: input.automationId,
        eventId: input.eventId,
        messageId: input.messageId,
        maxAttempts: Math.max(1, Math.min(Math.floor(input.maxAttempts ?? getOperationQueueConfig().maxAttempts), 10)),
        attempts: 0,
        createdAt: now,
        updatedAt: now,
        nextAttemptAt: now,
      };
      database.sends.push(operation);
      this.trim(database);
      database.updatedAt = now;
      result = { operation: clone(operation), created: true };
    });
    return result;
  }

  async list(): Promise<OperationDatabase["sends"]> {
    const database = await this.snapshot();
    return database.sends.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async process(
    deliver: (operation: SendOperation) => Promise<OperationDeliveryResult>,
    options: { limit?: number; ids?: string[] } = {},
  ): Promise<OperationProcessResult[]> {
    const results: OperationProcessResult[] = [];
    const limit = Math.max(1, Math.min(options.limit ?? 20, 100));
    const idFilter = options.ids ? new Set(options.ids) : undefined;

    for (let index = 0; index < limit; index += 1) {
      const claimed = await this.claimNext(idFilter);
      if (!claimed) break;

      let result: OperationDeliveryResult;
      try {
        result = await deliver(claimed);
      } catch (error) {
        result = { ok: false, mode: "live", error: error instanceof Error ? error.message : "Falha no envio." };
      }
      const completed = await this.complete(claimed.id, result);
      results.push({ operation: completed, result });
    }
    return results;
  }

  async recordWebhook(input: Pick<WebhookLog, "fingerprint" | "accepted" | "eventCount" | "error">): Promise<WebhookLog> {
    let result!: WebhookLog;
    await this.transact((database) => {
      const duplicate = input.accepted && database.webhooks.some((item) => item.accepted && item.fingerprint === input.fingerprint);
      result = {
        id: `webhook-${randomUUID()}`,
        fingerprint: input.fingerprint,
        accepted: input.accepted,
        duplicate,
        eventCount: input.eventCount,
        receivedAt: isoNow(),
        error: input.error,
      };
      database.webhooks.unshift(result);
      if (database.webhooks.length > MAX_WEBHOOK_LOGS) database.webhooks = database.webhooks.slice(0, MAX_WEBHOOK_LOGS);
      database.updatedAt = result.receivedAt;
    });
    return result;
  }

  async completeWebhook(id: string, patch: Pick<WebhookLog, "eventCount" | "error">): Promise<void> {
    await this.transact((database) => {
      const log = database.webhooks.find((item) => item.id === id);
      if (!log) return;
      log.eventCount = patch.eventCount;
      log.error = patch.error;
      log.completedAt = isoNow();
      database.updatedAt = log.completedAt;
    });
  }

  async requestDeletion(input: Pick<DataDeletionRequest, "subjectId" | "reason">): Promise<DataDeletionRequest> {
    let result!: DataDeletionRequest;
    await this.transact((database) => {
      result = {
        id: `deletion-${randomUUID()}`,
        subjectId: input.subjectId,
        reason: input.reason,
        status: "requested",
        requestedAt: isoNow(),
      };
      database.deletionRequests.unshift(result);
      if (database.deletionRequests.length > MAX_DELETION_REQUESTS) database.deletionRequests = database.deletionRequests.slice(0, MAX_DELETION_REQUESTS);
      database.updatedAt = result.requestedAt;
    });
    return result;
  }

  async health(): Promise<OperationQueueHealth> {
    try {
      const database = await this.snapshot();
      return {
        ready: true,
        cached: this.cache !== null,
        pendingWrites: this.pendingWrites,
        filePath: this.filePath,
        sendsPerMinute: getOperationQueueConfig().sendsPerMinute,
        counts: counts(database),
        lastLoadedAt: this.lastLoadedAt,
        lastWriteAt: this.lastWriteAt,
      };
    } catch {
      return {
        ready: false,
        cached: false,
        pendingWrites: this.pendingWrites,
        filePath: this.filePath,
        sendsPerMinute: getOperationQueueConfig().sendsPerMinute,
        counts: { queued: 0, processing: 0, sent: 0, failed: 0 },
        lastLoadedAt: this.lastLoadedAt,
        lastWriteAt: this.lastWriteAt,
      };
    }
  }

  private async claimNext(ids?: Set<string>): Promise<SendOperation | undefined> {
    let claimed: SendOperation | undefined;
    const now = Date.now();
    await this.transact((database) => {
      this.recoverStale(database, now);
      const config = getOperationQueueConfig();
      const used = database.sends.filter((item) =>
        (item.status === "sent" && isInLastMinute(item.completedAt, now)) ||
        (item.status === "processing" && isInLastMinute(item.processingAt, now)),
      ).length;
      if (used >= config.sendsPerMinute) return;

      const next = database.sends
        .filter((item) => item.status === "queued" && isDue(item, now) && (!ids || ids.has(item.id)))
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
      if (!next) return;
      next.status = "processing";
      next.attempts += 1;
      next.processingAt = new Date(now).toISOString();
      next.updatedAt = next.processingAt;
      claimed = clone(next);
      database.updatedAt = next.updatedAt;
    });
    return claimed;
  }

  private async complete(id: string, result: OperationDeliveryResult): Promise<SendOperation> {
    let completed!: SendOperation;
    await this.transact((database) => {
      const operation = database.sends.find((item) => item.id === id);
      if (!operation) throw new Error("Operação de envio desapareceu.");
      const now = isoNow();
      operation.updatedAt = now;
      operation.providerMessageId = result.providerMessageId;
      operation.providerMode = result.mode;
      operation.error = result.error;
      delete operation.processingAt;
      if (result.ok) {
        operation.status = "sent";
        operation.completedAt = now;
        delete operation.nextAttemptAt;
      } else if (operation.attempts < operation.maxAttempts) {
        operation.status = "queued";
        operation.nextAttemptAt = new Date(Date.now() + retryDelay(operation.attempts)).toISOString();
      } else {
        operation.status = "failed";
        operation.completedAt = now;
        delete operation.nextAttemptAt;
      }
      database.updatedAt = now;
      completed = clone(operation);
    });
    return completed;
  }

  private recoverStale(database: OperationDatabase, now: number): void {
    const staleBefore = now - 5 * MINUTE_MS;
    for (const operation of database.sends) {
      if (operation.status !== "processing" || !operation.processingAt || Date.parse(operation.processingAt) > staleBefore) continue;
      operation.status = operation.attempts >= operation.maxAttempts ? "failed" : "queued";
      operation.nextAttemptAt = new Date(now).toISOString();
      operation.updatedAt = new Date(now).toISOString();
      delete operation.processingAt;
    }
  }

  private trim(database: OperationDatabase): void {
    if (database.sends.length <= MAX_SENDS) return;
    database.sends = database.sends
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .filter((item) => item.status === "queued" || item.status === "processing")
      .concat(database.sends.filter((item) => item.status !== "queued" && item.status !== "processing").sort((a, b) => b.createdAt.localeCompare(a.createdAt)))
      .slice(0, MAX_SENDS);
  }

  private async transact(mutator: (database: OperationDatabase) => void): Promise<void> {
    const operation = this.mutationQueue.catch(() => undefined).then(async () => {
      await this.ensureLoaded();
      const database = clone(this.cache as OperationDatabase);
      mutator(database);
      this.cache = clone(database);
      this.pendingWrites += 1;
      await this.enqueueWrite(database);
    });
    this.mutationQueue = operation.then(() => undefined, () => undefined);
    await operation;
  }

  private async ensureLoaded(): Promise<void> {
    if (this.cache) return;
    if (!this.loadPromise) this.loadPromise = this.loadFromDisk();
    try {
      await this.loadPromise;
    } finally {
      this.loadPromise = null;
    }
  }

  private async loadFromDisk(): Promise<void> {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    try {
      const parsed: unknown = JSON.parse(await fs.readFile(this.filePath, "utf8"));
      validateDatabase(parsed);
      this.cache = clone(parsed);
    } catch (error) {
      const code = error && typeof error === "object" && "code" in error ? (error as { code?: string }).code : undefined;
      if (code !== "ENOENT") throw error;
      this.cache = emptyDatabase();
      await this.atomicWrite(this.cache);
    }
    this.lastLoadedAt = isoNow();
  }

  private async enqueueWrite(database: OperationDatabase): Promise<void> {
    const payload = `${JSON.stringify(database, null, 2)}\n`;
    const operation = this.writeQueue.catch(() => undefined).then(async () => {
      await this.atomicWrite(payload);
      this.pendingWrites = Math.max(0, this.pendingWrites - 1);
    });
    this.writeQueue = operation;
    await operation;
  }

  private async atomicWrite(databaseOrPayload: OperationDatabase | string): Promise<void> {
    const payload = typeof databaseOrPayload === "string" ? databaseOrPayload : `${JSON.stringify(databaseOrPayload, null, 2)}\n`;
    const temporaryPath = `${this.filePath}.tmp-${process.pid}-${randomUUID()}`;
    try {
      await fs.writeFile(temporaryPath, payload, "utf8");
      await fs.rename(temporaryPath, this.filePath);
      this.lastWriteAt = isoNow();
    } catch (error) {
      await fs.unlink(temporaryPath).catch(() => undefined);
      throw error;
    }
  }
}

export const operationQueue = new OperationQueue();
