import { createHash, randomUUID } from "node:crypto";
import {
  AggregatedMetrics,
  AnalyticsData,
  Automation,
  AutomationAction,
  AutomationDraft,
  AutomationStatus,
  AutomationTrigger,
  AutomationVersion,
  AutomationFunnel,
  DashboardData,
  DailyMetrics,
  JsonDatabase,
  InstagramMedia,
  Link,
  LinkDraft,
  MetricTotals,
} from "../../types/backend";
import { jsonStore, MAX_MESSAGES_PER_CONVERSATION, MAX_STORED_EVENTS } from "./json-store";
import { normalizedText, parseAutomationDraft, parseAutomationPatch, validateAutomationPublication } from "./validation";

const EMPTY_TOTALS: MetricTotals = {
  dmsSent: 0,
  mockedDms: 0,
  failedDms: 0,
  dmsReceived: 0,
  publicRepliesSent: 0,
  mockedPublicReplies: 0,
  failedPublicReplies: 0,
  linkClicks: 0,
  uniqueLinkClicks: 0,
  automationRuns: 0,
  webhookEvents: 0,
  failedWebhookEvents: 0,
};

function isoNow(): string {
  return new Date().toISOString();
}

export function dayKey(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

function ensureDailyMetrics(metrics: AggregatedMetrics, date = dayKey()): DailyMetrics {
  if (!metrics.byDay[date]) metrics.byDay[date] = { date, ...EMPTY_TOTALS };
  return metrics.byDay[date];
}

export function incrementMetric(database: JsonDatabase, field: keyof MetricTotals, amount = 1, date = dayKey()): void {
  database.metrics.totals[field] += amount;
  ensureDailyMetrics(database.metrics, date)[field] += amount;
  database.metrics.lastUpdatedAt = isoNow();
}

function slugify(value: string): string {
  const slug = normalizedText(value)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 70);
  return slug || `link-${randomUUID().slice(0, 8)}`;
}

function uniqueSlug(database: JsonDatabase, requested: string): string {
  const base = slugify(requested);
  let candidate = base;
  let suffix = 2;
  while (database.links.some((link) => link.slug === candidate)) candidate = `${base}-${suffix++}`;
  return candidate;
}

export async function listAutomations(filters: { status?: AutomationStatus; query?: string } = {}): Promise<Automation[]> {
  const database = await jsonStore.snapshot();
  const query = filters.query ? normalizedText(filters.query) : undefined;
  return database.automations
    .filter((automation) => !filters.status || automation.status === filters.status)
    .filter((automation) => !query || normalizedText(`${automation.name} ${automation.description}`).includes(query))
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function getAutomation(id: string): Promise<Automation | undefined> {
  const database = await jsonStore.snapshot();
  return database.automations.find((automation) => automation.id === id);
}

function materializeActions(actions: NonNullable<AutomationDraft["actions"]>): AutomationAction[] {
  return actions.map((action) => ({
    ...structuredClone(action),
    id: action.id ?? `action-${randomUUID()}`,
    enabled: action.enabled ?? true,
  }));
}

function versionSnapshot(automation: Automation): AutomationVersion {
  return structuredClone({
    revision: automation.revision ?? 1,
    savedAt: automation.updatedAt,
    name: automation.name,
    trigger: automation.trigger,
    actions: automation.actions,
  });
}

function mergeTrigger(previous: AutomationTrigger, patch: NonNullable<AutomationDraft["trigger"]>): AutomationTrigger {
  const trigger = { ...structuredClone(previous), ...structuredClone(patch) };
  // An explicit scope change must not carry a previous media selection into
  // "any" or an unresolved "next". Omitted fields otherwise stay intact.
  if (patch.mediaScope !== undefined && patch.mediaScope !== previous.mediaScope && patch.mediaScope !== "specific") {
    delete trigger.media;
    delete trigger.mediaId;
    if (patch.media !== undefined) trigger.media = structuredClone(patch.media);
    if (patch.mediaId !== undefined) trigger.mediaId = patch.mediaId;
  }
  if (patch.media !== undefined && patch.mediaId === undefined) trigger.mediaId = patch.media.id;
  if (patch.mediaId !== undefined && patch.media === undefined && trigger.media?.id !== patch.mediaId) delete trigger.media;
  return trigger;
}

export async function createAutomation(input: AutomationDraft): Promise<Automation> {
  const draft = parseAutomationDraft(input);
  const now = isoNow();
  const automation: Automation = {
    id: `automation-${randomUUID()}`,
    name: draft.name,
    description: draft.description ?? "",
    status: draft.status ?? "draft",
    trigger: mergeTrigger({ type: "comment_any", keywords: [] }, draft.trigger ?? { type: "comment_any" }),
    actions: materializeActions(draft.actions ?? []),
    stats: { runs: 0, messagesSent: 0 },
    createdAt: now,
    updatedAt: now,
    revision: 1,
    versions: [],
  };

  await jsonStore.transact((database) => {
    validateAutomationPublication(automation, database.links);
    database.automations.unshift(automation);
    database.updatedAt = now;
  });
  return automation;
}

export async function updateAutomation(id: string, input: Partial<AutomationDraft>): Promise<Automation | undefined> {
  const patch = parseAutomationPatch(input);
  let updated: Automation | undefined;
  await jsonStore.transact((database) => {
    const automation = database.automations.find((item) => item.id === id);
    if (!automation) return;

    const now = isoNow();
    const previous = versionSnapshot(automation);
    if (patch.name !== undefined) automation.name = patch.name;
    if (patch.description !== undefined) automation.description = patch.description;
    if (patch.status !== undefined) automation.status = patch.status;
    if (patch.trigger !== undefined) {
      automation.trigger = mergeTrigger(automation.trigger, patch.trigger);
    }
    if (patch.actions !== undefined) {
      automation.actions = materializeActions(patch.actions);
    }
    validateAutomationPublication(automation, database.links);
    automation.revision = previous.revision + 1;
    automation.versions = [...(automation.versions ?? []), previous].slice(-20);
    automation.updatedAt = now;
    database.updatedAt = now;
    updated = automation;
  });
  return updated;
}

export async function archiveAutomation(id: string): Promise<boolean> {
  return Boolean(await updateAutomation(id, { status: "archived" }));
}

export async function listLinks(): Promise<Link[]> {
  const database = await jsonStore.snapshot();
  return database.links.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function createLink(draft: LinkDraft): Promise<Link> {
  const now = isoNow();
  let link!: Link;
  await jsonStore.transact((database) => {
    link = {
      id: `link-${randomUUID()}`,
      name: draft.name,
      slug: uniqueSlug(database, draft.slug ?? draft.name),
      url: draft.url,
      utm: draft.utm ? structuredClone(draft.utm) : undefined,
      active: draft.active ?? true,
      clicks: 0,
      uniqueClicks: 0,
      uniqueVisitorHashes: [],
      createdAt: now,
      updatedAt: now,
    };
    database.links.unshift(link);
    database.updatedAt = now;
  });
  return link;
}

export function buildTrackedLinkUrl(link: Pick<Link, "url" | "utm">): string {
  const target = new URL(link.url);
  if (link.utm?.source) target.searchParams.set("utm_source", link.utm.source);
  if (link.utm?.medium) target.searchParams.set("utm_medium", link.utm.medium);
  if (link.utm?.campaign) target.searchParams.set("utm_campaign", link.utm.campaign);
  return target.toString();
}

export async function recordLinkClick(id: string, visitorIdentity?: string): Promise<Link | undefined> {
  let result: Link | undefined;
  await jsonStore.transact((database) => {
    const link = database.links.find((item) => item.id === id || item.slug === id);
    if (!link || !link.active) return;

    link.clicks += 1;
    let isUnique = false;
    if (visitorIdentity) {
      const secret = process.env.LINK_CLICK_HASH_SECRET ?? "local-json-db-click-secret";
      const hash = createHash("sha256").update(`${secret}:${visitorIdentity}`).digest("hex");
      if (!link.uniqueVisitorHashes.includes(hash)) {
        link.uniqueVisitorHashes.push(hash);
        isUnique = true;
      }
    } else {
      isUnique = true;
    }

    if (isUnique) {
      link.uniqueClicks += 1;
      incrementMetric(database, "uniqueLinkClicks");
    }
    incrementMetric(database, "linkClicks");
    link.updatedAt = isoNow();
    database.updatedAt = link.updatedAt;
    result = link;
  });
  return result;
}

export async function getDashboard(days = 30, integration: DashboardData["integration"]): Promise<DashboardData> {
  const database = await jsonStore.snapshot();
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const daily = Object.values(database.metrics.byDay)
    .filter((item) => item.date >= cutoff)
    .sort((a, b) => a.date.localeCompare(b.date));

  return {
    summary: database.metrics.totals,
    daily,
    automations: database.automations
      .filter((automation) => automation.status !== "archived")
      .map((automation) => ({
        ...automation,
        conversionRate: automation.stats.runs === 0 ? 0 : Number(((automation.stats.messagesSent / automation.stats.runs) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.stats.runs - a.stats.runs),
    links: database.links,
    integration,
    generatedAt: isoNow(),
  };
}

function metricTotals(items: readonly DailyMetrics[]): MetricTotals {
  return items.reduce((totals, item) => {
    for (const field of Object.keys(EMPTY_TOTALS) as Array<keyof MetricTotals>) totals[field] += item[field] ?? 0;
    return totals;
  }, { ...EMPTY_TOTALS });
}

function percentage(value: number, total: number): number {
  return total === 0 ? 0 : Number(((value / total) * 100).toFixed(1));
}

export async function getAnalytics(days = 30): Promise<AnalyticsData> {
  const database = await jsonStore.snapshot();
  const today = dayKey();
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const daily = Object.values(database.metrics.byDay)
    .filter((item) => item.date >= cutoff && item.date <= today)
    .sort((a, b) => a.date.localeCompare(b.date));
  const funnel: AutomationFunnel[] = database.automations
    .filter((automation) => automation.status !== "archived")
    .map((automation) => {
      const linkIds = new Set(automation.actions.filter((action) => action.type === "send_link" && action.linkId).map((action) => action.linkId as string));
      const linkClicks = database.links.filter((link) => linkIds.has(link.id)).reduce((sum, link) => sum + link.clicks, 0);
      const uniqueLinkClicks = database.links.filter((link) => linkIds.has(link.id)).reduce((sum, link) => sum + link.uniqueClicks, 0);
      return {
        automationId: automation.id,
        automationName: automation.name,
        status: automation.status,
        runs: automation.stats.runs,
        messagesSent: automation.stats.messagesSent,
        linkClicks,
        uniqueLinkClicks,
        messageRate: percentage(automation.stats.messagesSent, automation.stats.runs),
        clickRate: percentage(linkClicks, automation.stats.messagesSent),
        uniqueClickRate: percentage(uniqueLinkClicks, automation.stats.messagesSent),
      };
    });

  return {
    range: { days, from: cutoff, to: today },
    totals: metricTotals(daily),
    links: database.links.map(({ uniqueVisitorHashes: _uniqueVisitorHashes, ...link }) => structuredClone(link)),
    funnel,
    daily,
  };
}

export function addConversationMessage(
  database: JsonDatabase,
  instagramUserId: string,
  username: string,
  message: import("../../types/backend").Message,
): void {
  let conversation = database.conversations.find((item) => item.instagramUserId === instagramUserId);
  const now = message.createdAt;
  if (!conversation) {
    conversation = {
      id: `conversation-${instagramUserId}`,
      instagramUserId,
      username,
      status: "open",
      messages: [],
      createdAt: now,
      updatedAt: now,
      lastMessageAt: now,
    };
    database.conversations.unshift(conversation);
  }

  conversation.username = username || conversation.username;
  conversation.messages.push(message);
  if (conversation.messages.length > MAX_MESSAGES_PER_CONVERSATION) {
    conversation.messages = conversation.messages.slice(-MAX_MESSAGES_PER_CONVERSATION);
  }
  conversation.updatedAt = now;
  conversation.lastMessageAt = now;
}

export function trimEvents(database: JsonDatabase): void {
  if (database.events.length > MAX_STORED_EVENTS) database.events = database.events.slice(0, MAX_STORED_EVENTS);
}

export function findMatchingAutomation(database: JsonDatabase, eventType: string, text = "", mediaId?: string): Automation | undefined {
  // The webhook adapter must distinguish story replies from ordinary DMs.
  // Unknown and follower events cannot activate automations in this app.
  if (!["comment", "message", "mention", "story_reply"].includes(eventType)) return undefined;
  const normalized = normalizedText(text);
  return database.automations
    .filter((automation) => automation.status === "active")
    .filter((automation) => {
      const trigger = automation.trigger;
      if (eventType === "comment" && !["comment_any", "comment_keyword"].includes(trigger.type)) return false;
      if (eventType === "message" && trigger.type !== "dm_received") return false;
      if (eventType === "mention" && trigger.type !== "story_mention") return false;
      if (eventType === "story_reply" && trigger.type !== "story_reply") return false;
      const selectedMedia = trigger.mediaId || trigger.media?.id;
      if (trigger.mediaScope !== "any") {
        if ((trigger.mediaScope === "specific" || trigger.mediaScope === "next") && !selectedMedia) return false;
        if (selectedMedia && selectedMedia !== mediaId) return false;
      }
      if (trigger.type === "comment_keyword" || (trigger.type !== "comment_any" && trigger.keywords.length > 0)) {
        return trigger.keywords.some((keyword) => {
          const word = normalizedText(keyword);
          return word.length > 0 && normalized.includes(word);
        });
      }
      return true;
    })
    // A media-specific rule wins over a global rule, then a keyword rule wins
    // over a catch-all. Recency and ID provide a deterministic tie-break.
    .sort((a, b) => matchingPriority(b) - matchingPriority(a) || b.updatedAt.localeCompare(a.updatedAt) || a.id.localeCompare(b.id))[0];
}

function matchingPriority(automation: Automation): number {
  const trigger = automation.trigger;
  const mediaSpecific = trigger.mediaScope !== "any" && Boolean(trigger.mediaId || trigger.media?.id);
  const keywords = trigger.type !== "comment_any" && trigger.keywords.some((keyword) => normalizedText(keyword).length > 0);
  return (mediaSpecific ? 2 : 0) + (keywords ? 1 : 0);
}

/**
 * Pure resolver for the principal's media integration. Supply all pages of the
 * account's eligible media; chooses the earliest timestamp strictly after the
 * arming/save time (updatedAt by default). Media without a valid timestamp is
 * ineligible. Persist the returned trigger in a transaction only if the source
 * revision still matches; never rebind an already selected "next" media.
 * No fetching, writes, synthetic media or message delivery happens here.
 */
export function resolveNextAutomationMedia(
  automation: Automation,
  media: readonly InstagramMedia[],
  armedAt = automation.updatedAt,
): AutomationTrigger | undefined {
  if (automation.status !== "active" || automation.trigger.mediaScope !== "next") return undefined;
  if (automation.trigger.mediaId || automation.trigger.media) return structuredClone(automation.trigger);
  const after = Date.parse(armedAt);
  if (!Number.isFinite(after)) return undefined;
  const eligible = media
    .filter((item) => item.id.trim() && item.timestamp && Date.parse(item.timestamp) > after)
    .sort((a, b) => Date.parse(a.timestamp!) - Date.parse(b.timestamp!) || a.id.localeCompare(b.id));
  if (!eligible[0]) return undefined;
  return { ...structuredClone(automation.trigger), mediaId: eligible[0].id, media: structuredClone(eligible[0]) };
}

export function renderActionText(action: AutomationAction, database: JsonDatabase): string {
  const link = action.linkId ? database.links.find((item) => item.id === action.linkId && item.active) : undefined;
  const variant = action.type === "public_reply" ? action.variants?.find((item) => item.trim()) : undefined;
  const base = variant?.trim() || action.message?.trim() || "Olá! Obrigado por interagir comigo.";
  if (!link) return base;
  return `${base}\n${link.url}`;
}

export { EMPTY_TOTALS };
