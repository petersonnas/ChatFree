import { randomUUID } from "node:crypto";
import { JsonDatabase, MetricTotals } from "../../types/backend";

const now = "2026-09-21T12:00:00.000Z";

function totals(overrides: Partial<MetricTotals> = {}): MetricTotals {
  return {
    dmsSent: 128,
    mockedDms: 0,
    failedDms: 2,
    dmsReceived: 214,
    publicRepliesSent: 87,
    mockedPublicReplies: 0,
    failedPublicReplies: 1,
    linkClicks: 392,
    uniqueLinkClicks: 279,
    automationRuns: 173,
    webhookEvents: 421,
    failedWebhookEvents: 3,
    ...overrides,
  };
}

export function createSeedDatabase(): JsonDatabase {
  const linkOne = "link-free-guide";
  const linkTwo = "link-community";
  const automationOne = "automation-free-guide";
  const automationTwo = "automation-welcome";
  const contactOne = "contact-100001";
  const contactTwo = "contact-100002";

  return {
    schemaVersion: 1,
    createdAt: "2026-09-01T10:00:00.000Z",
    updatedAt: now,
    automations: [
      {
        id: automationOne,
        name: "Enviar guia quando comentarem FREE",
        description: "Responde o comentário e envia o guia por DM.",
        status: "active",
        trigger: { type: "comment_keyword", keywords: ["free", "guia"], mediaId: "media-demo-01" },
        actions: [
          {
            id: "action-public-guide",
            type: "public_reply",
            enabled: true,
            message: "Te enviei uma mensagem com o guia 😊",
          },
          {
            id: "action-dm-guide",
            type: "send_link",
            enabled: true,
            message: "Oi! Aqui está o guia que você pediu. Aproveite ✨",
            buttonText: "Abrir o guia",
            linkId: linkOne,
          },
        ],
        stats: { runs: 93, messagesSent: 90, lastRunAt: "2026-09-21T11:44:00.000Z" },
        createdAt: "2026-09-03T13:20:00.000Z",
        updatedAt: now,
      },
      {
        id: automationTwo,
        name: "Boas-vindas para novas conversas",
        description: "Recebe novos contatos com uma mensagem curta e um link útil.",
        status: "active",
        trigger: { type: "dm_received", keywords: [] },
        actions: [
          {
            id: "action-dm-welcome",
            type: "send_dm",
            enabled: true,
            message: "Olá! Obrigado por chamar. Como posso ajudar?",
          },
        ],
        stats: { runs: 80, messagesSent: 80, lastRunAt: "2026-09-21T10:18:00.000Z" },
        createdAt: "2026-09-05T09:00:00.000Z",
        updatedAt: "2026-09-20T16:10:00.000Z",
      },
      {
        id: "automation-paused-example",
        name: "Link da comunidade",
        description: "Automação pausada para revisão do texto.",
        status: "paused",
        trigger: { type: "comment_keyword", keywords: ["comunidade", "grupo"] },
        actions: [
          {
            id: "action-community",
            type: "send_link",
            enabled: true,
            message: "Aqui está o acesso à comunidade.",
            linkId: linkTwo,
          },
        ],
        stats: { runs: 0, messagesSent: 0 },
        createdAt: "2026-09-10T14:00:00.000Z",
        updatedAt: "2026-09-18T14:00:00.000Z",
      },
    ],
    links: [
      {
        id: linkOne,
        name: "Guia gratuito",
        slug: "guia",
        url: "https://example.com/guia",
        active: true,
        clicks: 267,
        uniqueClicks: 191,
        uniqueVisitorHashes: ["seed-visitor-1", "seed-visitor-2"],
        createdAt: "2026-09-03T13:20:00.000Z",
        updatedAt: now,
      },
      {
        id: linkTwo,
        name: "Comunidade",
        slug: "comunidade",
        url: "https://example.com/comunidade",
        active: true,
        clicks: 125,
        uniqueClicks: 88,
        uniqueVisitorHashes: ["seed-visitor-3"],
        createdAt: "2026-09-10T14:00:00.000Z",
        updatedAt: "2026-09-20T14:00:00.000Z",
      },
    ],
    contacts: [
      {
        id: contactOne,
        instagramUserId: "100001",
        username: "ana.exemplo",
        displayName: "Ana Exemplo",
        followsAccount: true,
        tags: ["guia", "lead"],
        createdAt: "2026-09-18T11:00:00.000Z",
        updatedAt: "2026-09-21T11:45:00.000Z",
        lastInteractionAt: "2026-09-21T11:45:00.000Z",
      },
      {
        id: contactTwo,
        instagramUserId: "100002",
        username: "bruno.dev",
        displayName: "Bruno Dev",
        followsAccount: false,
        tags: ["comunidade"],
        createdAt: "2026-09-17T15:30:00.000Z",
        updatedAt: "2026-09-20T18:20:00.000Z",
        lastInteractionAt: "2026-09-20T18:20:00.000Z",
      },
    ],
    conversations: [
      {
        id: "conversation-100001",
        instagramUserId: "100001",
        username: "ana.exemplo",
        status: "open",
        messages: [
          {
            id: randomUUID(),
            direction: "inbound",
            channel: "comment",
            text: "free",
            status: "received",
            automationId: automationOne,
            createdAt: "2026-09-21T11:44:00.000Z",
          },
          {
            id: randomUUID(),
            direction: "outbound",
            channel: "dm",
            text: "Oi! Aqui está o guia que você pediu. Aproveite ✨\nhttps://example.com/guia",
            status: "sent",
            automationId: automationOne,
            linkId: linkOne,
            createdAt: "2026-09-21T11:44:02.000Z",
          },
        ],
        createdAt: "2026-09-18T11:00:00.000Z",
        updatedAt: "2026-09-21T11:44:02.000Z",
        lastMessageAt: "2026-09-21T11:44:02.000Z",
      },
      {
        id: "conversation-100002",
        instagramUserId: "100002",
        username: "bruno.dev",
        status: "open",
        messages: [
          {
            id: randomUUID(),
            direction: "inbound",
            channel: "dm",
            text: "Oi, como funciona a comunidade?",
            status: "received",
            createdAt: "2026-09-20T18:20:00.000Z",
          },
        ],
        createdAt: "2026-09-17T15:30:00.000Z",
        updatedAt: "2026-09-20T18:20:00.000Z",
        lastMessageAt: "2026-09-20T18:20:00.000Z",
      },
    ],
    events: [
      {
        id: "event-seed-1",
        externalId: "comment-seed-1",
        type: "comment",
        status: "processed",
        instagramUserId: "100001",
        username: "ana.exemplo",
        text: "free",
        commentId: "comment-seed-1",
        mediaId: "media-demo-01",
        automationId: automationOne,
        receivedAt: "2026-09-21T11:44:00.000Z",
        processedAt: "2026-09-21T11:44:02.000Z",
      },
    ],
    metrics: {
      totals: totals(),
      byDay: {
        "2026-09-19": {
          date: "2026-09-19",
          ...totals({ dmsSent: 40, mockedDms: 0, failedDms: 0, dmsReceived: 61, publicRepliesSent: 24, mockedPublicReplies: 0, failedPublicReplies: 0, linkClicks: 119, uniqueLinkClicks: 84, automationRuns: 49, webhookEvents: 102, failedWebhookEvents: 0 }),
        },
        "2026-09-20": {
          date: "2026-09-20",
          ...totals({ dmsSent: 45, mockedDms: 0, failedDms: 1, dmsReceived: 73, publicRepliesSent: 30, mockedPublicReplies: 0, failedPublicReplies: 1, linkClicks: 141, uniqueLinkClicks: 101, automationRuns: 58, webhookEvents: 141, failedWebhookEvents: 2 }),
        },
        "2026-09-21": {
          date: "2026-09-21",
          ...totals({ dmsSent: 43, mockedDms: 0, failedDms: 1, dmsReceived: 80, publicRepliesSent: 33, mockedPublicReplies: 0, failedPublicReplies: 0, linkClicks: 132, uniqueLinkClicks: 94, automationRuns: 66, webhookEvents: 178, failedWebhookEvents: 1 }),
        },
      },
      lastUpdatedAt: now,
    },
  };
}
