import { promises as fs } from "node:fs";
import path from "node:path";

export type AppSettings = {
  name: string;
  username: string;
  email: string;
  timezone: string;
  connected: boolean;
};

const defaults: AppSettings = {
  name: "Gabriel Peterson",
  username: "gpeterson.co",
  email: "gabriel@exemplo.com",
  timezone: "America/Sao_Paulo",
  connected: false,
};

const filePath = process.env.SETTINGS_JSON_PATH
  ? path.resolve(process.env.SETTINGS_JSON_PATH)
  : path.join(process.cwd(), "data", "settings.json");

let cached: AppSettings | null = null;
let queue: Promise<void> = Promise.resolve();

async function write(value: AppSettings): Promise<void> {
  const temporaryPath = `${filePath}.tmp-${process.pid}`;
  await fs.writeFile(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(temporaryPath, filePath);
}

async function load(): Promise<AppSettings> {
  if (cached) return { ...cached };
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  try {
    const parsed = JSON.parse(await fs.readFile(filePath, "utf8")) as Partial<AppSettings>;
    cached = { ...defaults, ...parsed };
  } catch {
    cached = { ...defaults };
    await write(cached);
  }
  return { ...cached };
}

export async function getSettings(): Promise<AppSettings> {
  return load();
}

export async function updateSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
  let result!: AppSettings;
  const operation = queue.catch(() => undefined).then(async () => {
    const current = await load();
    result = { ...current, ...patch };
    cached = result;
    await write(result);
  });
  queue = operation.then(() => undefined, () => undefined);
  await operation;
  return { ...result };
}
