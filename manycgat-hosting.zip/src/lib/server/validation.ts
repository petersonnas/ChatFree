import {
  Automation,
  AutomationActionType,
  AutomationDraft,
  AutomationStatus,
  AutomationTrigger,
  InstagramMedia,
  JsonDatabase,
  LinkDraft,
  Link,
  LinkUtm,
  TriggerType,
} from "../../types/backend";

export class ValidationError extends Error {
  public readonly statusCode = 400;

  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

const TRIGGER_TYPES: TriggerType[] = [
  "comment_keyword",
  "comment_any",
  "new_follower",
  "dm_received",
  "story_mention",
  "story_reply",
];

const ACTION_TYPES: AutomationActionType[] = [
  "public_reply",
  "send_dm",
  "send_link",
  "request_follow",
  "request_email",
  "reminder",
];

const STATUSES: AutomationStatus[] = ["active", "paused", "draft", "archived"];
const LINK_SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const UTM_FIELDS = ["source", "medium", "campaign"] as const;

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringValue(value: unknown, field: string, maxLength: number): string {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new ValidationError(`${field} precisa ser um texto não vazio.`);
  }

  const result = value.trim();
  if (result.length > maxLength) {
    throw new ValidationError(`${field} excede o limite de ${maxLength} caracteres.`);
  }

  return result;
}

function optionalString(value: unknown, field: string, maxLength: number): string | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  return stringValue(value, field, maxLength);
}

function enumValue<T extends string>(value: unknown, values: readonly T[], field: string): T {
  if (typeof value !== "string" || !values.includes(value as T)) {
    throw new ValidationError(`${field} contém um valor inválido.`);
  }
  return value as T;
}

function parseHttpUrl(value: unknown, field = "url"): string {
  const url = stringValue(value, field, 2000);
  if (/[\u0000-\u001f\u007f]/.test(url)) throw new ValidationError(`${field} contém caracteres de controle inválidos.`);
  let parsed: URL;
  try { parsed = new URL(url); } catch { throw new ValidationError(`${field} precisa ser uma URL válida.`); }
  if (!(parsed.protocol === "http:" || parsed.protocol === "https:") || !parsed.hostname) throw new ValidationError(`${field} precisa usar http ou https.`);
  if (parsed.username || parsed.password) throw new ValidationError(`${field} não pode conter credenciais.`);
  return url;
}

export function parseLinkUtm(value: unknown): LinkUtm | undefined {
  if (value === undefined || value === null) return undefined;
  if (!isRecord(value)) throw new ValidationError("utm precisa ser um objeto.");
  if (Object.keys(value).some((key) => !(UTM_FIELDS as readonly string[]).includes(key))) throw new ValidationError("utm contém campos inválidos.");
  const utm: LinkUtm = {};
  for (const field of UTM_FIELDS) {
    const parsed = optionalString(value[field], `utm.${field}`, 100);
    if (parsed !== undefined) {
      if (/[\u0000-\u001f\u007f]/.test(parsed)) throw new ValidationError(`utm.${field} contém caracteres de controle inválidos.`);
      utm[field] = parsed;
    }
  }
  return Object.keys(utm).length ? utm : undefined;
}

function parseLinkSlug(value: unknown): string | undefined {
  const slug = optionalString(value, "slug", 80);
  if (slug !== undefined && !LINK_SLUG_PATTERN.test(slug)) throw new ValidationError("slug deve conter apenas letras minúsculas, números e hífens.");
  return slug;
}

// Draft text is preserved verbatim, including empty inputs. Publication checks
// completeness separately, after a PATCH has been merged with the saved record.
function draftText(value: unknown, field: string, maxLength: number): string {
  if (typeof value !== "string") throw new ValidationError(`${field} precisa ser um texto.`);
  if (value.length > maxLength) throw new ValidationError(`${field} excede o limite de ${maxLength} caracteres.`);
  return value;
}

function optionalDraftText(value: unknown, field: string, maxLength: number): string | undefined {
  return value === undefined ? undefined : draftText(value, field, maxLength);
}

function stringArray(value: unknown, field: string, maxItems: number, maxItemLength: number): string[] {
  if (!Array.isArray(value) || value.length > maxItems) {
    throw new ValidationError(`${field} precisa ser uma lista com até ${maxItems} itens.`);
  }

  return value.map((item, index) => draftText(item, `${field}[${index}]`, maxItemLength));
}

export function parseInstagramMedia(input: unknown, field = "trigger.media"): InstagramMedia {
  if (!isRecord(input)) throw new ValidationError(`${field} precisa ser um objeto.`);
  const id = draftText(input.id, `${field}.id`, 200);
  if (!id.trim()) throw new ValidationError(`${field}.id precisa ser um texto não vazio.`);
  const media: InstagramMedia = {
    id,
    mediaType: enumValue(input.mediaType, ["IMAGE", "VIDEO", "CAROUSEL_ALBUM"], `${field}.mediaType`),
    caption: draftText(input.caption, `${field}.caption`, 2200),
  };
  for (const key of ["mediaUrl", "thumbnailUrl", "permalink", "timestamp"] as const) {
    if (input[key] !== undefined) media[key] = draftText(input[key], `${field}.${key}`, key === "timestamp" ? 80 : 4000);
  }
  if (media.timestamp !== undefined && !Number.isFinite(Date.parse(media.timestamp))) {
    throw new ValidationError(`${field}.timestamp precisa ser uma data válida.`);
  }
  return media;
}

export function parseAutomationDraft(input: unknown): AutomationDraft {
  if (!isRecord(input)) throw new ValidationError("O corpo da automação precisa ser um objeto.");

  const triggerInput = input.trigger;
  let trigger: AutomationDraft["trigger"];
  if (triggerInput !== undefined) {
    if (!isRecord(triggerInput)) throw new ValidationError("trigger precisa ser um objeto.");
    trigger = {
      type: enumValue(triggerInput.type, TRIGGER_TYPES, "trigger.type"),
    };
    if (triggerInput.keywords !== undefined) trigger.keywords = stringArray(triggerInput.keywords, "trigger.keywords", 20, 80);
    if (triggerInput.mediaId !== undefined) trigger.mediaId = draftText(triggerInput.mediaId, "trigger.mediaId", 200);
    if (triggerInput.mediaScope !== undefined) trigger.mediaScope = enumValue(triggerInput.mediaScope, ["any", "specific", "next"] as const, "trigger.mediaScope");
    if (triggerInput.media !== undefined) trigger.media = parseInstagramMedia(triggerInput.media);
  }

  let actions: AutomationDraft["actions"];
  if (input.actions !== undefined) {
    if (!Array.isArray(input.actions) || input.actions.length > 20) {
      throw new ValidationError("actions precisa ser uma lista com até 20 itens.");
    }

    actions = input.actions.map((value, index) => {
      if (!isRecord(value)) throw new ValidationError(`actions[${index}] precisa ser um objeto.`);
      const result: NonNullable<AutomationDraft["actions"]>[number] = {
        type: enumValue(value.type, ACTION_TYPES, `actions[${index}].type`),
      };
      if (value.id !== undefined) {
        result.id = draftText(value.id, `actions[${index}].id`, 200);
        if (!result.id.trim()) throw new ValidationError(`actions[${index}].id precisa ser um texto não vazio.`);
      }

      if (value.enabled !== undefined && typeof value.enabled !== "boolean") {
        throw new ValidationError(`actions[${index}].enabled precisa ser booleano.`);
      }
      if (value.enabled !== undefined) result.enabled = value.enabled;
      for (const [key, limit] of [["message", 1000], ["buttonText", 80], ["linkId", 120]] as const) {
        if (value[key] !== undefined) result[key] = draftText(value[key], `actions[${index}].${key}`, limit);
      }
      if (value.variants !== undefined) {
        if (result.type !== "public_reply") throw new ValidationError(`actions[${index}].variants só é permitido em public_reply.`);
        result.variants = stringArray(value.variants, `actions[${index}].variants`, 20, 1000);
      }

      if (value.delaySeconds !== undefined) {
        if (typeof value.delaySeconds !== "number" || !Number.isFinite(value.delaySeconds) || value.delaySeconds < 0 || value.delaySeconds > 86400) {
          throw new ValidationError(`actions[${index}].delaySeconds precisa estar entre 0 e 86400.`);
        }
        result.delaySeconds = value.delaySeconds;
      }

      return result;
    });
    const ids = actions.flatMap((action) => action.id === undefined ? [] : [action.id]);
    if (new Set(ids).size !== ids.length) throw new ValidationError("actions contém IDs duplicados.");
  }

  return {
    name: draftText(input.name, "name", 120),
    description: optionalDraftText(input.description, "description", 500),
    status: input.status === undefined ? undefined : enumValue(input.status, STATUSES, "status"),
    trigger,
    actions,
  };
}

/** Call with the merged configuration and current links inside the write transaction. */
export function validateAutomationPublication(automation: Automation, links: readonly Link[]): void {
  if (automation.status !== "active") return;
  if (!automation.name.trim()) throw new ValidationError("Informe o nome da automação antes de ativar.");
  const trigger: AutomationTrigger = automation.trigger;
  if (trigger.type === "new_follower") {
    throw new ValidationError("O gatilho new_follower não pode ser ativado: recurso não disponível neste app.");
  }
  if (trigger.type === "comment_keyword" && trigger.keywords.length === 0) {
    throw new ValidationError("Informe ao menos uma palavra-chave ou use comment_any para qualquer comentário.");
  }
  if (trigger.keywords.some((keyword) => !normalizedText(keyword))) {
    throw new ValidationError("As palavras-chave não podem estar vazias ao ativar a automação.");
  }
  if (trigger.mediaScope === "specific" && !(trigger.mediaId?.trim() || trigger.media?.id.trim())) {
    throw new ValidationError("Selecione uma mídia específica antes de ativar a automação.");
  }
  if (trigger.mediaId && trigger.media && trigger.mediaId !== trigger.media.id) {
    throw new ValidationError("trigger.mediaId deve corresponder ao id de trigger.media.");
  }
  const enabled = automation.actions.filter((action) => action.enabled);
  if (!enabled.some((action) => action.type === "send_link")) {
    throw new ValidationError("Ative uma ação de entrega send_link com um link para publicar a automação.");
  }
  for (const action of enabled) {
    const field = `Ação ${action.id} (${action.type})`;
    const variants = action.type === "public_reply" ? action.variants : undefined;
    if (variants?.some((variant) => !variant.trim())) {
      throw new ValidationError(`${field}: as variantes de resposta não podem estar vazias.`);
    }
    if (!action.message?.trim() && !variants?.length) {
      throw new ValidationError(`${field}: informe uma mensagem antes de ativar.`);
    }
    if (action.type === "send_link" && !action.linkId?.trim()) {
      throw new ValidationError(`${field}: selecione um link para entrega.`);
    }
    if (action.linkId) {
      const link = links.find((item) => item.id === action.linkId);
      if (!link) throw new ValidationError(`${field}: o link selecionado não existe.`);
      if (!link.active) throw new ValidationError(`${field}: o link selecionado está inativo.`);
    }
  }
}

export function parseAutomationPatch(input: unknown): Partial<AutomationDraft> {
  if (!isRecord(input)) throw new ValidationError("O corpo da automação precisa ser um objeto.");
  const parsed = parseAutomationDraft({
    ...input,
    name: input.name === undefined ? "patch" : input.name,
  });
  if (input.name === undefined) {
    const { name: _name, ...withoutName } = parsed;
    return withoutName;
  }
  return parsed;
}

export function parseLinkDraft(input: unknown): LinkDraft {
  if (!isRecord(input)) throw new ValidationError("O corpo do link precisa ser um objeto.");

  const url = parseHttpUrl(input.url);
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    throw new ValidationError("url precisa ser uma URL válida.");
  }

  if (!(["http:", "https:"].includes(parsedUrl.protocol))) {
    throw new ValidationError("url precisa usar http ou https.");
  }

  if (input.active !== undefined && typeof input.active !== "boolean") {
    throw new ValidationError("active precisa ser booleano.");
  }

  return {
    name: stringValue(input.name, "name", 120),
    url,
    slug: parseLinkSlug(input.slug),
    utm: parseLinkUtm(input.utm),
    active: input.active === undefined ? true : input.active,
  };
}

function requireString(value: unknown, field: string): string {
  if (typeof value !== "string" || value.length === 0) throw new Error(`Banco inválido: ${field}.`);
  return value;
}

export function validateDatabase(value: unknown): asserts value is JsonDatabase {
  if (!isRecord(value)) throw new Error("Banco inválido: raiz não é um objeto.");
  if (value.schemaVersion !== 1) throw new Error("Banco inválido: schemaVersion não suportada.");

  for (const field of ["createdAt", "updatedAt"] as const) requireString(value[field], field);
  for (const field of ["automations", "links", "contacts", "conversations", "events"] as const) {
    if (!Array.isArray(value[field])) throw new Error(`Banco inválido: ${field} não é uma lista.`);
  }

  const automations = value.automations as unknown[];
  const links = value.links as unknown[];

  if (!isRecord(value.metrics) || !isRecord(value.metrics.totals) || !isRecord(value.metrics.byDay)) {
    throw new Error("Banco inválido: métricas ausentes.");
  }

  for (const automation of automations) {
    if (!isRecord(automation)) throw new Error("Banco inválido: automação inválida.");
    requireString(automation.id, "automation.id");
    // Validate stored shape, not publication readiness: legacy active seeds may
    // predate delivery requirements, and incomplete drafts must remain loadable.
    parseAutomationDraft(automation);
    if (!STATUSES.includes(automation.status as AutomationStatus)) throw new Error("Banco inválido: status de automação.");
    if (!isRecord(automation.trigger) || !TRIGGER_TYPES.includes(automation.trigger.type as TriggerType)) {
      throw new Error("Banco inválido: gatilho de automação.");
    }
    if (!Array.isArray(automation.actions) || !isRecord(automation.stats)) {
      throw new Error("Banco inválido: ações ou estatísticas de automação.");
    }
    if (automation.revision !== undefined && (!Number.isSafeInteger(automation.revision) || (automation.revision as number) < 1)) {
      throw new Error("Banco inválido: revisão de automação.");
    }
    if (automation.versions !== undefined) {
      if (!Array.isArray(automation.versions) || automation.versions.length > 20) {
        throw new Error("Banco inválido: versões precisam ser uma lista com até 20 snapshots.");
      }
      let lastRevision = 0;
      for (const version of automation.versions) {
        if (!isRecord(version) || !Number.isSafeInteger(version.revision) || (version.revision as number) <= lastRevision) {
          throw new Error("Banco inválido: revisão de snapshot.");
        }
        if (typeof automation.revision !== "number" || (version.revision as number) >= automation.revision) {
          throw new Error("Banco inválido: snapshot precisa preservar uma revisão anterior.");
        }
        lastRevision = version.revision as number;
        if (!Number.isFinite(Date.parse(requireString(version.savedAt, "version.savedAt")))) {
          throw new Error("Banco inválido: data do snapshot.");
        }
        if (!isRecord(version.trigger) || !Array.isArray(version.actions)) throw new Error("Banco inválido: configuração do snapshot.");
        parseAutomationDraft(version);
      }
    }
  }

  for (const link of links) {
    if (!isRecord(link)) throw new Error("Banco inválido: link inválido.");
    requireString(link.id, "link.id");
    if (typeof link.name !== "string" || link.name.trim().length === 0) link.name = link.id;
    link.url = parseHttpUrl(link.url, "link.url");
    if (link.slug === undefined) link.slug = link.name;
    if (typeof link.slug !== "string") throw new Error("Banco inválido: slug do link.");
    const slug = normalizedText(link.slug).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);
    if (!slug) throw new Error("Banco inválido: slug do link vazio.");
    link.slug = slug;
    if (link.utm === null) delete link.utm;
    else if (link.utm !== undefined) link.utm = parseLinkUtm(link.utm);
    if (link.active === undefined) link.active = true;
    if (typeof link.active !== "boolean") throw new Error("Banco inválido: active do link.");
    if (link.clicks === undefined) link.clicks = 0;
    if (link.uniqueClicks === undefined) link.uniqueClicks = 0;
    if (typeof link.clicks !== "number" || !Number.isSafeInteger(link.clicks) || link.clicks < 0 || typeof link.uniqueClicks !== "number" || !Number.isSafeInteger(link.uniqueClicks) || link.uniqueClicks < 0) {
      throw new Error("Banco inválido: contadores de link.");
    }
    if (!Array.isArray(link.uniqueVisitorHashes)) link.uniqueVisitorHashes = [];
  }
}

export function parseDays(value: string | null): number {
  if (value === null || value === "") return 30;
  const days = Number(value);
  if (!Number.isInteger(days) || days < 1 || days > 365) {
    throw new ValidationError("days precisa ser um número inteiro entre 1 e 365.");
  }
  return days;
}

export function normalizedText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR")
    .trim();
}
