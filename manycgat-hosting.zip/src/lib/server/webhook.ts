import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { Message, NormalizedInstagramEvent, StoredEvent } from "../../types/backend";
import { addConversationMessage, findMatchingAutomation, incrementMetric, renderActionText, trimEvents } from "./repository";
import { jsonStore } from "./json-store";
import { getWebhookAppSecret } from "./instagram";
import { enqueueSendOperation, processPendingSendOperations } from "./operation-dispatcher";
import { operationQueue } from "./operation-queue";

function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
}

function stringField(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function normalizeComment(value: unknown): NormalizedInstagramEvent | undefined {
  const data = record(value);
  if (!data) return undefined;
  const from = record(data.from);
  const media = record(data.media);
  const commentId = stringField(data.id);
  return {
    externalId: commentId,
    type: "comment",
    instagramUserId: stringField(from?.id),
    username: stringField(from?.username),
    text: stringField(data.text),
    commentId,
    mediaId: stringField(data.media_id) ?? stringField(media?.id),
  };
}

function normalizeMessaging(value: unknown): NormalizedInstagramEvent | undefined {
  const data = record(value);
  if (!data) return undefined;
  const sender = record(data.sender);
  const message = record(data.message);
  const text = stringField(message?.text);
  if (!sender?.id || !text) return undefined;
  const messageId = stringField(message?.mid) ?? `${String(sender.id)}-${String(data.timestamp ?? Date.now())}`;
  return {
    externalId: messageId,
    type: "message",
    instagramUserId: stringField(sender.id),
    username: stringField(sender.username),
    text,
    timestamp: typeof data.timestamp === "number" ? new Date(data.timestamp).toISOString() : undefined,
  };
}

export function normalizeInstagramPayload(payload: unknown): NormalizedInstagramEvent[] {
  const root = record(payload);
  if (!root || !Array.isArray(root.entry)) return [];
  const result: NormalizedInstagramEvent[] = [];

  for (const entryValue of root.entry) {
    const entry = record(entryValue);
    if (!entry) continue;

    if (Array.isArray(entry.messaging)) {
      for (const item of entry.messaging) {
        const event = normalizeMessaging(item);
        if (event) result.push(event);
      }
    }

    if (Array.isArray(entry.changes)) {
      for (const changeValue of entry.changes) {
        const change = record(changeValue);
        const value = record(change?.value);
        const field = stringField(change?.field);
        if (field === "comments" || value?.text) {
          const event = normalizeComment(value);
          if (event) result.push(event);
        } else if (field === "mentions") {
          result.push({
            externalId: stringField(value?.id),
            type: "mention",
            instagramUserId: stringField(record(value?.from)?.id),
            username: stringField(record(value?.from)?.username),
            text: stringField(value?.text),
          });
        } else if (field === "followers") {
          result.push({
            externalId: stringField(value?.id),
            type: "follow",
            instagramUserId: stringField(record(value?.from)?.id) ?? stringField(value?.id),
            username: stringField(record(value?.from)?.username),
          });
        }
      }
    }
  }

  return result;
}

export function verifyMetaSignature(rawBody: string, signatureHeader: string | null): boolean {
  const secret = getWebhookAppSecret();
  if (!secret) {
    return process.env.NODE_ENV !== "production" && process.env.ALLOW_UNSIGNED_WEBHOOKS === "true";
  }
  if (!signatureHeader?.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", secret).update(rawBody, "utf8").digest("hex");
  const supplied = signatureHeader.slice("sha256=".length);
  const expectedBuffer = Buffer.from(expected, "utf8");
  const suppliedBuffer = Buffer.from(supplied, "utf8");
  return expectedBuffer.length === suppliedBuffer.length && timingSafeEqual(expectedBuffer, suppliedBuffer);
}

function eventFromNormalized(event: NormalizedInstagramEvent, automationId?: string): StoredEvent {
  return {
    id: `event-${randomUUID()}`,
    externalId: event.externalId,
    type: event.type,
    status: "processing",
    instagramUserId: event.instagramUserId,
    username: event.username,
    text: event.text,
    commentId: event.commentId,
    mediaId: event.mediaId,
    automationId,
    receivedAt: new Date().toISOString(),
  };
}

async function processOne(event: NormalizedInstagramEvent): Promise<{ status: string; mocked: number; failed: number; queued: number }> {
  if (!event.externalId && !event.instagramUserId) return { status: "ignored", mocked: 0, failed: 0, queued: 0 };

  const initial = await jsonStore.snapshot();
  if (event.externalId && initial.events.some((stored) => stored.externalId === event.externalId)) {
    return { status: "duplicate", mocked: 0, failed: 0, queued: 0 };
  }

  const automation = findMatchingAutomation(initial, event.type, event.text, event.mediaId);
  const storedEvent = eventFromNormalized(event, automation?.id);
  let duplicateDuringTransaction = false;
  await jsonStore.transact((database) => {
    if (event.externalId && database.events.some((stored) => stored.externalId === event.externalId)) {
      duplicateDuringTransaction = true;
      return;
    }
    database.events.unshift(storedEvent);
    trimEvents(database);
    incrementMetric(database, "webhookEvents");
    if (event.type === "message") incrementMetric(database, "dmsReceived");

    if (event.instagramUserId) {
      const now = new Date().toISOString();
      let contact = database.contacts.find((item) => item.instagramUserId === event.instagramUserId);
      if (!contact) {
        contact = {
          id: `contact-${event.instagramUserId}`,
          instagramUserId: event.instagramUserId,
          username: event.username ?? event.instagramUserId,
          tags: [],
          createdAt: now,
          updatedAt: now,
          lastInteractionAt: now,
        };
        database.contacts.unshift(contact);
      } else {
        contact.username = event.username || contact.username;
        contact.updatedAt = now;
        contact.lastInteractionAt = now;
      }
      if (event.type === "message" && event.text) {
        addConversationMessage(database, event.instagramUserId, event.username ?? event.instagramUserId, {
          id: randomUUID(),
          direction: "inbound",
          channel: "dm",
          text: event.text,
          status: "received",
          createdAt: now,
        });
      }
    }
    database.updatedAt = new Date().toISOString();
  });

  if (duplicateDuringTransaction) return { status: "duplicate", mocked: 0, failed: 0, queued: 0 };

  if (!automation || !event.instagramUserId) {
    await jsonStore.transact((database) => {
      const current = database.events.find((item) => item.id === storedEvent.id);
      if (current) {
        current.status = "ignored";
        current.processedAt = new Date().toISOString();
      }
      database.updatedAt = new Date().toISOString();
    });
    return { status: "ignored", mocked: 0, failed: 0, queued: 0 };
  }

  const operationIds: string[] = [];
  for (const action of automation.actions.filter((item) => item.enabled)) {
    const text = renderActionText(action, initial);
    let channel: "dm" | "comment" | undefined;
    let kind: "dm" | "comment" | undefined;
    let recipientId: string | undefined;
    let commentId: string | undefined;
    if (action.type === "public_reply" && event.commentId) {
      channel = "comment";
      kind = "comment";
      commentId = event.commentId;
    } else if (["send_dm", "send_link"].includes(action.type)) {
      channel = "dm";
      kind = "dm";
      recipientId = event.instagramUserId;
    }
    if (!channel || !kind) continue;

    const messageId = randomUUID();
    const operation = await enqueueSendOperation({
      idempotencyKey: `webhook:${storedEvent.id}:${action.id}`,
      kind,
      recipientId,
      commentId,
      text,
      instagramUserId: event.instagramUserId,
      username: event.username,
      channel,
      automationId: automation.id,
      eventId: storedEvent.id,
      messageId,
    });
    operationIds.push(operation.operation.id);

    if (operation.created || !(await jsonStore.snapshot()).conversations.some((conversation) => conversation.messages.some((message) => message.operationId === operation.operation.id))) {
      const message: Message = {
        id: messageId,
        direction: "outbound",
        channel,
        text,
        status: operation.operation.status === "sent" ? operation.operation.providerMode === "mock" ? "mocked" : "sent" : operation.operation.status === "failed" ? "failed" : "queued",
        providerMessageId: operation.operation.providerMessageId,
        idempotencyKey: operation.operation.idempotencyKey,
        operationId: operation.operation.id,
        automationId: automation.id,
        linkId: action.linkId,
        createdAt: new Date().toISOString(),
      };
      await jsonStore.transact((database) => {
        if (event.instagramUserId && !database.conversations.some((conversation) => conversation.messages.some((item) => item.operationId === operation.operation.id))) {
          addConversationMessage(database, event.instagramUserId, event.username ?? event.instagramUserId, message);
          database.updatedAt = new Date().toISOString();
        }
      });
    }

  }

  if (operationIds.length === 0) {
    await jsonStore.transact((database) => {
      const current = database.events.find((item) => item.id === storedEvent.id);
      if (current) {
        current.status = "processed";
        current.deliveryRecorded = true;
        current.processedAt = new Date().toISOString();
      }
      database.updatedAt = new Date().toISOString();
    });
  }

  await processPendingSendOperations({ limit: operationIds.length, ids: operationIds });
  const currentOperations = (await operationQueue.snapshot()).sends.filter((item) => operationIds.includes(item.id));
  const operationResults = currentOperations.map((operation) => ({
    status: operation.status === "failed" ? "failed" : operation.status === "sent" ? "processed" : "queued",
    mocked: operation.status === "sent" && operation.providerMode === "mock" ? 1 : 0,
    failed: operation.status === "failed" ? 1 : 0,
    queued: operation.status === "queued" || operation.status === "processing" ? 1 : 0,
  }));

  const mocked = operationResults.reduce((total, item) => total + item.mocked, 0);
  const failed = operationResults.reduce((total, item) => total + item.failed, 0);
  const queued = operationResults.reduce((total, item) => total + item.queued, 0);
  return { status: failed > 0 ? "failed" : queued > 0 ? "queued" : "processed", mocked, failed, queued };
}

export async function processInstagramWebhookPayload(payload: unknown): Promise<{
  received: number;
  processed: number;
  ignored: number;
  duplicates: number;
  mocked: number;
  failed: number;
  queued: number;
}> {
  const events = normalizeInstagramPayload(payload);
  const summary = { received: events.length, processed: 0, ignored: 0, duplicates: 0, mocked: 0, failed: 0, queued: 0 };
  for (const event of events) {
    const result = await processOne(event);
    if (result.status === "processed") summary.processed += 1;
    else if (result.status === "duplicate") summary.duplicates += 1;
    else if (result.status === "ignored") summary.ignored += 1;
    summary.mocked += result.mocked;
    summary.failed += result.failed;
    summary.queued += result.queued;
  }
  return summary;
}

export function webhookPayloadFingerprint(rawBody: string): string {
  return createHash("sha256").update(rawBody).digest("hex");
}
