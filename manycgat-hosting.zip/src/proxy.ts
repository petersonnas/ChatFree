import { NextRequest, NextResponse } from "next/server";
import { isValidSessionToken } from "./lib/session";

const SESSION_COOKIE = "conversa_session";

export async function proxy(request: NextRequest): Promise<NextResponse> {
  const pathname = request.nextUrl.pathname;
  const accessKey = process.env.APP_ACCESS_KEY;

  if (!accessKey || pathname === "/api/health" || pathname.startsWith("/api/webhook/instagram") || pathname.startsWith("/api/auth")) {
    return NextResponse.next();
  }

  const valid = await isValidSessionToken(request.cookies.get(SESSION_COOKIE)?.value, accessKey);
  if (valid) return NextResponse.next();

  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Autenticação necessária." }, { status: 401 });
  }

  const loginUrl = new URL("/login", request.url);
  loginUrl.searchParams.set("next", `${pathname}${request.nextUrl.search}`);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ["/dashboard/:path*", "/api/:path*"],
};
