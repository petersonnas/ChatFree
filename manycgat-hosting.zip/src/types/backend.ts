export type AutomationStatus = "active" | "paused" | "draft" | "archived";

export type TriggerType =
  | "comment_keyword"
  | "comment_any"
  | "new_follower"
  | "dm_received"
  | "story_mention"
  | "story_reply";

export type AutomationActionType =
  | "public_reply"
  | "send_dm"
  | "send_link"
  | "request_follow"
  | "request_email"
  | "reminder";

export type Channel = "dm" | "comment" | "story";

export interface InstagramMedia {
  id: string;
  mediaType: "IMAGE" | "VIDEO" | "CAROUSEL_ALBUM";
  mediaUrl?: string;
  thumbnailUrl?: string;
  caption: string;
  permalink?: string;
  timestamp?: string;
}

export interface AutomationTrigger {
  type: TriggerType;
  keywords: string[];
  mediaId?: string;
  mediaScope?: "any" | "specific" | "next";
  media?: InstagramMedia;
}

export interface AutomationAction {
  id: string;
  type: AutomationActionType;
  enabled: boolean;
  message?: string;
  buttonText?: string;
  linkId?: string;
  delaySeconds?: number;
  variants?: string[];
}

export interface AutomationVersion {
  revision: number;
  savedAt: string;
  name: string;
  trigger: AutomationTrigger;
  actions: AutomationAction[];
}

export interface AutomationStats {
  runs: number;
  messagesSent: number;
  lastRunAt?: string;
}

export interface Automation {
  id: string;
  name: string;
  description: string;
  status: AutomationStatus;
  trigger: AutomationTrigger;
  actions: AutomationAction[];
  stats: AutomationStats;
  createdAt: string;
  updatedAt: string;
  /** Server-managed, monotonically increasing; legacy schemaVersion 1 records may omit it. */
  revision?: number;
  /** Previous 20 saved configurations, oldest first, for a future restore. */
  versions?: AutomationVersion[];
}

export interface AutomationDraft {
  name: string;
  description?: string;
  status?: AutomationStatus;
  trigger?: Partial<AutomationTrigger> & { type: TriggerType };
  actions?: Array<Partial<AutomationAction> & { type: AutomationActionType }>;
}

export interface Link {
  id: string;
  name: string;
  slug: string;
  url: string;
  utm?: LinkUtm;
  active: boolean;
  clicks: number;
  uniqueClicks: number;
  uniqueVisitorHashes: string[];
  createdAt: string;
  updatedAt: string;
}

export interface LinkUtm {
  source?: string;
  medium?: string;
  campaign?: string;
}

export interface LinkDraft {
  name: string;
  url: string;
  slug?: string;
  utm?: LinkUtm;
  active?: boolean;
}

export interface Contact {
  id: string;
  instagramUserId: string;
  username: string;
  displayName?: string;
  profilePictureUrl?: string;
  followsAccount?: boolean;
  email?: string;
  tags: string[];
  notes?: string[];
  note?: string;
  createdAt: string;
  updatedAt: string;
  lastInteractionAt: string;
}

export interface Message {
  id: string;
  direction: "inbound" | "outbound";
  channel: Channel;
  text: string;
  status?: "received" | "queued" | "sent" | "mocked" | "failed";
  providerMessageId?: string;
  /** Local client key used to make manual sends idempotent. */
  idempotencyKey?: string;
  /** Persistent operation that is delivering this message, when applicable. */
  operationId?: string;
  automationId?: string;
  linkId?: string;
  createdAt: string;
}

export interface Conversation {
  id: string;
  instagramUserId: string;
  username: string;
  status: "open" | "closed";
  /** Legacy conversations may omit this field and are treated as false. */
  pauseAutomation?: boolean;
  /** API/UI spelling retained alongside pauseAutomation. */
  automationPaused?: boolean;
  note?: string;
  notes?: string[];
  messages: Message[];
  createdAt: string;
  updatedAt: string;
  lastMessageAt: string;
}

export interface QuickReply {
  id: string;
  title: string;
  text: string;
}

export type StoredEventType = "comment" | "message" | "follow" | "mention" | "story_reply" | "unknown";
export type StoredEventStatus = "processing" | "processed" | "ignored" | "failed";

export interface StoredEvent {
  id: string;
  externalId?: string;
  type: StoredEventType;
  status: StoredEventStatus;
  instagramUserId?: string;
  username?: string;
  text?: string;
  commentId?: string;
  mediaId?: string;
  automationId?: string;
  error?: string;
  /** Set once all operations created for this event reach a terminal state. */
  deliveryRecorded?: boolean;
  receivedAt: string;
  processedAt?: string;
}

export interface MetricTotals {
  dmsSent: number;
  mockedDms: number;
  failedDms: number;
  dmsReceived: number;
  publicRepliesSent: number;
  mockedPublicReplies: number;
  failedPublicReplies: number;
  linkClicks: number;
  uniqueLinkClicks: number;
  automationRuns: number;
  webhookEvents: number;
  failedWebhookEvents: number;
}

export interface DailyMetrics extends MetricTotals {
  date: string;
}

export interface AggregatedMetrics {
  totals: MetricTotals;
  byDay: Record<string, DailyMetrics>;
  lastUpdatedAt: string;
}

export interface JsonDatabase {
  schemaVersion: 1;
  createdAt: string;
  updatedAt: string;
  automations: Automation[];
  links: Link[];
  contacts: Contact[];
  conversations: Conversation[];
  /** Optional so schemaVersion 1 databases created before Inbox remain valid. */
  quickReplies?: QuickReply[];
  events: StoredEvent[];
  metrics: AggregatedMetrics;
}

export interface DashboardData {
  summary: MetricTotals;
  daily: DailyMetrics[];
  automations: Array<Automation & { conversionRate: number }>;
  links: Link[];
  integration: {
    mode: "mock" | "live";
    accountConfigured: boolean;
  };
  generatedAt: string;
}

export interface AutomationFunnel {
  automationId: string;
  automationName: string;
  status: AutomationStatus;
  runs: number;
  messagesSent: number;
  linkClicks: number;
  uniqueLinkClicks: number;
  messageRate: number;
  clickRate: number;
  uniqueClickRate: number;
}

export interface AnalyticsData {
  range: {
    days: number;
    from: string;
    to: string;
  };
  totals: MetricTotals;
  links: Array<Omit<Link, "uniqueVisitorHashes">>;
  funnel: AutomationFunnel[];
  daily: DailyMetrics[];
}

export interface NormalizedInstagramEvent {
  externalId?: string;
  type: StoredEventType;
  instagramUserId?: string;
  username?: string;
  text?: string;
  commentId?: string;
  mediaId?: string;
  timestamp?: string;
}

export type OperationSendStatus = "queued" | "processing" | "sent" | "failed";
export type OperationSendKind = "dm" | "comment";

export interface SendOperation {
  id: string;
  idempotencyKey: string;
  kind: OperationSendKind;
  status: OperationSendStatus;
  recipientId?: string;
  commentId?: string;
  text: string;
  instagramUserId?: string;
  username?: string;
  channel: "dm" | "comment";
  automationId?: string;
  eventId?: string;
  messageId?: string;
  maxAttempts: number;
  attempts: number;
  createdAt: string;
  updatedAt: string;
  nextAttemptAt?: string;
  processingAt?: string;
  completedAt?: string;
  providerMessageId?: string;
  providerMode?: "mock" | "live";
  error?: string;
}

export interface WebhookLog {
  id: string;
  fingerprint: string;
  accepted: boolean;
  duplicate: boolean;
  eventCount?: number;
  receivedAt: string;
  completedAt?: string;
  error?: string;
}

export interface DataDeletionRequest {
  id: string;
  subjectId?: string;
  reason?: string;
  status: "requested" | "reviewed" | "completed";
  requestedAt: string;
}

export interface OperationDatabase {
  schemaVersion: 1;
  createdAt: string;
  updatedAt: string;
  sends: SendOperation[];
  webhooks: WebhookLog[];
  deletionRequests: DataDeletionRequest[];
}
