export type FlowStatus = "draft" | "active" | "paused" | "archived";

export type FlowNodeKind = "trigger" | "message" | "condition" | "delay" | "action" | "handoff" | "end";

export interface FlowNode {
  id: string;
  kind: FlowNodeKind;
  title: string;
  description: string;
  x: number;
  y: number;
  config?: Record<string, unknown>;
}

export interface FlowEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

export interface FlowVersion {
  revision: number;
  savedAt: string;
  name: string;
  nodes: FlowNode[];
  edges: FlowEdge[];
}

export interface Flow {
  id: string;
  automationId?: string;
  name: string;
  status: FlowStatus;
  nodes: FlowNode[];
  edges: FlowEdge[];
  revision: number;
  versions: FlowVersion[];
  createdAt: string;
  updatedAt: string;
}

export interface FlowDraft {
  id?: string;
  automationId?: string;
  name: string;
  status?: FlowStatus;
  nodes: FlowNode[];
  edges: FlowEdge[];
}
