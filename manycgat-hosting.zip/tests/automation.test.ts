import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import type { Automation, AutomationDraft, InstagramMedia, JsonDatabase } from "../src/types/backend";
import { createSeedDatabase } from "../src/lib/server/seed";
import { parseAutomationDraft, parseAutomationPatch, validateDatabase, ValidationError } from "../src/lib/server/validation";

// Import the repository only after redirecting the singleton store to a new
// temporary database. These tests never import providers or run webhook delivery.
let repository: typeof import("../src/lib/server/repository");
let directory: string;
let databasePath: string;
const originalDatabasePath = process.env.JSON_DB_PATH;
const originalFetch = globalThis.fetch;

before(async () => {
  directory = await mkdtemp(path.join(tmpdir(), "automation-tests-"));
  databasePath = path.join(directory, "db.json");
  process.env.JSON_DB_PATH = databasePath;
  globalThis.fetch = async () => { throw new Error("Network delivery is forbidden in automation tests."); };
  await writeFile(databasePath, JSON.stringify(createSeedDatabase()));
  repository = await import("../src/lib/server/repository");
});

after(async () => {
  globalThis.fetch = originalFetch;
  if (originalDatabasePath === undefined) delete process.env.JSON_DB_PATH;
  else process.env.JSON_DB_PATH = originalDatabasePath;
  if (directory) {
    assert.equal(path.dirname(directory), path.resolve(tmpdir()));
    assert.ok(path.basename(directory).startsWith("automation-tests-"));
    await rm(directory, { recursive: true, force: true });
  }
});

const media: InstagramMedia = {
  id: "example-media",
  mediaType: "CAROUSEL_ALBUM",
  mediaUrl: "https://example.com/image.jpg",
  thumbnailUrl: "https://example.com/thumb.jpg",
  caption: "Exemplo de mídia\n com espaços preservados ",
  permalink: "https://example.com/post",
  timestamp: "2026-09-22T12:00:00.000Z",
};

function draft(overrides: Partial<AutomationDraft> = {}): AutomationDraft {
  return {
    name: "Exemplo de automação",
    description: "Exemplo isolado de teste",
    status: "draft",
    trigger: { type: "comment_keyword", keywords: ["guia"], mediaScope: "specific", mediaId: media.id, media: structuredClone(media) },
    actions: [
      { id: "opening", type: "send_dm", enabled: true, message: " Abertura\n preservada ", buttonText: "Quero o guia" },
      { id: "delivery", type: "send_link", enabled: true, message: "Seu guia", linkId: "link-free-guide", buttonText: "Abrir" },
      { id: "reply", type: "public_reply", enabled: true, message: "Veja a DM", variants: [" Enviei! ", "Confira a DM"] },
      { id: "follow", type: "request_follow", enabled: true, message: "Siga o perfil" },
      { id: "email", type: "request_email", enabled: true, message: "Qual seu email?" },
      { id: "reminder", type: "reminder", enabled: true, message: "Conseguiu acessar?", delaySeconds: 300 },
    ],
    ...overrides,
  };
}

function matchingAutomation(id: string, trigger: Automation["trigger"], updatedAt = "2026-09-22T10:00:00.000Z"): Automation {
  return {
    id, name: `Exemplo ${id}`, description: "", status: "active", trigger, actions: [],
    stats: { runs: 0, messagesSent: 0 }, createdAt: updatedAt, updatedAt,
  };
}

function matchingDatabase(...automations: Automation[]): JsonDatabase {
  return { ...createSeedDatabase(), automations };
}

test("parse preserves every Phase 2 field, action IDs, order and whitespace", () => {
  const input = draft();
  assert.deepEqual(parseAutomationDraft(input), input);
  assert.equal(parseAutomationDraft(draft({ trigger: { type: "story_reply", keywords: [] } })).trigger?.type, "story_reply");
  const patch = parseAutomationPatch({ description: "", trigger: { type: "dm_received" } });
  assert.equal(patch.description, "");
  assert.equal(patch.trigger?.keywords, undefined);
  assert.equal(patch.name, undefined);
});

test("draft parser allows incomplete fields without converting an empty keyword trigger", () => {
  const input = draft({ name: "", trigger: { type: "comment_keyword", keywords: ["", "  "], mediaScope: "specific" }, actions: [{ type: "send_link", message: "", linkId: "" }] });
  assert.deepEqual(parseAutomationDraft(input), input);
  assert.equal(parseAutomationDraft(draft({ trigger: { type: "comment_keyword", keywords: [] } })).trigger?.type, "comment_keyword");
});

const malformed: Array<[string, unknown, RegExp]> = [
  ["name length", draft({ name: "a".repeat(121) }), /name.*120/],
  ["description shape", { ...draft(), description: null }, /description/],
  ["trigger shape", { ...draft(), trigger: [] }, /trigger/],
  ["scope enum", { ...draft(), trigger: { type: "comment_any", mediaScope: "all" } }, /mediaScope/],
  ["keywords shape", { ...draft(), trigger: { type: "dm_received", keywords: "guia" } }, /keywords/],
  ["keywords count", draft({ trigger: { type: "comment_keyword", keywords: Array(21).fill("guia") } }), /20/],
  ["keyword length", draft({ trigger: { type: "dm_received", keywords: ["a".repeat(81)] } }), /80/],
  ["media shape", { ...draft(), trigger: { type: "comment_any", media: null } }, /media/],
  ["media enum", { ...draft(), trigger: { type: "comment_any", media: { ...media, mediaType: "REEL" } } }, /mediaType/],
  ["caption length", draft({ trigger: { type: "comment_any", media: { ...media, caption: "a".repeat(2201) } } }), /2200/],
  ["timestamp", draft({ trigger: { type: "comment_any", media: { ...media, timestamp: "invalid" } } }), /timestamp/],
  ["action shape", { ...draft(), actions: [null] }, /actions/],
  ["enabled shape", { ...draft(), actions: [{ type: "send_dm", enabled: "true" }] }, /enabled/],
  ["action count", draft({ actions: Array.from({ length: 21 }, () => ({ type: "send_dm" })) }), /20/],
  ["message length", draft({ actions: [{ type: "send_dm", message: "a".repeat(1001) }] }), /1000/],
  ["duplicate IDs", draft({ actions: [{ id: "same", type: "send_dm" }, { id: "same", type: "send_link" }] }), /duplicados/],
  ["empty ID", draft({ actions: [{ id: " ", type: "send_dm" }] }), /id/],
  ["variants shape", { ...draft(), actions: [{ type: "public_reply", variants: [3] }] }, /variants/],
  ["variants count", draft({ actions: [{ type: "public_reply", variants: Array(21).fill("reply") }] }), /20/],
  ["variants action", draft({ actions: [{ type: "send_dm", variants: ["reply"] }] }), /public_reply/],
  ["NaN delay", draft({ actions: [{ type: "reminder", delaySeconds: NaN }] }), /delaySeconds/],
  ["infinite delay", draft({ actions: [{ type: "reminder", delaySeconds: Infinity }] }), /delaySeconds/],
  ["negative delay", draft({ actions: [{ type: "reminder", delaySeconds: -1 }] }), /delaySeconds/],
];
for (const [name, input, message] of malformed) {
  test(`draft rejects malformed ${name}`, () => {
    assert.throws(() => parseAutomationDraft(input), (error: unknown) => error instanceof ValidationError && error.statusCode === 400 && message.test(error.message));
  });
}

test("repository roundtrip survives disk reload and preserves IDs and independent prior snapshots", async () => {
  const input = draft();
  const created = await repository.createAutomation(parseAutomationDraft(input));
  assert.equal(created.revision, 1);
  assert.deepEqual(created.versions, []);
  assert.deepEqual(created.trigger, input.trigger);
  assert.deepEqual(created.actions, input.actions);
  assert.deepEqual(await repository.getAutomation(created.id), created);
  const actions = structuredClone(created.actions);
  actions[0].message = "Abertura alterada";
  actions.reverse();
  const updated = await repository.updateAutomation(created.id, parseAutomationPatch({ name: "Exemplo alterado", description: "", actions }));
  assert.ok(updated);
  assert.equal(updated.revision, 2);
  assert.equal(updated.description, "");
  assert.deepEqual(updated.actions, actions);
  assert.deepEqual(updated.versions, [{ revision: 1, savedAt: created.updatedAt, name: created.name, trigger: created.trigger, actions: created.actions }]);
  updated.versions![0].actions[0].message = "Mutação externa";
  input.trigger!.media!.caption = "Mutação externa";
  const persisted = await repository.getAutomation(created.id);
  assert.equal(persisted?.versions?.[0].actions[0].message, created.actions[0].message);
  const { JsonStore } = await import("../src/lib/server/json-store");
  const reloaded = await new JsonStore(databasePath).snapshot();
  assert.deepEqual(reloaded.automations.find((item) => item.id === created.id), persisted);
});

test("permissive drafts save and list; incomplete active creation fails without writing", async () => {
  const input = draft({ name: "", trigger: { type: "comment_keyword", keywords: [], mediaScope: "specific" }, actions: [{ type: "send_link", message: "", linkId: "" }] });
  const saved = await repository.createAutomation(input);
  assert.ok((await repository.listAutomations({ status: "draft" })).some((item) => item.id === saved.id));
  const before = await readFile(databasePath, "utf8");
  await assert.rejects(repository.createAutomation({ ...input, status: "active" }), /nome/);
  assert.equal(await readFile(databasePath, "utf8"), before);
});

const invalidPublications: Array<[string, Partial<AutomationDraft>, RegExp]> = [
  ["empty keywords", { trigger: { type: "comment_keyword", keywords: [] } }, /palavra-chave/],
  ["blank keyword", { trigger: { type: "dm_received", keywords: [" "] } }, /palavras-chave/],
  ["missing specific media", { trigger: { type: "comment_any", mediaScope: "specific" } }, /mídia específica/],
  ["conflicting media IDs", { trigger: { type: "comment_any", mediaId: "other", media } }, /corresponder/],
  ["unsupported follower", { trigger: { type: "new_follower" } }, /new_follower.*não disponível/],
  ["opening only", { actions: [{ type: "send_dm", message: "Abertura" }] }, /entrega send_link/],
  ["disabled delivery", { actions: [{ type: "send_link", enabled: false }] }, /entrega send_link/],
  ["missing message", { actions: [{ type: "send_link", message: " ", linkId: "link-free-guide" }] }, /mensagem/],
  ["missing link", { actions: [{ type: "send_link", message: "Entrega" }] }, /selecione um link/],
  ["nonexistent link", { actions: [{ type: "send_link", message: "Entrega", linkId: "missing" }] }, /não existe/],
  ["blank variant", { actions: [...draft().actions!, { type: "public_reply", variants: [" "] }] }, /variantes/],
];
for (const [name, overrides, message] of invalidPublications) {
  test(`publication rejects ${name} and keeps the draft and history unchanged`, async () => {
    const saved = await repository.createAutomation(draft(overrides));
    const before = await readFile(databasePath, "utf8");
    await assert.rejects(repository.updateAutomation(saved.id, { status: "active" }), message);
    assert.deepEqual(await repository.getAutomation(saved.id), saved);
    assert.equal(await readFile(databasePath, "utf8"), before);
  });
}

test("publication checks current link state, supports variants and ignores disabled incomplete actions", async () => {
  const inactive = await repository.createLink({ name: "Exemplo inativo", url: "https://example.com", active: false });
  await assert.rejects(repository.createAutomation(draft({ status: "active", actions: [{ type: "send_link", message: "Entrega", linkId: inactive.id }] })), /inativo/);
  const actions = draft().actions!.map((action) => action.type === "public_reply" ? { ...action, message: "" } : action);
  actions.push({ type: "reminder", enabled: false, message: "" });
  const active = await repository.createAutomation(draft({ status: "active", actions }));
  assert.equal(active.status, "active");
  const before = await repository.getAutomation(active.id);
  await assert.rejects(repository.updateAutomation(active.id, { actions: [{ type: "send_dm", message: "Abertura" }] }), /entrega/);
  assert.deepEqual(await repository.getAutomation(active.id), before);
});

test("patch keeps omitted trigger fields and keywords, clears old scope selection, and persists story_reply", async () => {
  const saved = await repository.createAutomation(draft());
  const dm = await repository.updateAutomation(saved.id, { trigger: { type: "dm_received" } });
  assert.deepEqual(dm?.trigger, { ...saved.trigger, type: "dm_received" });
  const next = await repository.updateAutomation(saved.id, { trigger: { type: "story_reply", mediaScope: "next" } });
  assert.equal(next?.trigger.mediaId, undefined);
  assert.equal(next?.trigger.media, undefined);
  assert.deepEqual(next?.trigger.keywords, ["guia"]);
  assert.equal(next?.trigger.type, "story_reply");
  const specific = await repository.updateAutomation(saved.id, { trigger: { type: "comment_any", mediaScope: "specific", media } });
  assert.equal(specific?.trigger.mediaId, media.id);
});

test("revisions are serialized, preserve previous configurations, cap at 20 and can restore fields", async () => {
  const saved = await repository.createAutomation(draft());
  await Promise.all(Array.from({ length: 23 }, (_, i) => repository.updateAutomation(saved.id, { name: `Exemplo revisão ${i + 2}` })));
  const current = await repository.getAutomation(saved.id);
  assert.equal(current?.revision, 24);
  assert.equal(current?.versions?.length, 20);
  assert.deepEqual(current?.versions?.map((item) => item.revision), Array.from({ length: 20 }, (_, i) => i + 4));
  const previous = current!.versions![0];
  const restored = await repository.updateAutomation(saved.id, { name: previous.name, trigger: previous.trigger, actions: previous.actions });
  assert.equal(restored?.revision, 25);
  assert.equal(restored?.name, previous.name);
  assert.deepEqual(restored?.actions, previous.actions);
  assert.equal(restored?.versions?.at(-1)?.revision, 24);
  assert.equal(await repository.archiveAutomation(saved.id), true);
  assert.equal((await repository.getAutomation(saved.id))?.revision, 26);
  assert.equal(await repository.archiveAutomation("missing"), false);
});

test("schemaVersion 1 seeds remain readable and receive a snapshot on their first edit", async () => {
  const seed = createSeedDatabase();
  assert.doesNotThrow(() => validateDatabase(seed));
  const legacy = await repository.getAutomation("automation-welcome");
  assert.equal(legacy?.revision, undefined);
  const updated = await repository.updateAutomation("automation-welcome", { status: "paused" });
  assert.equal(updated?.revision, 2);
  assert.deepEqual(updated?.versions?.[0].actions, legacy?.actions);
  assert.equal(updated?.versions?.[0].revision, 1);
  const invalid = { ...seed, automations: [{ ...updated, versions: Array(21).fill(updated?.versions?.[0]) }] };
  assert.throws(() => validateDatabase(invalid), /20 snapshots/);
});

test("matcher ignores unknown/follow events, respects DM keywords and separates story replies", () => {
  const dm = matchingAutomation("dm", { type: "dm_received", keywords: ["ação"] });
  const story = matchingAutomation("story", { type: "story_reply", keywords: [] });
  const follower = matchingAutomation("follower", { type: "new_follower", keywords: [] });
  const database = matchingDatabase(dm, story, follower);
  for (const event of ["unknown", "unexpected", "", "follow", "toString"]) assert.equal(repository.findMatchingAutomation(database, event, "AÇÃO"), undefined);
  assert.equal(repository.findMatchingAutomation(database, "message", "quero ACAO")?.id, "dm");
  assert.equal(repository.findMatchingAutomation(database, "message", "olá"), undefined);
  assert.equal(repository.findMatchingAutomation(database, "story_reply", "olá")?.id, "story");
  assert.equal(repository.findMatchingAutomation(database, "mention", "olá"), undefined);
});

test("matcher prioritizes media then keywords then recency, never mutating database order", () => {
  const general = matchingAutomation("general", { type: "comment_any", keywords: [] }, "2026-09-23T10:00:00.000Z");
  const keyword = matchingAutomation("keyword", { type: "comment_keyword", keywords: ["guia"] });
  const specific = matchingAutomation("specific", { type: "comment_any", keywords: [], mediaId: media.id });
  const database = matchingDatabase(general, keyword, specific);
  const before = structuredClone(database);
  assert.equal(repository.findMatchingAutomation(database, "comment", "guia", media.id)?.id, "specific");
  assert.equal(repository.findMatchingAutomation(database, "comment", "GUIA", "other")?.id, "keyword");
  assert.equal(repository.findMatchingAutomation(database, "comment", "olá")?.id, "general");
  assert.deepEqual(database, before);
  const newerKeyword = { ...keyword, id: "newer", updatedAt: "2026-09-24T10:00:00.000Z" };
  assert.equal(repository.findMatchingAutomation(matchingDatabase(keyword, newerKeyword), "comment", "guia")?.id, "newer");
  assert.equal(repository.findMatchingAutomation(matchingDatabase({ ...keyword, status: "paused" }), "comment", "guia"), undefined);
  assert.equal(repository.findMatchingAutomation(matchingDatabase(matchingAutomation("blank", { type: "comment_keyword", keywords: [" "] })), "comment", "anything"), undefined);
});

test("media scopes honor legacy IDs, explicit any and unresolved specific/next", () => {
  for (const scope of ["specific", "next"] as const) {
    const unresolved = matchingAutomation(scope, { type: "comment_any", keywords: [], mediaScope: scope });
    assert.equal(repository.findMatchingAutomation(matchingDatabase(unresolved), "comment", "", media.id), undefined);
  }
  const any = matchingAutomation("any", { type: "comment_any", keywords: [], mediaScope: "any", mediaId: "stale" });
  assert.equal(repository.findMatchingAutomation(matchingDatabase(any), "comment", "", media.id)?.id, "any");
  const legacy = matchingAutomation("legacy", { type: "comment_any", keywords: [], mediaId: media.id });
  assert.equal(repository.findMatchingAutomation(matchingDatabase(legacy), "comment", "", "other"), undefined);
});

test("next resolution is pure, chooses earliest eligible media and never rebinds", async () => {
  const saved = await repository.createAutomation(draft({ status: "active", trigger: { type: "comment_any", keywords: [], mediaScope: "next" } }));
  const timestamp = Date.parse(saved.updatedAt);
  const first = { ...media, id: "first", timestamp: new Date(timestamp + 1000).toISOString() };
  const later = { ...media, id: "later", timestamp: new Date(timestamp + 2000).toISOString() };
  const candidates = [later, { ...media, timestamp: saved.updatedAt }, { ...media, timestamp: undefined }, { ...media, timestamp: "invalid" }, first];
  const before = structuredClone({ saved, candidates });
  const resolved = repository.resolveNextAutomationMedia(saved, candidates);
  assert.equal(resolved?.mediaId, "first");
  assert.deepEqual({ saved, candidates }, before);
  assert.equal(repository.resolveNextAutomationMedia(saved, []), undefined);
  assert.ok(resolved);
  const bound = await repository.updateAutomation(saved.id, { trigger: resolved });
  assert.ok(bound);
  assert.equal(repository.resolveNextAutomationMedia(bound, [later])?.mediaId, "first");
  assert.equal(repository.findMatchingAutomation(matchingDatabase(bound), "comment", "", "first")?.id, bound.id);
  assert.equal(repository.findMatchingAutomation(matchingDatabase(bound), "comment", "", "later"), undefined);
});

test("public reply variants render text and inactive links are not appended", () => {
  const database = createSeedDatabase();
  assert.equal(repository.renderActionText({ id: "reply", type: "public_reply", enabled: true, variants: ["Primeira", "Segunda"] }, database), "Primeira");
  const action = { id: "delivery", type: "send_link" as const, enabled: true, message: "Entrega", linkId: database.links[0].id };
  assert.equal(repository.renderActionText(action, database), `Entrega\n${database.links[0].url}`);
  database.links[0].active = false;
  assert.equal(repository.renderActionText(action, database), "Entrega");
});
