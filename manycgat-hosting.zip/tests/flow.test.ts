import assert from "node:assert/strict";
import test from "node:test";
import { parseFlowDraft, validateFlowPublication } from "../src/lib/server/flow-validation";
import type { Flow } from "../src/types/flow";

const base = {
  name: "Fluxo de comentários",
  nodes: [
    { id: "trigger", kind: "trigger", title: "Comentário recebido", description: "", x: 0, y: 0 },
    { id: "message", kind: "message", title: "Enviar mensagem", description: "Olá!", x: 260, y: 0 },
    { id: "action", kind: "action", title: "Entregar link", description: "Material", x: 520, y: 0 },
  ],
  edges: [
    { id: "edge-1", source: "trigger", target: "message" },
    { id: "edge-2", source: "message", target: "action" },
  ],
};

test("flow draft roundtrips nodes and labeled branches", () => {
  const draft = parseFlowDraft({ ...base, edges: [...base.edges, { id: "edge-3", source: "message", target: "action", label: "Sim" }] });
  assert.equal(draft.nodes[1].kind, "message");
  assert.equal(draft.edges[2].label, "Sim");
  const serialized = JSON.parse(JSON.stringify(draft)) as typeof draft;
  assert.equal(serialized.name, draft.name);
  assert.deepEqual(serialized.nodes, draft.nodes);
  assert.deepEqual(serialized.edges, draft.edges);
});

test("active flow requires one reachable trigger and an executable node", () => {
  const flow = parseFlowDraft({ ...base, status: "active" }) as Flow;
  flow.status = "active";
  assert.doesNotThrow(() => validateFlowPublication(flow));
});

test("active flow rejects disconnected nodes and cycles", () => {
  const disconnected = parseFlowDraft({ ...base, nodes: [...base.nodes, { id: "orphan", kind: "end", title: "Fim", description: "", x: 800, y: 0 }], status: "active" }) as Flow;
  disconnected.status = "active";
  assert.throws(() => validateFlowPublication(disconnected), /conectados/);

  const cycle = parseFlowDraft({ ...base, edges: [...base.edges, { id: "edge-cycle", source: "action", target: "trigger" }], status: "draft" }) as Flow;
  cycle.status = "active";
  assert.throws(() => validateFlowPublication(cycle), /ciclos/);
});

test("invalid connections fail before they can be persisted", () => {
  assert.throws(() => parseFlowDraft({ ...base, edges: [{ id: "edge-invalid", source: "message", target: "missing" }] }), /nó inexistente/);
});
