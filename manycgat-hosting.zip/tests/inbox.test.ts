import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createSeedDatabase } from "../src/lib/server/seed";
import { JsonStore } from "../src/lib/server/json-store";
import { InboxRepository, parseInboxPatch, parseManualMessage } from "../src/lib/server/inbox-repository";

async function withRepository(run: (repository: InboxRepository, databasePath: string) => Promise<void>): Promise<void> {
  const directory = await mkdtemp(path.join(os.tmpdir(), "manycgat-inbox-"));
  const databasePath = path.join(directory, "db.json");
  const database = createSeedDatabase();
  await import("node:fs/promises").then(({ writeFile }) => writeFile(databasePath, JSON.stringify(database), "utf8"));
  try {
    await run(new InboxRepository(new JsonStore(databasePath)), databasePath);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

test("reads schemaVersion 1 conversations with normalized contact details", async () => {
  await withRepository(async (repository) => {
    const list = await repository.list();
    assert.equal(list.length, 2);
    assert.equal(list[0].id, "conversation-100001");
    assert.deepEqual(list[0].tags, ["guia", "lead"]);
    assert.equal(list[0].channel, "dm");

    const detail = await repository.get("conversation-100001");
    assert.equal(detail?.contact.displayName, "Ana Exemplo");
    assert.deepEqual(detail?.contact.notes, []);
    assert.equal(detail?.conversation.pauseAutomation, false);
    assert.equal(detail?.conversation.messages.length, 2);
    assert.equal(detail?.quickReplies.length, 3);
  });
});

test("validates message IDs, tags and notes before a transaction", () => {
  assert.throws(() => parseManualMessage({ text: "Olá", idempotencyKey: "chave inválida" }), /ID válido/);
  assert.throws(() => parseManualMessage({ text: "   " }), /não vazia/);
  assert.throws(() => parseInboxPatch({ tags: ["lead", " LEAD "] }), /duplicatas/);
  assert.throws(() => parseInboxPatch({ notes: [" "] }), /notes/);
  assert.deepEqual(parseManualMessage({ quickReplyId: "greeting", idempotencyKey: "send-1" }), {
    quickReplyId: "greeting",
    idempotencyKey: "send-1",
    text: undefined,
    id: undefined,
    channel: "dm",
  });
});

test("updates status, pauseAutomation, tags and notes atomically", async () => {
  await withRepository(async (repository, databasePath) => {
    const updated = await repository.update("conversation-100002", {
      status: "closed",
      automationPaused: true,
      tags: ["vip", "follow-up"],
      note: "Responder sobre a comunidade.",
    });
    assert.equal(updated?.conversation.status, "closed");
    assert.equal(updated?.conversation.pauseAutomation, true);
    assert.deepEqual(updated?.contact.tags, ["vip", "follow-up"]);
    assert.deepEqual(updated?.contact.notes, ["Responder sobre a comunidade."]);
    assert.equal(updated?.conversation.note, "Responder sobre a comunidade.");

    const persisted = JSON.parse(await readFile(databasePath, "utf8")) as {
      schemaVersion: number;
      conversations: Array<{ id: string; status: string; pauseAutomation?: boolean }>;
      contacts: Array<{ id: string; tags: string[]; notes?: string[] }>;
    };
    assert.equal(persisted.schemaVersion, 1);
    assert.equal(persisted.conversations.find((item) => item.id === "conversation-100002")?.pauseAutomation, true);
    assert.deepEqual(persisted.contacts.find((item) => item.id === "contact-100002")?.notes, ["Responder sobre a comunidade."]);
  });
});

test("sends a mocked message and is locally idempotent under concurrent retries", async () => {
  await withRepository(async (repository) => {
    const results = await Promise.all([
      repository.send("conversation-100002", parseManualMessage({ text: "Olá, Bruno", idempotencyKey: "manual-1" })),
      repository.send("conversation-100002", parseManualMessage({ text: "Olá, Bruno", idempotencyKey: "manual-1" })),
    ]);
    assert.equal(results.filter((item) => item?.idempotent === false).length, 1);
    assert.equal(results.filter((item) => item?.idempotent === true).length, 1);
    assert.equal(results[0]?.message.id, results[1]?.message.id);
    assert.equal(results[0]?.message.status, "mocked");

    const detail = await repository.get("conversation-100002");
    assert.equal(detail?.conversation.messages.filter((message) => message.idempotencyKey === "manual-1").length, 1);

    const quickReply = await repository.send("conversation-100002", parseManualMessage({ quickReplyId: "greeting", idempotencyKey: "manual-2" }));
    assert.equal(quickReply?.message.text, "Olá! Como posso ajudar?");
    assert.equal(quickReply?.message.status, "mocked");
  });
});
