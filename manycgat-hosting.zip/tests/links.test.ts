import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { NextRequest } from "next/server";
import { createSeedDatabase } from "../src/lib/server/seed";
import { parseLinkDraft, validateDatabase } from "../src/lib/server/validation";

let directory: string;
let databasePath: string;
let repository: typeof import("../src/lib/server/repository");
let redirectRoute: typeof import("../src/app/r/[slug]/route");
const originalDatabasePath = process.env.JSON_DB_PATH;

before(async () => {
  directory = await mkdtemp(path.join(tmpdir(), "manycgat-links-"));
  databasePath = path.join(directory, "db.json");
  process.env.JSON_DB_PATH = databasePath;
  const legacy = createSeedDatabase() as unknown as Record<string, unknown>;
  const links = legacy.links as Array<Record<string, unknown>>;
  delete links[0].slug;
  delete links[0].active;
  delete links[0].utm;
  await writeFile(databasePath, JSON.stringify(legacy), "utf8");
  repository = await import("../src/lib/server/repository");
  redirectRoute = await import("../src/app/r/[slug]/route");
});

after(async () => {
  if (originalDatabasePath === undefined) delete process.env.JSON_DB_PATH;
  else process.env.JSON_DB_PATH = originalDatabasePath;
  await rm(directory, { recursive: true, force: true });
});

test("valida URL, slug e UTMs antes de persistir", () => {
  assert.deepEqual(parseLinkDraft({
    name: "Material",
    slug: "material",
    url: "https://example.com/landing?ref=dm",
    utm: { source: "instagram", medium: "dm", campaign: "guia-2026" },
  }).utm, { source: "instagram", medium: "dm", campaign: "guia-2026" });
  assert.throws(() => parseLinkDraft({ name: "x", url: "javascript:alert(1)" }), /http ou https/);
  assert.throws(() => parseLinkDraft({ name: "x", url: "https://example.com", utm: "instagram" }), /utm/);
  assert.throws(() => parseLinkDraft({ name: "x", url: "https://user:pass@example.com" }), /credenciais/);
  assert.throws(() => parseLinkDraft({ name: "x", slug: "../admin", url: "https://example.com" }), /slug/);
});

test("normaliza link legado e grava criação com UTM", async () => {
  const legacy = await repository.listLinks();
  assert.equal(legacy[0].slug, "guia-gratuito");
  assert.equal(legacy[0].active, true);

  const created = await repository.createLink(parseLinkDraft({
    name: "Página segura",
    slug: "pagina-segura",
    url: "https://example.com/landing",
    utm: { source: "instagram", medium: "bio" },
  }));
  assert.deepEqual(created.utm, { source: "instagram", medium: "bio" });
  const persisted = JSON.parse(await readFile(databasePath, "utf8")) as { links: Array<Record<string, unknown>> };
  assert.deepEqual(persisted.links.find((link) => link.id === created.id)?.utm, { source: "instagram", medium: "bio" });
});

test("redireciona com UTMs codificadas e contabiliza clique único", async () => {
  const link = await repository.createLink({
    name: "Campanha",
    slug: "campanha",
    url: "https://example.com/oferta?existing=1",
    utm: { source: "instagram & dm", medium: "story", campaign: "set/1" },
    active: true,
  });
  const first = await redirectRoute.GET(new NextRequest("http://localhost/r/campanha", { headers: { "x-real-ip": "203.0.113.10", "user-agent": "test" } }), { params: Promise.resolve({ slug: link.slug }) });
  const second = await redirectRoute.GET(new NextRequest("http://localhost/r/campanha", { headers: { "x-real-ip": "203.0.113.10", "user-agent": "test" } }), { params: Promise.resolve({ slug: link.slug }) });
  assert.equal(first.status, 302);
  assert.equal(second.status, 302);
  const location = first.headers.get("location");
  assert.ok(location);
  const target = new URL(location);
  assert.equal(target.origin, "https://example.com");
  assert.equal(target.searchParams.get("existing"), "1");
  assert.equal(target.searchParams.get("utm_source"), "instagram & dm");
  assert.equal(target.searchParams.get("utm_medium"), "story");
  assert.equal(target.searchParams.get("utm_campaign"), "set/1");
  const counted = (await repository.listLinks()).find((item) => item.id === link.id);
  assert.equal(counted?.clicks, 2);
  assert.equal(counted?.uniqueClicks, 1);
});

test("analytics expõe totais, links sem hashes e funil por automação", async () => {
  const analytics = await repository.getAnalytics(30);
  assert.equal(analytics.totals.linkClicks, 394);
  assert.ok(analytics.links.every((link) => !("uniqueVisitorHashes" in link)));
  assert.ok(analytics.funnel.some((item) => item.automationId === "automation-free-guide"));
  assert.ok(analytics.daily.length >= 1);
  assert.doesNotThrow(() => validateDatabase(createSeedDatabase()));
});
