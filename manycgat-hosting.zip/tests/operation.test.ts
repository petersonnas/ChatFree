import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { OperationQueue } from "../src/lib/server/operation-queue";
import { isAuthorizedForOperations } from "../src/lib/server/operation-auth";
import { getInstagramIntegrationDiagnostics } from "../src/lib/server/instagram";

async function withQueue(run: (queue: OperationQueue, filePath: string) => Promise<void>): Promise<void> {
  const directory = await mkdtemp(path.join(os.tmpdir(), "manycgat-operation-"));
  const filePath = path.join(directory, "operations.json");
  try {
    await run(new OperationQueue(filePath), filePath);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

test("persists sends and is idempotent across retries", async () => {
  await withQueue(async (queue, filePath) => {
    const input = { idempotencyKey: "send-1", kind: "dm" as const, recipientId: "user-1", text: "Olá", channel: "dm" as const };
    const first = await queue.enqueue(input);
    const second = await queue.enqueue(input);
    assert.equal(first.created, true);
    assert.equal(second.created, false);
    assert.equal(first.operation.id, second.operation.id);

    const processed = await queue.process(async () => ({ ok: true, mode: "mock" as const, providerMessageId: "mock-1" }));
    assert.equal(processed[0]?.operation.status, "sent");
    assert.equal(processed[0]?.operation.attempts, 1);

    const reloaded = await new OperationQueue(filePath).snapshot();
    assert.equal(reloaded.sends[0]?.status, "sent");
    assert.equal(JSON.stringify(reloaded).includes("INSTAGRAM_ACCESS_TOKEN"), false);
  });
});

test("enforces the local per-minute limit and records bounded retry backoff", async () => {
  const previousLimit = process.env.OPERATION_SENDS_PER_MINUTE;
  const previousBase = process.env.OPERATION_RETRY_BASE_MS;
  process.env.OPERATION_SENDS_PER_MINUTE = "1";
  process.env.OPERATION_RETRY_BASE_MS = "60000";
  try {
    await withQueue(async (queue) => {
      await queue.enqueue({ idempotencyKey: "send-1", kind: "dm", recipientId: "user-1", text: "A", channel: "dm" });
      await queue.enqueue({ idempotencyKey: "send-2", kind: "dm", recipientId: "user-2", text: "B", channel: "dm" });
      const firstPass = await queue.process(async () => ({ ok: true, mode: "mock" as const }));
      assert.equal(firstPass.length, 1);
      assert.equal((await queue.health()).counts.queued, 1);

      const retryQueue = new OperationQueue(path.join(os.tmpdir(), `manycgat-retry-${Date.now()}.json`));
      const retry = await retryQueue.enqueue({ idempotencyKey: "retry-1", kind: "dm", recipientId: "user-3", text: "C", channel: "dm", maxAttempts: 2 });
      const failed = await retryQueue.process(async () => ({ ok: false, mode: "live" as const, error: "temporário" }));
      assert.equal(failed[0]?.operation.status, "queued");
      assert.equal(failed[0]?.operation.attempts, 1);
      assert.ok(Date.parse(failed[0]?.operation.nextAttemptAt ?? "") > Date.now());
      assert.equal(retry.operation.status, "queued");
      await rm(retryQueue.filePath, { force: true });
    });
  } finally {
    if (previousLimit === undefined) delete process.env.OPERATION_SENDS_PER_MINUTE;
    else process.env.OPERATION_SENDS_PER_MINUTE = previousLimit;
    if (previousBase === undefined) delete process.env.OPERATION_RETRY_BASE_MS;
    else process.env.OPERATION_RETRY_BASE_MS = previousBase;
  }
});

test("logs webhook duplicates and data deletion requests without payloads", async () => {
  await withQueue(async (queue, filePath) => {
    const first = await queue.recordWebhook({ fingerprint: "hash-1", accepted: true, eventCount: 1 });
    const duplicate = await queue.recordWebhook({ fingerprint: "hash-1", accepted: true, eventCount: 1 });
    const rejected = await queue.recordWebhook({ fingerprint: "hash-1", accepted: false, error: "Assinatura inválida." });
    const deletion = await queue.requestDeletion({ subjectId: "instagram-user-1", reason: "Solicitação do titular" });
    const persisted = JSON.parse(await readFile(filePath, "utf8")) as { webhooks: Array<{ id: string; duplicate: boolean }>; deletionRequests: Array<{ id: string }> };
    assert.equal(first.duplicate, false);
    assert.equal(duplicate.duplicate, true);
    assert.equal(rejected.duplicate, false);
    assert.equal(persisted.webhooks.length, 3);
    assert.equal(persisted.deletionRequests[0]?.id, deletion.id);
    assert.equal(JSON.stringify(persisted).includes("access_token"), false);
  });
});

test("protects operations and redacts credentials from diagnostics", async () => {
  const previousAppKey = process.env.APP_ACCESS_KEY;
  const previousOpsKey = process.env.OPS_ACCESS_KEY;
  const previousBaseUrl = process.env.META_GRAPH_API_BASE_URL;
  process.env.APP_ACCESS_KEY = "app-secret-for-test";
  process.env.OPS_ACCESS_KEY = "ops-secret-for-test";
  process.env.META_GRAPH_API_BASE_URL = "https://graph.example.test/v1?access_token=do-not-return";
  try {
    assert.equal(await isAuthorizedForOperations(new Request("http://localhost/api/ops/diagnostics")), false);
    assert.equal(await isAuthorizedForOperations(new Request("http://localhost/api/ops/diagnostics", { headers: { "x-ops-key": "ops-secret-for-test" } })), true);
    const diagnostics = getInstagramIntegrationDiagnostics();
    assert.equal(diagnostics.graphApiBaseUrl.includes("do-not-return"), false);
  } finally {
    if (previousAppKey === undefined) delete process.env.APP_ACCESS_KEY;
    else process.env.APP_ACCESS_KEY = previousAppKey;
    if (previousOpsKey === undefined) delete process.env.OPS_ACCESS_KEY;
    else process.env.OPS_ACCESS_KEY = previousOpsKey;
    if (previousBaseUrl === undefined) delete process.env.META_GRAPH_API_BASE_URL;
    else process.env.META_GRAPH_API_BASE_URL = previousBaseUrl;
  }
});
